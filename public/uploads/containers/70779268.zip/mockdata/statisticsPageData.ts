export const statisticsContentData = {
  text: 'Yeni qlobal reallıqlara adekvat makroiqtisadi siyasətin, o cümlədən monetar siyasətin formalaşması operativ, keyfiyyətli və əhatəli statistik məlumatlardan istifadə zərurəti yaradır. Mərkəzi Bank pul və valyuta siyasətinin hazırlanması, onun makroiqtisadi nəticələrinin təhlil edilməsi, iqtisadi tədqiqatların aparılması və proqnoz göstəricilərin işlənməsi üçün beynəlxalq standartlara cavab verən keyfiyyətli və əhatəli statistik məlumatların toplanmasını, emalını, icmallaşdırılmasını, təhlil edilməsini və istifadəçilərə çatdırılmasını təmin edir.Mərkəzi Bank – “Azərbaycan Respublikası Mərkəzi Bankı haqqında Qanun”un 64-cü Maddəsinə uyğun olaraq ayda bir dəfədən az olmayaraq pul və maliyyə bazarlarının vəziyyəti haqqında informasiya bülletenləri buraxır və bank sistemi haqqında ümumiləşdirilmiş statistika, habelə iqtisadi məsələlərə aid məqsədəuyğun saydığı digər məlumatı maliyyə bazarlarına nəzarət orqanı ilə razılaşdırmaqla dərc etdirir.',
};
export const statisticsBulletin = [
  {
    id: 1,
    title: '2025',
    files: [
      {
        id: 1,
        title: 'May',
        year: 2025,
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'xls',
      },
      {
        id: 2,
        title: 'May',
        year: 2025,
        coverTitle: 'Statistik Bülleten',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
      {
        id: 3,
        title: 'Aprel',
        year: 2025,
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'xls',
      },
      {
        id: 4,
        title: 'Aprel',
        year: 2025,
        coverTitle: 'Statistik Bülleten',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
    ],
  },
  {
    id: 2,
    title: '2024',
    files: [
      {
        id: 1,
        title: 'May',
        year: 2024,
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'xls',
      },
      {
        id: 2,
        title: 'May',
        year: 2024,
        coverTitle: 'Statistik Bülleten',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
      {
        id: 3,
        title: 'Aprel',
        year: 2024,
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'xls',
      },
      {
        id: 4,
        title: 'Aprel',
        year: 2024,
        coverTitle: 'Statistik Bülleten',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
    ],
  },
  {
    id: 3,
    title: '2023',
    files: [
      {
        id: 1,
        title: 'May',
        year: 2023,
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'xls',
      },
      {
        id: 2,
        title: 'May',
        year: 2023,
        coverTitle: 'Statistik Bülleten',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
      {
        id: 3,
        title: 'Aprel',
        year: 2023,
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'xls',
      },
      {
        id: 4,
        title: 'Aprel',
        year: 2023,
        coverTitle: 'Statistik Bülleten',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
    ],
  },
  {
    id: 4,
    title: '2022',
    files: [
      {
        id: 1,
        title: 'May',
        year: 2022,
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'xls',
      },
      {
        id: 2,
        title: 'May',
        year: 2022,
        coverTitle: 'Statistik Bülleten',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
      {
        id: 3,
        title: 'Aprel',
        year: 2022,
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'xls',
      },
      {
        id: 4,
        title: 'Aprel',
        year: 2022,
        coverTitle: 'Statistik Bülleten',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
    ],
  },
  {
    id: 5,
    title: '2021',
    files: [
      {
        id: 1,
        title: 'May',
        year: 2021,
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'xls',
      },
      {
        id: 2,
        title: 'May',
        year: 2021,
        coverTitle: 'Statistik Bülleten',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
      {
        id: 3,
        title: 'Aprel',
        year: 2021,
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'xls',
      },
      {
        id: 4,
        title: 'Aprel',
        year: 2021,
        coverTitle: 'Statistik Bülleten',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
    ],
  },
];
export const macroEconomyData = {
  id: 1,
  title: 'Makroiqtisadi statistika',
  files: [
    {
      id: 1,
      title: 'Əsas Makroiqtisadi göstəricilər (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
    {
      id: 2,
      title: 'Qiymət indekslərinin dəyişməsi (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
    {
      id: 3,
      title: 'Azərbaycan Respublikasının Dövlət Büdcəsinin əsas göstəriciləri (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
    {
      id: 4,
      title: 'Azərbaycan Respublikasının tədiyə balansı (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
    {
      id: 5,
      title: 'Azərbaycan Respublikasının xarici ticarəti (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
    {
      id: 6,
      title: 'Manatın xarici valyutalara nisbətən nominal və real effektiv məzənnəsi (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
  ],
};
export const monetaryStatisticsData = {
  id: 1,
  title: 'Pul-kredit statistikası',
  files: [
    {
      id: 1,
      title: 'Pul icmalı (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
    {
      id: 2,
      title: 'AMB-nin analitik balansı (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
    {
      id: 3,
      title: 'Kommersiya banklarının analitik balansı (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
    {
      id: 4,
      title: 'Pul aqreqatları (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
    {
      id: 5,
      title: 'Pul bazası (dövrün sonuna) (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
    {
      id: 6,
      title:
        'İqtisadiyyata kredit qoyuluşlarının kredıt təşkilatları üzrə strukturu (dövrün sonuna) (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
  ],
};
export const externalSectorData = [
  {
    id: 1,
    title: '2025',
    files: [
      {
        id: 1,
        title: '2025-ci ilin I rübü üzrə Azərbaycan Respublikasının tədiyə balansı',
        year: 2025,
        coverTitle: '2025-ci ilin I rübü üzrə Tədiyə balansı',
        web_url: 'https://uploads.cbar.az/assets/71d4da94ec6df159561b1a2b7.pdf',
        file_url: 'https://uploads.cbar.az/assets/71d4da94ec6df159561b1a2b7.pdf',
        type: 'pdf',
      },
      {
        id: 2,
        title: '2025-ci ilin I rübü üzrə Azərbaycan Respublikasının tədiyə balansı',
        year: 2025,
        file_url: 'https://uploads.cbar.az/assets/6c3b38e4e89e280968c2cf43a.xlsx',
        type: 'xlsx',
      },
      {
        id: 3,
        title: '2025-ci ilin I rübü üzrə fiziki şəxslərin pul baratları barədə məlumat',
        year: 2025,
        file_url: 'https://uploads.cbar.az/assets/e558ab70145e31c5d3959a447.xlsx',
        type: 'xlsx',
      },
    ],
  },
  {
    id: 2,
    title: '2024',
    files: [
      {
        id: 1,
        title: '2024-cü ilin yekunu üzrə Azərbaycan Respublikasının tədiyə balansı',
        year: 2024,
        coverTitle: '2024-cü il üzrə Tədiyə balansı',
        web_url: 'https://uploads.cbar.az/assets/ccaf18d68b8d6fbc2196c86a2.pdf',
        file_url: 'https://uploads.cbar.az/assets/ccaf18d68b8d6fbc2196c86a2.pdf',
        type: 'pdf',
      },
      {
        id: 2,
        title:
          '2024-cü ilin yekunu üzrə Azərbaycan iqtisadiyyatına cəlb olunmuş və xarici iqtisadiyyata yönəldilmiş birbaşa xarici investisiyalar',
        year: 2024,
        file_url: 'https://uploads.cbar.az/assets/6d837b66ca2b90f122ca93d0f.xlsx',
        type: 'xlsx',
      },
      {
        id: 3,
        title: '2024-cü ilin 9 ayı üzrə Azərbaycan Respublikasının tədiyə balansı',
        year: 2024,
        coverTitle: '2024-cü ilin 9 ayı üzrə Tədiyə balansı',
        web_url: 'https://uploads.cbar.az/assets/89453aa3f1dae9599248c0818.pdf',
        file_url: 'https://uploads.cbar.az/assets/89453aa3f1dae9599248c0818.pdf',
        type: 'pdf',
      },
      {
        id: 4,
        title:
          '2024-cü ilin 9 ayı üzrə Azərbaycan iqtisadiyyatına cəlb olunmuş və xarici iqtisadiyyata yönəldilmiş birbaşa xarici investisiyalar',
        year: 2024,
        file_url: 'https://uploads.cbar.az/assets/e545504a22de49ede96600dc8.xlsx',
        type: 'xlsx',
      },
    ],
  },
];

export const paymentStatisticsData = {
  id: 1,
  title: 'Ödəniş sistemlərinin statistikası',
  files: [
    {
      id: 1,
      title: 'Milli Ödəniş Sistemləri üzrə əməliyyatlar (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/8b94db78d5397b86e3e91f5b6.xlsx',
      type: 'xls',
    },
    {
      id: 2,
      title:
        'Milli Ödəniş Sistemləri vasitəsilə aparılan ödəniş əməliyyatlarının iştirakçılar üzrə bölgüsü (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/3d9684d665c3f2eda1afac5b4.xlsx',
      type: 'xls',
    },
    {
      id: 3,
      title: 'Statistik vahidə məxsus ödəniş xidməti şəbəkəsi (dövrün sonuna) (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/f3ee27c9f9383b567704ebeaf.xlsx',
      type: 'xls',
    },
    {
      id: 4,
      title:
        'Statistik vahidə məxsus ödəniş xidməti şəbəkəsinin iqtisadi rayonlar üzrə statistikası (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/1af28e79f1d3b1cd6ae801426.xlsx',
      type: 'xls',
    },
    {
      id: 5,
      title: 'Debet və kredit kartları ilə aparılan əməliyyatlar (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/790aacbd78f4ad80287ff7360.xlsx',
      type: 'xls',
    },
    {
      id: 6,
      title: 'Ödəniş kartları və terminallardan istifadə göstəriciləri (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/9347497631ca6e8aa61eed6b9.xlsx',
      type: 'xls',
    },
  ],
};

export const dataRevisionPolicy = {
  title: 'Məlumatların reviziyası siyasəti',
  content:
    'Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum quae veritatis error voluptas consectetur tempora rerum dolorem nobis esse est magni modi, quidem eveniet perferendis maxime velit, repellat libero possimus commodi sequi quo quis numquam nesciunt? Ipsam repudiandae magni architecto sed! Quo pariatur adipisci consequuntur itaque rem distinctio dicta facilis.',
};

export const methodologyData = {
  id: 1,
  title: 'Metodologiya',
  files: [
    {
      id: 1,
      title: 'Tədiyə Balansının tərtibi haqqında metodoloji izahat',
      web_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
      file_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: 'Nominal və Real Effektiv Məzənnənin hesablanması metodologiyası',
      web_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
      file_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
      type: 'pdf',
    },
  ],
};

export const releaseScheduleData = {
  title: 'Statistik hesabatların yayımlanması qrafiki',
  files: [
    {
      id: 1,
      title: 'Statistik hesabatların yayımlanması qrafiki',
      web_url: 'https://uploads.cbar.az/assets/b1a53281f8baf50f60269c1bc.pdf',
      file_url: 'https://uploads.cbar.az/assets/b1a53281f8baf50f60269c1bc.pdf',
      type: 'pdf',
    },
  ],
  tableData: [
    {
      id: 1,
      title: 'Əsas makroiqtisadi göstəricilər',
      rows: [
        {
          id: 1,
          name: 'Əsas makroiqtisadi göstəricilər',
          period: 'Hesabat dövründən sonrakı 30 gün ərzində',
        },
        {
          id: 2,
          name: 'Qiymət indekslərinin dəyişməsi',
          period: 'Hesabat dövründən sonrakı 30 gün ərzində',
        },
        {
          id: 3,
          name: 'Azərbaycan Respublikasının Dövlət büdcəsinin əsas göstəriciləri',
          period: 'Hesabat dövründən sonrakı 30 gün ərzində',
        },
      ],
    },
    {
      id: 2,
      title: 'Əsas pul - kredit göstəriciləri',
      rows: [
        {
          id: 1,
          name: 'Pul icmalı',
          period: 'Hesabat dövründən sonrakı 30 gün ərzində',
        },
        {
          id: 2,
          name: 'AMB - nin analitik balansı',
          period: 'Hesabat dövründən sonrakı 30 gün ərzində',
        },
        {
          id: 3,
          name: 'Kommersiya banklarının analitik balansı',
          period: 'Hesabat dövründən sonrakı 30 gün ərzində',
        },
      ],
    },
    {
      id: 3,
      title: 'Xarici sektorun statistikası',
      rows: [
        {
          id: 1,
          name: 'Azərbaycan Respublikasının tədiyə balansı',
          period: 'Hesabat dövründən sonrakı 30 gün ərzində',
        },
        {
          id: 2,
          name: 'Fiziki şəxslərin pul baratları barədə məlumat',
          period: 'Hesabat dövründən sonrakı 30 gün ərzində',
        },
        {
          id: 3,
          name: 'Azərbaycan iqtisadiyyatına cəlb olunmuş və xarici iqtisadiyyata yönəldilmiş birbaşa xarici investisiyalar',
          period: 'Hesabat dövründən sonrakı 30 gün ərzində',
        },
      ],
    },
    {
      id: 4,
      title: 'Maliyyə Bazarı',
      subcategories: [
        {
          id: 1,
          title: 'Kredit təşkilatları',
          subcategories: [
            {
              id: 1,
              title: 'Bank icmalı',
              rows: [
                {
                  id: 1,
                  name: 'Bank sektorunun əsas göstəriciləri',
                  period: 'Hesabat dövründən sonrakı 30 gün ərzində',
                },
              ],
            },
          ],
        },
        {
          id: 2,
          title: 'BOKT və kredit ittifaqları icmalı',
          rows: [
            {
              id: 1,
              name: 'Bank olmayan kredit təşkilatları üzrə əsas göstəricilər',
              period: 'Hesabat dövründən sonrakı 30 gün ərzində',
            },
          ],
          subcategories: [
            {
              id: 1,
              title: 'İstehlak kreditlərinin orta faiz dərəcələri ',
              rows: [
                {
                  id: 1,
                  name: 'İstehlak kreditləri üzrə orta faiz dərəcələri',
                  period: 'Hesabat dövründən sonrakı 30 gün ərzində',
                },
              ],
            },
            {
              id: 2,
              title: 'Biznes portfelinin təminatlılığı ',
              rows: [
                {
                  id: 1,
                  name: 'Bankların biznes subyektləri üzrə kredit portfelinin təminatlılığının bölgüsü',
                  period: 'Hesabat dövründən sonrakı 30 gün ərzində',
                },
              ],
            },
          ],
        },
        {
          id: 3,
          title: 'Sığorta',
          subcategories: [
            {
              id: 1,
              title: 'Sığortaçılar üzrə ',
              rows: [
                {
                  id: 1,
                  name: 'Sığorta şirkətləri üzrə sığorta haqları və sığorta ödənişləri',
                  period: 'Hesabat dövründən sonrakı 30 gün ərzində',
                },
              ],
            },
            {
              id: 2,
              title: 'Siniflər üzrə',
              rows: [
                {
                  id: 1,
                  name: 'Sığorta növləri üzrə sığorta haqları və sığorta ödənişləri',
                  period: 'Hesabat dövründən sonrakı 30 gün ərzində',
                },
              ],
            },
          ],
        },
        {
          id: 4,
          title: 'Kapital bazarı',
          rows: [
            {
              id: 1,
              name: 'Mərkəzi Bankın likvidliyin idarə edilməsi üzrə əməliyyatlarının həcmi və faiz dərəcələri',
              period: 'Hesabat dövründən sonrakı 30 gün ərzində',
            },
            {
              id: 2,
              name: 'Dövlət istiqrazları',
              period: 'Hesabat dövründən sonrakı 30 gün ərzində',
            },
            {
              id: 3,
              name: 'Mərkəzi Bankın notları',
              period: 'Hesabat dövründən sonrakı 30 gün ərzində',
            },
            {
              id: 4,
              name: 'Dövlət qiymətli kağızlar bazarı üzrə əsas göstəricilər',
              period: 'Hesabat dövründən sonrakı 30 gün ərzində',
            },
          ],
        },
      ],
    },
    {
      id: 5,
      title: 'Ödəniş sistemləri',
      rows: [
        {
          id: 1,
          name: 'Milli Ödəniş Sistemləri üzrə əməliyyatlar',
          period: 'Hesabat dövründən sonrakı 30 gün ərzində',
        },
        {
          id: 2,
          name: 'Milli Ödəniş Sistemləri vasitəsilə aparılan ödəniş əməliyyatlarının iştirakçılar üzrə bölgüsü',
          period: 'Hesabat dövründən sonrakı 30 gün ərzində',
        },
        {
          id: 3,
          name: 'Bankomatlar və Pos-terminallar',
          period: 'Hesabat dövründən sonrakı 30 gün ərzində',
        },
      ],
    },
  ],
};
export const nsdpData = {
  id: 1,
  title: 'Statistical Data for NSDP',
  files: [
    {
      id: 1,
      title: 'Official average exchange rates of manat, nominal and real effective exchange rates',
      web_url: 'https://uploads.cbar.az/assets/Exchange_rates_Aze.xml',
      file_url: 'https://uploads.cbar.az/assets/Exchange_rates_Aze.xml',
      type: 'xml',
    },
    {
      id: 2,
      title: 'Official average exchange rates of manat, nominal and real effective exchange rates',
      file_url: 'https://uploads.cbar.az/assets/Exchange_rates_Aze.xlsx',
      type: 'xls',
    },
    {
      id: 3,
      title:
        'CBA`s liquidity management - volume and interest rates, average interest rates on deposits and loans',
      web_url: 'https://uploads.cbar.az/assets/Interest_rates_Aze.xml',
      file_url: 'https://uploads.cbar.az/assets/Interest_rates_Aze.xml',
      type: 'xml',
    },
    {
      id: 4,
      title:
        'CBA`s liquidity management - volume and interest rates, average interest rates on deposits and loans',
      file_url: 'https://uploads.cbar.az/assets/Interest_rates_Aze.xlsx',
      type: 'xls',
    },
  ],
};

export const creditInstitutionData = [
  {
    id: 1,
    title: 'Bank icmalı',
    filesData: [
      {
        id: 1,
        title: '2025-ci il üzrə bank icmalı',
        files: [
          {
            id: 1,
            title: 'Maliyyə bazarlarının iştirakçıları haqqında ümumi məlumat (25.06.2025)',
            file_url: 'https://uploads.cbar.az/assets/2a5ee4681475918905302ecf4.xlsx',
            type: 'xlsx',
          },
          {
            id: 2,
            title: 'Bank sektorunun icmal balansı (25.06.2025)',
            file_url: 'https://uploads.cbar.az/assets/30d41fd6c5b92214c7fc8e569.xlsx',
            type: 'xlsx',
          },
        ],
      },
      {
        id: 2,
        title: '2024-ci il üzrə bank icmalı',
        files: [
          {
            id: 1,
            title: 'Maliyyə bazarlarının iştirakçıları haqqında ümumi məlumat (30.01.2025)',
            file_url: 'https://uploads.cbar.az/assets/74dd86d36b0727b9b58af1189.xlsx',
            type: 'xlsx',
          },
          {
            id: 2,
            title: 'Bank sektorunun icmal balansı (30.01.2025)',
            file_url: 'https://uploads.cbar.az/assets/78029cd1251f0e337e27e69b1.xlsx',
            type: 'xlsx',
          },
        ],
      },
    ],
  },
  {
    id: 2,
    title: 'BOKT və kredit ittifaqları icmalı',
    filesData: [
      {
        id: 1,
        title: '2025-ci il üzrə BOKT icmalı',
        files: [
          {
            id: 1,
            title:
              'Bank olmayan kredit təşkilatları və Poçt rabitəsinin milli operatoru haqqında ümumi məlumat (28.04.2025)',
            file_url: 'https://uploads.cbar.az/assets/f3f5b11827d1a25c3940af17a.xlsx',
            type: 'xlsx',
          },
          {
            id: 2,
            title: 'Bank olmayan kredit təşkilatlarının icmal balansı (28.04.2025)',
            file_url: 'https://uploads.cbar.az/assets/722d453c984b6f04e06b39601.xlsx',
            type: 'xlsx',
          },
        ],
      },
      {
        id: 2,
        title: '2024-ci il üzrə BOKT icmalı',
        files: [
          {
            id: 1,
            title:
              'Bank olmayan kredit təşkilatları və Poçt rabitəsinin milli operatoru haqqında ümumi məlumat (30.01.2025)',
            file_url: 'https://uploads.cbar.az/assets/810db66141686bf4deadfef22.xlsx',
            type: 'xlsx',
          },
          {
            id: 2,
            title: 'Bank olmayan kredit təşkilatlarının icmal balansı (30.01.2025)',
            file_url: 'https://uploads.cbar.az/assets/43e48a9b4effc6386d59ae4c6.xlsx',
            type: 'xlsx',
          },
        ],
      },
    ],
  },
  {
    id: 3,
    title: 'İstehlak kreditlərinin orta faiz dərəcələri',
    subCategories: [
      {
        id: 1,
        title: 'Banklar',
        files: [
          {
            id: 1,
            title: '31 mart 2025-ci il tarixinə istehlak kreditləri üzrə orta faiz dərəcələri',
            web_url: 'https://uploads.cbar.az/assets/519a96efc84643ddaaabe42cf.pdf',
            file_url: 'https://uploads.cbar.az/assets/519a96efc84643ddaaabe42cf.pdf',
            type: 'pdf',
          },
          {
            id: 2,
            title: '31 dekabr 2024-cü il tarixinə istehlak kreditləri üzrə orta faiz dərəcələri',
            web_url: 'https://uploads.cbar.az/assets/123805623f7ee179af40e39b0.pdf',
            file_url: 'https://uploads.cbar.az/assets/123805623f7ee179af40e39b0.pdf',
            type: 'pdf',
          },
        ],
      },
      {
        id: 2,
        title: 'Bank olmayan kredit təşkilatları',
        files: [
          {
            id: 1,
            title:
              'BOKT sektorunun milli valyutada istehlak kreditləri üzrə orta faiz dərəcəsi - (31.03.2025)',
            web_url: 'https://uploads.cbar.az/assets/7697d9c9374d8b5b2d88b6d84.pdf',
            file_url: 'https://uploads.cbar.az/assets/7697d9c9374d8b5b2d88b6d84.pdf',
            type: 'pdf',
          },
          {
            id: 2,
            title:
              'BOKT sektorunun milli valyutada istehlak kreditləri üzrə orta faiz dərəcəsi - (31.12.2024)',
            web_url: 'https://uploads.cbar.az/assets/db6514e3912e53e2698d0fb03.pdf',
            file_url: 'https://uploads.cbar.az/assets/db6514e3912e53e2698d0fb03.pdf',
            type: 'pdf',
          },
        ],
      },
    ],
  },
  {
    id: 4,
    title: 'Biznes portfelinin təminatlılığı',
    files: [
      {
        id: 1,
        title:
          'Bankların biznes subyektləri üzrə kredit portfelinin təminatlılığının bölgüsü - mart 2025',
        web_url: 'https://uploads.cbar.az/assets/21dd85103766d2e1296ae4b32.pdf',
        file_url: 'https://uploads.cbar.az/assets/21dd85103766d2e1296ae4b32.pdf',
        type: 'pdf',
      },
      {
        id: 2,
        title:
          'Bankların biznes subyektləri üzrə kredit portfelinin təminatlılığının bölgüsü - dekabr 2024',
        web_url: 'https://uploads.cbar.az/assets/cbed4e7a1dbf98b8fa85c3e3f.pdf',
        file_url: 'https://uploads.cbar.az/assets/cbed4e7a1dbf98b8fa85c3e3f.pdf',
        type: 'pdf',
      },
    ],
  },
];
export const insuranceData = [
  {
    id: 1,
    title: 'Sığortaçılar üzrə',
    filesData: [
      {
        id: 1,
        title: '2025-ci il üzrə sığorta icmalı',
        files: [
          {
            id: 1,
            title:
              '2025-ci ilin yanvar-may ayları üzrə hesablanmış sığorta haqları və sığorta ödənişləri',
            file_url: 'https://uploads.cbar.az/assets/83a32b6f758977e4cf77f00bc.xlsx',
            type: 'xlsx',
          },
        ],
      },
      {
        id: 2,
        title: '2024-ci il üzrə sığorta icmalı',
        files: [
          {
            id: 1,
            title:
              '2024-cü ilin yanvar-dekabr ayları üzrə hesablanmış sığorta haqları və sığorta ödənişləri',
            file_url: 'https://uploads.cbar.az/assets/69c5e658b1a2888cf1d5d5cda.xlsx',
            type: 'xlsx',
          },
        ],
      },
    ],
  },
  {
    id: 2,
    title: 'Siniflər üzrə',
    filesData: [
      {
        id: 1,
        title: '2025-ci il üzrə sığorta icmalı',
        files: [
          {
            id: 1,
            title:
              '2025-ci ilin yanvar-may ayları üzrə hesablanmış sığorta haqları və sığorta ödənişləri',
            file_url: 'https://uploads.cbar.az/assets/83a32b6f758977e4cf77f00bc.xlsx',
            type: 'xlsx',
          },
        ],
      },
      {
        id: 2,
        title: '2024-ci il üzrə sığorta icmalı',
        files: [
          {
            id: 1,
            title:
              '2024-cü ilin yanvar-dekabr ayları üzrə hesablanmış sığorta haqları və sığorta ödənişləri',
            file_url: 'https://uploads.cbar.az/assets/69c5e658b1a2888cf1d5d5cda.xlsx',
            type: 'xlsx',
          },
        ],
      },
    ],
  },
];
export const capitalMarketData = {
  id: 1,
  title: 'Kapital bazarı',
  files: [
    {
      id: 1,
      title:
        'Mərkəzi Bankın monetar əməliyyatlarının həcmi və faiz dərəcələri (dövrün sonuna) (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/da769ae89dd3ae6336feac2b6.xlsx',
      type: 'xls',
    },
    {
      id: 2,
      title: 'Dövlət istiqrazları (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/15eccb555e6eef6be6c614015.xlsx',
      type: 'xls',
    },
    {
      id: 3,
      title: 'Mərkəzi Bankın notları (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/8224f8009a22d0bf9e56ca637.xlsx',
      type: 'xls',
    },
    {
      id: 4,
      title: 'Qiymətli kağızlar bazarı üzrə əsas göstəricilər (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/deeaa533f7ad48ce249b1ef8f.xlsx',
      type: 'xls',
    },
  ],
  filesData: [
    {
      id: 1,
      title: '2025-ci il üzrə qiymətli kağızlar bazarının əsas göstəriciləri',
      files: [
        {
          id: 1,
          title: '31 mart 2025-ci il tarixinə qiymətli kağızlar bazarının əsas göstəriciləri',
          web_url: 'https://uploads.cbar.az/assets/f63d21fe88d33da1cb3961092.pdf',
          file_url: 'https://uploads.cbar.az/assets/f63d21fe88d33da1cb3961092.pdf',
          type: 'pdf',
        },
      ],
    },
    {
      id: 2,
      title: '2024-ci il üzrə qiymətli kağızlar bazarının əsas göstəriciləri',
      files: [
        {
          id: 1,
          title: '31 dekabr 2024-cü il tarixinə qiymətli kağızlar bazarının əsas göstəriciləri',
          web_url: 'https://uploads.cbar.az/assets/d2d61a3c22d5e89027de9a249.pdf',
          file_url: 'https://uploads.cbar.az/assets/d2d61a3c22d5e89027de9a249.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title: '30 sentyabr 2024-cü il tarixinə qiymətli kağızlar bazarının əsas göstəriciləri',
          web_url: 'https://uploads.cbar.az/assets/de5b2098d2d5f80c8a26fabb1.pdf',
          file_url: 'https://uploads.cbar.az/assets/de5b2098d2d5f80c8a26fabb1.pdf',
          type: 'pdf',
        },
        {
          id: 3,
          title: '30 iyun 2024-cü il tarixinə qiymətli kağızlar bazarının əsas göstəriciləri',
          web_url: 'https://uploads.cbar.az/assets/257b2f3daddae891b9b0fc34b.pdf',
          file_url: 'https://uploads.cbar.az/assets/257b2f3daddae891b9b0fc34b.pdf',
          type: 'pdf',
        },
        {
          id: 4,
          title: '31 mart 2024-cü il tarixinə qiymətli kağızlar bazarının əsas göstəriciləri',
          web_url: 'https://uploads.cbar.az/assets/f8249d387229e502db5084641.pdf',
          file_url: 'https://uploads.cbar.az/assets/f8249d387229e502db5084641.pdf',
          type: 'pdf',
        },
      ],
    },
  ],
};
