import manat1 from '../images/1manat_on.jpg'
import manat5 from '../images/5manat_on.jpg'
import manat10 from '../images/10manat_on.jpg'
import qepik10 from '../images/qepik10.png'
import qepik20 from '../images/qepik20.png'
import qepik50 from '../images/qepik50.png'

export const currencyCirculation = {
  text: 'Azərbaycan Respublikasının Prezidentinin 7 fevral 2005-ci il tarixli “Azərbaycan Respublikasında pul nişanlarının nominal dəyərinin və qiymətlər miqyasının dəyişdirilməsi (denominasiyası) haqqında” Fərmanına uyğun olaraq 2006-cı ildən etibarən 1 yeni manat 5000 manata bərabər tutulmaqla denominasiya həyata keçirilmiş, tədavülə yeni nəsil pul nişanları (AZN) buraxılmışdır.',
  paperMoneys: [
    {
      id: 1,
      slug:"kagiz-pul",
      topic:"Mədəniyyət və incəsənət",
      title:"1 AZN",
      releaseDate:"(2006 il)",
      image:manat1
    },
    {
      id: 2,
      slug:"kagiz-pul",
      topic:"Yazı və ədəbiyyat",
      title:"5 AZN",
      releaseDate:"(2006 il)",
      image:manat5
    },
    {
      id: 3,
      slug:"kagiz-pul",
      topic:"Tarix",
      title:"10 AZN",
      releaseDate:"(2006 il)",
      image:manat10
    },
  ],
  metalMoneys: [
    {
      id: 1,
      slug:"metal-pul",
      image:qepik20
    },
    {
      id: 2,
      slug:"metal-pul",
      image:qepik10
    },
    {
      id: 3,
      slug:"metal-pul",
      image:qepik50
    },
  ],
};
