import {
  internationalEvent1,
  internationalEvent2,
  internationalEvent3,
  internationalEvent4,
  internationalEvent5,
  internationalEvent6,
  internationalEvent7,
  internationalEvent8,
  internationalEvent9,
  internationalEvent10,
} from './images';

export const internationalCooperation = {
  title: 'Beynəlxalq əməkdaşlıq',
  content:
    'Qlobal iqtisadi qarşılıqlı asılılığın artması və dünya iqtisadiyyatının üzləşdiyi çağırışlar şəraitində beynəlxalq təşkilatlar və digər mərkəzi banklarla əməkdaşlıq xarici iqtisadi şokların və sistem risklərinin əlaqələndirilmiş şəkildə idarə olunmasına kömək edir. Azərbaycan Respublikasının Mərkəzi Bankı da (ARMB) fəaliyyətinin müasir tələblərə uyğun səmərəli təşkili və mərkəzi bankçılığın bütün funksional istiqamətləri üzrə beynəlxalq standartların tətbiqi məqsədilə beynəlxalq təşkilatlar, digər ölkələrin mərkəzi bankları və nəzarət qurumları ilə əməkdaşlığa mühüm əhəmiyyət verir. ARMB fəaliyyəti çərçivəsində beynəlxalq və regional forumlarda aktiv iştirak edərək qlobal maliyyə sabitliyi və beynəlxalq maliyyə tənzimləmə islahatları ilə bağlı müzakirələrə töhfə verir.',
};

export const withOrganizations = {
  title: 'Beynəlxalq təşkilatlarla əməkdaşlıq',
  content:
    'Beynəlxalq Valyuta Fondu. Azərbaycan Beynəlxalq Valyuta Fonduna (BVF) 18 sentyabr 1992-ci ildə üzv olmuşdur. Azərbaycan Mərkəzi Bankının (AMB) Sədri BVF-də Azərbaycan üzrə əvəzedici müdirdir.BVF tərəfindən Azərbaycana aşağıdakı proqramlar həyata keçirilmışdır:Yoxsulluğun azaldılması və iqtisadi inkişaf;Struktur quruculuğunun artırılması;Sistem dəyişikliyi;Əlavə maliyyələşmə proqramları. BVF-nin ekspertlərinin AMB-yə mütəmadi səfərləri təşkil edilir. Bu səfərlər zamanı qısa müddətdə inflyasiyanın səviyyəsini azaltmaq və orta müddətdə inflyasiya proqnozlarının sabitləşdirilməsi üçün Mərkəzi Bankın apardığı siyasətlər, məzənnə və faiz dərəcəsi siyasəti, müdaxilə və sterilizasiya, manatla pul bazasının artımı, valyuta ehtiyatlarının diversifikasiya planları və digər məsələlər barədə BVF ekspertləri ilə müzakirələr aparılır.',
};
export const withCentralBanks = {
  title: 'Mərkəzi banklarla əməkdaşlıq',
  content:
    'ARMB beynəlxalq arenada fəal rol oynamaq məqsədilə öz fəaliyyəti çərçivəsində xarici ölkələrin mərkəzi bankları, maliyyə bazarlarına nəzarət orqanları, rezolyusiya orqanları ilə ikitərəfli formatda sıx əməkdaşlıq edir. Bu çərçivədə ARMB sözügedən qurumlar ilə Anlaşma Memorandumları imzalayaraq texniki əməkdaşlıq və yüksək səviyyəli dialoq fəaliyyəti həyata keçirir. Bu Memorandumların əsas məqsədi monetar siyasət, maliyyə sektoru, ödəniş sistemləri, maliyyə texnologiyaları sahəsində əməkdaşlıq edilməsi, təcrübə və məlumat mübadiləsinin aparılması, aktual məsələlərin müzakirəsi, təlim, internatura proqramları və seminarların keçirilməsi, texniki məsləhətlərin verilməsi məqsədilə araşdırma və tədqiqat xarakterli səfərlərin təşkilindən ibarətdir.',
  banks: [
    {
      id: 1,
      title: 'Gürcüstan Milli Bankı',
      date: 'mart 2025',
    },
    {
      id: 2,
      title: 'Özbəkistan Mərkəzi Bankı',
      date: 'iyul 2024',
    },
    {
      id: 3,
      title: 'Qırğız Respublikasının Milli Bankı',
      date: 'may 2024',
    },
    {
      id: 4,
      title: 'Belarus Milli Bankı',
      date: 'aprel 2024',
    },
    {
      id: 5,
      title: 'Qazaxıstan Milli Bankı',
      date: 'iyun 2023',
    },
    {
      id: 6,
      title: 'Tacikistan Milli Bankı ',
      date: 'aprel 2023',
    },
    {
      id: 7,
      title: 'Çin Xalq Respublikasının Bank və Sığorta Tənzimləmə Komissiyası ',
      date: 'oktyabr 2022',
    },
    {
      id: 8,
      title: 'Türkiyə Respublikası Prezidenti Administrasiyasının Maliyyə Ofisi ',
      date: 'mart 2022',
    },
    {
      id: 9,
      title: 'Türkiyə Kapital Bazarları Şurası ',
      date: 'aprel 2021',
    },
    {
      id: 10,
      title: 'Türkiyə Sığorta və Özəl Pensiya tənzimlənməsi və nəzarəti Agentliyi ',
      date: 'mart 2021',
    },
    {
      id: 11,
      title: 'Türkiyə Respublikasının Mərkəzi Bankı ',
      date: 'dekabr 2020',
    },
    {
      id: 12,
      title: 'İtaliya Respublikasının Milli Mikrokredit Agentliyi ',
      date: 'fevral 2020',
    },
    {
      id: 13,
      title: 'İran İslam Respublikasının Mərkəzi Bankı ',
      date: 'avqust 2016',
    },
    {
      id: 14,
      title: 'Rusiya Federasiyasının Mərkəzi Bankı ',
      date: 'dekabr 2006',
    },
    {
      id: 15,
      title: 'Türkiyə Bank Tənzimlənməsi və Nəzarəti Agentliyi ',
      date: 'sentyabr 2005',
    },
    {
      id: 16,
      title: 'Ukrayna Milli Bankı ',
      date: 'mart 2000',
    },
    {
      id: 17,
      title: 'Pakistan İslam Respublikası Mərkəzi Bankı ',
      date: 'aprel 1996',
    },
  ],
};

export const internationalEvents = {
  title: 'Beynəlxalq tədbirlər',
  events: [
    {
      id: 1,
      title:
        'Azərbaycan və Mərkəzi Asiya ölkələrinin mərkəzi (milli) banklarının ödəniş ekspertlərinin regional toplantısı',
      content:
        '13-14 iyun 2024-cü il tarixlərində Azərbaycan Respublikasının Mərkəzi Bankının təşəbbüsü ilə Bakı şəhərində Qazaxıstan, Qırğızıstan, Özbəkistan və Tacikistan mərkəzi banklarının nümayəndələrinin iştirakı ilə regional tədbir təşkil olunub. Bu tədbir çərçivəsində mərkəzi bankların ödəniş sahəsi üzrə ekspertləri arasında təcrübə mübadiləsi baş tutub və qlobal ödəniş trendlərinə dair müzakirələr aparılıb.Tədbir çərçivəsində Azərbaycanın ödəniş sektorunda baş verən yeniliklər, qanunvericilik bazasının təkmilləşdirilməsi, nağdsız ödənişlərdən istifadə trendləri, tətbiq olunan innovativ ödəniş həlləri, fintexlərin ödəniş bazarına cəlb edilməsi, eləcə də Milli Ödəniş Sisteminin əhatəliliyinin genişləndirilməsi istiqamətində həyata keçirilən tədbirlər barədə məlumatlar diqqətə çatdırılıb.',
      images: [
        {
          id: 1,
          image: internationalEvent1,
        },
        {
          id: 2,
          image: internationalEvent2,
        },
        {
          id: 3,
          image: internationalEvent3,
        },
        {
          id: 4,
          image: internationalEvent4,
        },
      ],
    },
    {
      id: 2,
      title: 'Birinci Beynəlxalq Tədqiqat Konfransı',
      content:
        '30 - 31 oktyabr 2014-cü il tarixlərində Bakı şəhərində “İnkişaf etməkdə olan ölkələrdə makroiqtisadi siyasət və maliyyə sabitliyi məsələləri” mövzusunda 1-ci Beynəlxalq Tədqiqat Konfransı keçirilmişdir. Konfransda 15 ölkənin mərkəzi bankları və universitetlərindən 30-a yaxın tanınmış tədqiqatçı, habelə ölkəmizin qabaqcıl ali məktəb, beyin mərkəzlərinin tədqiqatçıları və maliyyə-bank sferasının nümayəndələri iştirak etmişlər.Konfransın əsas məqsədi tədqiqatçılar və siyasətçilər arasında institusional islahatlar, makroiqtisadi və maliyyə siyasəti çərçivəsi, həmçinin böhrandan sonrakı dövrdə maliyyə sabitliyi məsələləri də daxil olmaqla inkişaf edən iqtisadi sistemlərdə rast gəlinən çağırışlar ətrafında interaktiv müzakirələrin təşkil edilməsindən ibarət olmuşdur.',
      images: [
        {
          id: 1,
          image: internationalEvent5,
        },
        {
          id: 2,
          image: internationalEvent6,
        },
        {
          id: 3,
          image: internationalEvent7,
        },
        {
          id: 4,
          image: internationalEvent8,
        },
        {
          id: 5,
          image: internationalEvent9,
        },
        {
          id: 6,
          image: internationalEvent10,
        },
      ],
    },
  ],
};
export const membershipData = {
  title: 'Beynəlxalq təşkilatlarda üzvlük',
  organizations: [
    {
      id: 1,
      title: 'Berlin Qrup üzrə Açıq Maliyyə İşçi Qrupu',
      date: '2025',
    },
    {
      id: 2,
      title: 'Qlobal Maliyyə İnnovasiyaları Şəbəkəsi',
      date: '2025',
    },
    {
      id: 3,
      title:
        'Beynəlxalq Qiymətli Kağızlar Komissiyaları Təşkilatının “Artım və inkişaf etməkdə olan bazarlar Komitəsi”',
      date: '2024',
    },
    {
      id: 4,
      title: 'Beynəlxalq Pul Nişanları Assosiasiyası',
      date: '2022',
    },
    {
      id: 5,
      title: 'Dayanıqlı Bankçılıq və Maliyyə Şəbəkəsi',
      date: '2022',
    },
    {
      id: 6,
      title: 'Beynəlxalq Qiymətli Kağızlar Komissiyaları Təşkilatı ',
      date: '2020',
    },
    {
      id: 7,
      title: 'Beynəlxalq Sığorta Nəzarəti Qurumları Assosiasiyası ',
      date: '2020',
    },
    {
      id: 8,
      title: 'Bazel Komitəsinin Bazel Konsultativ Qrupu',
      date: '2020',
    },
    {
      id: 9,
      title:
        'MDB-yə üzv dövlətlərin qiymətli kağızlar bazarının tənzimlənməsi üzrə səlahiyyətli orqanlarının rəhbərləri Şurası ',
      date: '2020',
    },
    {
      id: 10,
      title: 'Maliyyə Savadlılığı üzrə Beynəlxalq Şəbəkə',
      date: '2011',
    },
    {
      id: 11,
      title: 'Pulların Saxtalaşdırılmasına qarşı Mərkəzi Banklar Qrupu ',
      date: '2005',
    },
    {
      id: 12,
      title: 'Mərkəzi Asiya, Qara Dəniz Regionu və Balkan ölkələrinin Mərkəzi Bank Sədrləri Klubu',
      date: '1997',
    },
  ],
};
