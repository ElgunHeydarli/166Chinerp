export const openBanking = {
  title: 'Açıq bankçılıq',
  content:
    'Ənənəvi bankçılıq sistemlərində müştərilərin hesab məlumatlarına giriş hüququ yalnız onların banklarına məxsusdur.',
  files: [
    {
      id: 1,
      title: 'Açıq bankçılıq üzrə istifadə təlimatı',
      web_url: 'https://uploads.cbar.az/assets/7ceb34db48ce13c301f5447ae.pdf',
      file_url: 'https://uploads.cbar.az/assets/7ceb34db48ce13c301f5447ae.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: 'Açıq bankçılığın tətbiqi üzrə yol xəritəsi',
      web_url: 'https://uploads.cbar.az/assets/d56a662a8509f656d6baecc2c.pdf',
      file_url: 'https://uploads.cbar.az/assets/d56a662a8509f656d6baecc2c.pdf',
      type: 'pdf',
    },
  ],
};
export const editingMode = {
  title: 'Xüsusi tənzimləmə rejimi',
  content:
    'Xüsusi tənzimləmə rejimi – innovativ maliyyə məhsul və xidmətlərinin real mühitə bənzər şəraitdə, lakin məhdud miqyasda və nəzarət altında sınaqdan keçirilməsinə imkan verən tənzimləyici çərçivədir. Azərbaycan Respublikasının Mərkəzi Bankı tərəfindən tətbiq olunan bu rejim, maliyyə texnologiyaları (fintex) sahəsində innovasiyaların təşviq olunması, istehlakçı hüquqlarının qorunması və maliyyə sabitliyinin təmin edilməsi məqsədi daşıyır.',
};
export const kyc = {
  title: 'Paylanılmış Öz Müştərini Tanı (EKYC) platforması',
  content:
    '“Maliyyə sektorunun inkişaf Strategiyası”nın tədbirlər planına uyğun olaraq maliyyə sektorunda “Öz müştərini tanı” yanaşmasının effektiv tətbiq edilməsi məqsədilə “Paylanılmış - Öz müştərini tanı” platformasının (bundan sonra Paylanılmış EKYC) yaradılması nəzərdə tutulmuşdur. ',
};
export const virtualAssets = {
  title: 'Virtual Aktivlər',
  content:
    'Virtual aktivlər və bu sahədə fəaliyyət göstərən xidmət təminatçılarının fəaliyyəti son illərdə qlobal miqyasda sürətlə genişlənməkdədir. Bu inkişaf bir tərəfdən maliyyə texnologiyalarında innovasiyalara təkan verir, digər tərəfdən isə maliyyə sabitliyi, investor müdafiəsi və şəffaflıq baxımından yeni çağırışlar yaradır.',
};
export const digitalCurrency = {
  title: 'Mərkəzi Bankın Rəqəmsal Valyutası (MBRV)',
  content:
    'Mərkəzi Bank Rəqəmsal Valyutası (MBRV), Mərkəzi Bank tərəfindən buraxılan və milli valyutanın rəqəmsal forması kimi fəaliyyət göstərən yeni nəsil ödəniş vasitəsidir. Ənənəvi nağd pullardan fərqli olaraq, MBRV yalnız rəqəmsal formatda mövcuddur və birbaşa Mərkəzi Bankın zəmanəti ilə dövriyyəyə buraxılır.',
};
