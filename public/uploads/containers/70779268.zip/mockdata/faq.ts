export const faqData = {
  title: 'Tez-tez verilən suallar',
  categories: [
    {
      id: 1,
      title: 'Pul siyasəti',
      faqItems: [
        {
          id: 1,
          title: 'Pul siyasəti nədir?',
          description:
            'Pul siyasəti əsasən qiymətlərin sabitliyinin təmin edilməsi məqsədilə həyata keçirilən tədbirlər sistemidir. Mərkəzi Bank valyuta məzənnəsi, pul kütləsi və faiz dərəcələrini tənzimləmək vasitəsilə inflyasiya proseslərinə təsir göstərir. Azərbaycan Respublikasında pul siyasəti Mərkəzi Bank tərəfindən həyata keçirilir.',
        },
        {
          id: 2,
          title: 'İnflyasiya və deflyasiya nədir?',
          description:
            'İnflyasiya mal və xidmətlərin keyfiyətinin yüksəlməməsi halında qiymətlərinin ümumi səviyyəsinin qalxmasıdır. Başqa sözlə desək, inflyasiya mal və xidmətlərin qiymətinin artması ilə müşayiət olunan pulun dəyərsizləşməsi prosesidir. Deflyasiya isə əksinə, mal və xidmətlərin keyfiyətinin azalmaması halında qiymətlərinin ümumi səviyyəsinin aşağı düşməsi və ya pulun dəyərinin artması prosesidir. Ayrıca götürülmüş mal və ya xidmətin qiymətinin dəyişimi inflyasiyanı ifadə etmir. İnflyasiyanı ölçmək üçün adətən “İstehlak Qiymətləri İndeksi”ndən istifadə olunur. Azərbaycanda bu göstərici Dövlət Statistika Komitəsi tərəfindən “istehlak səbəti” əsasında aylıq əsasda hesablanır və ictimaiyyətə təqdim olunur. İstehlak səbətinə bütün zəruri tələbat malları və xidmətləri daxil edilir. Hər bir mal və xidmət istehlak səbətində xüsusi çəkiyə malikdır.',
        },
      ],
    },
    {
      id: 2,
      title: 'Valyuta ehtiyatlarının idarə olunması',
      faqItems: [
        {
          id: 1,
          title: 'Mərkəzi Bankın valyuta ehtiyatlarının idarə olunmasının məqsədləri?',
          description:
            'Valyuta ehtiyatlarının idarə olunmasının məqsədi dövlətin pul və məzənnə siyasətinin həyata keçirilməsi və ölkənin beynəlxalq öhdəlikləri üzrə hesablaşmalarının aparılması üçün valyuta ehtiyatlarının təhlükəsiz və likvid saxlanılması, həmçinin investisiya gəliri əldə edilməsidir.',
        },
        {
          id: 2,
          title: 'Bu ehtiyatlar sosial inkişafda rol oynayırmı?',
          description:
            'Mərkəzi Bankın valyuta ehtiyatları yalnız makroiqtisadi “stabilizator” və “təhlükəsizlik yastığı” funksiyasını həyata keçirir.',
        },
      ],
    },
    {
      id: 3,
      title: 'Kredit təşkilatlarının fəaliyyəti',
      faqItems: [
        {
          id: 1,
          title: 'Banklarda xidmət haqlarının tənzimlənməsi hansı formada həyata keçirilir?',
          description:
            '“Banklar haqqında” Azərbaycan Respublikasının Qanununun 36.6-cı maddəsinə və “Bank olmayan kredit təşkilatları haqqında” Azərbaycan Respublikasının Qanununun 3-cü maddəsinə əsasən, hər bir kredit təşkilatı müştərilərlə bağladığı müqavilədə xidmət şərtlərini, o cümlədən faiz dərəcələrini, komisyon haqlarını və göstərilən xidmətlər üçün digər ödənişləri müəyyən etməkdə sərbəstdir.',
        },
        {
          id: 2,
          title: 'Zaminliyə hansı hallarda xitam verilir?',
          description:
            'Azərbaycan Respublikasının Mülki Məcəlləsinin 477-ci maddəsinə uyğun olaraq zaminliyin təmin etdiyi öhdəliyə xitam verildikdə, habelə zaminin razılığı olmadan həmin öhdəlik dəyişdirildikdə və bu dəyişdirilmə onun məsuliyyətinin artmasına və ya onun üçün digər əlverişsiz nəticələrə səbəb olduqda, əgər zamin yeni borclu üçün cavabdeh olmaq barəsində kreditora razılıq verməmişsə, zaminliklə təmin edilmiş öhdəlik üzrə borc başqa şəxsə keçirildikdə, kreditor borclunun və ya zaminin təklif etdiyi lazımi icranı qəbul etməkdən imtina etdikdə, zaminlik müqaviləsində göstərilmiş onun verilmə müddəti qurtardıqda. Belə müddət təyin edilmədikdə zaminliyə onun təmin etdiyi öhdəliyin icrası vaxtının çatdığı gündən bir il ərzində kreditorun zaminə qarşı iddia irəli sürmədiyi halda xitam verilir. Əsas öhdəliyin icrası müddəti göstərilmədikdə və müəyyənləşdirilə bilmədikdə və ya tələbetmə məqamı ilə müəyyənləşdirilə bildikdə zaminliyə zaminlik müqaviləsinin bağlandığı gündən iki il ərzində kreditorun zaminə qarşı iddia irəli sürmədiyi halda xitam verilir.',
        },
      ],
    },
    {
      id: 4,
      title: 'Ödəniş xidmətləri və ödəniş sistemləri',
      faqItems: [
        {
          id: 1,
          title:
            '“Ödəniş xidmətləri və ödəniş sistemləri haqqında” Qanunun əhatə dairəsinə nələr aiddir?',
          description:
            'Bu Qanun Azərbaycan Respublikası Konstitusiyasının 94-cü maddəsinin I hissəsinin 10-cu, 11-ci, 12-ci və 15-ci bəndlərinə uyğun olaraq ödəniş xidmətlərini, bu xidmətlər üzrə hüquq və vəzifələri, ödəniş təşkilatları, elektron pul təşkilatları və ödəniş sistemi operatorlarının fəaliyyətinin hüquqi əsaslarını, ödəniş sistemlərinin təhlükəsiz və effektiv fəaliyyətinin təmin olunması üzrə tələbləri, habelə ödəniş xidməti təchizatçıları, ödəniş agentləri və ödəniş sistemi operatorları üzərində tənzimləmə və nəzarətin hüquqi və iqtisadi əsaslarını müəyyən edir.',
        },
        {
          id: 2,
          title: 'Lisenziya əldə etmək üçün əsas tələblər hansılardır?',
          description:
            ' Lisenziya almaq üçün tələblər “Ödəniş xidmətləri və ödəniş sistemləri haqqında” Qanunun 7-ci fəsli, habelə “Ödəniş təşkilatları və elektron pul təşkilatlarının fəaliyyətinin təşkili üzrə Qayda” ilə müəyyən edilir.',
        },
      ],
    },
    {
      id: 5,
      title: 'Kapital bazarları',
      faqItems: [
        {
          id: 1,
          title: 'Kapital bazarı nədir?',
          description:
            'Kapital bazarı maliyyə sektorunda resursların effektiv bölüşdürülməsini təmin edən platformadır. Kapital bazarı dedikdə qiymətli kağızların emissiyası, tədavülü, ödənilməsi, saxlanılması və öhdəliklərlə yüklənməsi kimi əməliyyatların həyata keçirildiyi bazar başa düşülür. Kapital bazarı dövlətin və hüquqi şəxslərin qiymətli kağızlar vasitəsilə öz layihələrini maliyyələşdirə biləcəkləri bazardır. Kapital bazarının ən geniş yayılmış alətləri investisiya qiymətli kağızları olan səhmlər və istiqrazlardır.',
        },
        {
          id: 2,
          title: 'Kapital bazarının iştirakçıları kimlərdir?',
          description:
            'Kapital bazarının iştirakçıları bu bazarın əsas oyunçuları olan emitentlər, investorlar, mərkəzi depozitar, investisiya şirkətləri, digər lisenziyalaşdırılan şəxslər və maliyyə bazarlarına nəzarət orqanıdır. Emitent – qiymətli kağızları buraxan hüquqi şəxslər, investorlar isə bu qiymətli kağızları alan şəxslərdir. Alıcı və satıcılara bu bazarda iştirak imkanını təmin edən - maliyyə vasitəçiliyi rolunu oynayan təşkilatlardır. Nəzarət orqanı, yəni Mərkəzi Bank, bazarın tənzimlənməsi, bazar iştirakçılarının fəaliyyətinə nəzarət, investorların hüquqlarının qorunması, bazarın şəffaflığı və inkişafına cavabdeh qurumdur.',
        },
      ],
    },
    {
      id: 6,
      title: 'Sığorta',
      faqItems: [
        {
          id: 1,
          title: 'Sığorta nədir?',
          description:
            'Sığorta hər hansı itkiyə məruz qalmış şəxsi buna səbəb olmuş hadisədən əvvəlki maliyyə vəziyyətinə qaytarmaq üçün təzminatla təmin edən vasitədir.Sığorta sığortalının və ya sığorta olunanın əmlakı, həyatı, sağlamlığı, mülki məsuliyyəti, həmçinin qanunla qadağan olunmayan fəaliyyəti, o cümlədən sahibkarlıq fəaliyyəti ilə əlaqədar olan əmlak mənafelərinin müdafiəsi sahəsində riskin ötürülməsinə və ya bölüşdürülməsinə əsaslanan münasibətlər sistemidir.',
        },
        {
          id: 2,
          title: 'Nələri sığortalamaq olar?',
          description:
            'Sığorta, gözlənilməz hadisələr zamanı maliyyə itkilərinin qarşısını alan bir alətdir. Müxtəlif sığorta məhsulları—tibbi, kasko, əmlak sığortası və s.—qəza, xəstəlik, təbii fəlakətlər və digər gözlənilməz hallarda yaranan maliyyə yükünü azaldır. Həmçinin, bəzi sığorta növləri qanunla tələb olunur və buna görə də hüquqi tələblərə uyğunluğu təmin edir.',
        },
      ],
    },
    {
      id: 7,
      title: 'Milli pul nişanları',
      faqItems: [
        {
          id: 1,
          title: 'Azərbaycanın pul vahidi nədir?',
          description:
            'Azərbaycan Respublikası Konstitusiyasının 19-cu maddəsinin I hissəsinə müvafiq olaraq Azərbaycan Respublikasının pul vahidi manatdır. Bir manat 100 (yüz) qəpikdən ibarətdir. Pul nişanları kağız və metal pul formasında tədavülə buraxılır.',
        },
        {
          id: 2,
          title:
            'Ölkə ərazisində manatdan başqa hansı pul vahidləri ödəniş vasitəsi kimi işlədilə bilər?',
          description:
            'Azərbaycan Respublikası Konstitusiyasının 19-cu maddəsinin III hissəsinə müvafiq olaraq Azərbaycan Respublikasının ərazisində manatdan başqa pul vahidlərinin ödəniş vasitəsi kimi işlədilməsi qadağandır.Mərkəzi Bankın tədavülə buraxdığı pul nişanları, o cümlədən yubiley və xatirə pul nişanları Azərbaycan Respublikasının bütün ərazisində nominal dəyərləri ilə hər növ ödənişlərin həyata keçirilməsi, hesablara daxil edilməsi və pul köçürmələri zamanı hökmən qəbul edilməlidir.',
        },
      ],
    },
    {
      id: 8,
      title: 'Mərkəzi Banka müraciət və qəbul məsələlərina dair',
      faqItems: [
        {
          id: 1,
          title: 'Mərkəzi Banka rəsmi yazılı müraciət qaydası necədir?',
          description:
            'Müraciətlər Mərkəzi Bankın poçt ünvanına (AZ1014 Bakı şəh., R.Behbudov küç.90 və ya AZ1000 Bakı şəh., Bülbül pr.27) göndərilməklə, həmçinin rəsmi internet səhifəsində “onlayn müraciət” bölməsi vasitəsilə qəbul edilə bilər.',
        },
        {
          id: 2,
          title: 'Mərkəzi Bankla necə şifahi əlaqə saxlamaq olar?',
          description:
            'Mərkəzi Bankla (+99412) 4935058 telefon nömrəsi vasitəsilə əlaqə saxlanılır. Həmçinin “966 qaynar xətti” iş günlərində fasiləsiz olaraq saat 09:00-dan 18:00-dək daxil olan zənglərin cavablandırılmasını həyata keçirir.',
        },
      ],
    },
  ],
  video: {
    title: 'Video sual-cavab ',
    videoUrl: 'https://www.youtube.com/embed/FZrEo1nXlgs?si=2bkyK2B2_Z62XSHB',
    playlistUrl: 'https://www.youtube.com/watch?v=FZrEo1nXlgs',
  },
};
