export const legalFrameWorkData = {
  title: 'Mərkəzi Bankın hüquqi əsasları',
  files: [
    {
      id: 1,
      title: 'Azərbaycan Respublikasının Konstitusiyası',
      web_url: 'https://e-qanun.az/framework/897',
      file_url: 'https://uploads.cbar.az/assets/ea0d0e5d5e74db5c8b92176ed.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title:
        'Azərbaycan Respublikasının İqtisadi Müstəqilliyinin əsasları haqqında Konstitusiya Qanunu',
      web_url: 'https://e-qanun.az/framework/6506',
      file_url: 'https://uploads.cbar.az/assets/95f67f83a230c4f48c3efde23.pdf',
      type: 'pdf',
    },
    {
      id: 3,
      title: 'Azərbaycan Respublikasının Mərkəzi Bankı haqqında',
      web_url: 'https://e-qanun.az/framework/5530',
      file_url: 'https://uploads.cbar.az/assets/5d4fd0b42f189ce5bda504903.pdf',
      type: 'pdf',
    },
  ],
};

export const creditInstitutionsLawData = {
  title: 'Qanunlar',
  files: [
    {
      id: 1,
      title: 'Banklar haqqında',
      web_url: 'https://e-qanun.az/framework/5825',
      file_url: 'https://uploads.cbar.az/assets/166bd5322a6bb40a26fdfcc25.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: 'Bank olmayan kredit təşkilatları haqqında',
      web_url: 'https://e-qanun.az/framework/19197',
      file_url: 'https://uploads.cbar.az/assets/dc3234f510d3262810c0ad3ed.pdf',
      type: 'pdf',
    },
    {
      id: 3,
      title: 'Kredit ittifaqları haqqında',
      web_url: 'https://e-qanun.az/framework/625',
      file_url: 'https://uploads.cbar.az/assets/7999d28b32ba50591d2f7bc0a.pdf',
      type: 'pdf',
    },
    {
      id: 4,
      title: 'Poçt haqqında',
      web_url: 'https://e-qanun.az/framework/5457',
      file_url: 'https://uploads.cbar.az/assets/4e83201d334d69accc5c8caac.pdf',
      type: 'pdf',
    },
    {
      id: 5,
      title: 'Əmanətlərin sığortalanması haqqında',
      web_url: 'https://e-qanun.az/framework/12137',
      file_url: 'https://uploads.cbar.az/assets/76e305207475f38b5d37bba93.pdf',
      type: 'pdf',
    },
  ],
};
export const creditInstitutionsPresidentActsData = {
  title: 'Azərbaycan Respublikası Prezidentinin aktları',
  files: [
    {
      id: 1,
      title: 'Azərbaycan Respublikası Milli Bankının yaradılması haqqında',
      web_url: 'https://e-qanun.az/framework/6960',
      file_url: 'https://uploads.cbar.az/assets/e4a9ffb3d5615818c6b560cff.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: 'Azərbaycan Respublikası milli valyutasının dövriyyəyə buraxılması haqqında',
      web_url: 'https://e-qanun.az/framework/7500',
      file_url: 'https://uploads.cbar.az/assets/8b3463092089174465a9a620c.pdf',
      type: 'pdf',
    },
    {
      id: 3,
      title:
        'Azərbaycan Respublikası milli valyutasının respublika ərazisində yeganə ödəniş vasitəsi elan olunması haqqında',
      web_url: 'https://e-qanun.az/framework/8790',
      file_url: 'https://uploads.cbar.az/assets/a309ed6861370798df93e1fc8.pdf',
      type: 'pdf',
    },
    {
      id: 4,
      title:
        '“2018-2020-ci illərdə Azərbaycan Respublikasında rəqəmsal ödənişlərin genişləndirilməsi üzrə Dövlət Proqramı”nın təsdiq edilməsi haqqında',
      web_url: 'https://e-qanun.az/framework/40164',
      file_url: 'https://uploads.cbar.az/assets/786bff89c2c0e5d46e492eafb.pdf',
      type: 'pdf',
    },
    {
      id: 5,
      title:
        'Nizamnamə kapitalında dövlətə məxsus səhmlər olan bankların və bank olmayan kredit təşkilatlarının idarə edilməsində dövlətin iştirakı qaydası haqqında',
      web_url: 'https://e-qanun.az/framework/18168',
      file_url: 'https://uploads.cbar.az/assets/eccf24e68ba03b4ab2bb8d1a0.pdf',
      type: 'pdf',
    },
    {
      id: 6,
      title:
        'Ödəmə qabiliyyətini itirmiş bankların rezolyusiyası və sağlamlaşdırma tədbirləri çərçivəsində qeyri-işlək (toksik) aktivlərin təqdim edilməsi Qaydası”nın təsdiq edilməsi haqqında',
      web_url: 'https://e-qanun.az/framework/35349',
      file_url: 'https://uploads.cbar.az/assets/78f53c881df47b48207de4f97.pdf',
      type: 'pdf',
    },
  ],
};
export const creditInstitutionsCabinetMinistersactsData = {
  title: 'Nazirlər Kabinetinin aktları',
  files: [
    {
      id: 1,
      title:
        'Azərbaycan Respublikası Mərkəzi Bankının normativ xarakterli aktlarının hazırlanması və qəbul edilməsi Qaydası”nın təsdiq edilməsi barədə',
      web_url: 'https://e-qanun.az/framework/22543',
      file_url: 'https://uploads.cbar.az/assets/83415682e48d5b3a9660242c2.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title:
        'Nəzarət zərfi dövlətə məxsus banklar tərəfindən öz vəsaitləri hesabına ipoteka kreditlərinin verilməsi Qaydası',
      web_url: 'https://e-qanun.az/framework/36659',
      file_url: 'https://uploads.cbar.az/assets/26c822988c41f7c2576841414.pdf',
      type: 'pdf',
    },
  ],
};
export const creditInstitutionsRegulationData = {
  title: 'Qaydalar',
  note: 'Aşağıda yerləşdirilmiş hüquqi aktların rekvizitlərinə, o cümlədən qüvvəyə minməsinə dair məlumatları hüquqi aktın burada yerləşdirilmiş e-qanun.az internet səhifəsində mövcud olan versiyasına (keçidə) daxil olduqdan sonra, səhifənin yuxarı sağ küncündəki açılan siyahı işarəsini (ꓦ) klikləməklə açılan rekvizitlər bölməsindən əldə edə bilərsiniz.',
  files: [
    {
      id: 1,
      title: 'Banklarda korporativ idarəetmə standartları',
      web_url: 'https://e-qanun.az/framework/55125',
      file_url: 'https://uploads.cbar.az/assets/3ff8beba727780c6b2d6f9339.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: 'Bank hesablarının açılması, aparılması və bağlanması Qaydaları',
      web_url: 'https://e-qanun.az/framework/49456',
      file_url: 'https://uploads.cbar.az/assets/fbc1fc9dcdd6bc8424af2f984.pdf',
      type: 'pdf',
    },
    {
      id: 3,
      title:
        'Fiziki şəxslərin xarici valyutada olan kreditlərinin əsas məbləğinin devalvasiya nəticəsində manatla artmış hissəsinin ödənilməsi mexanizminin və həmin məbləğə hesablanmış faiz və dəbbə pulu (cərimə, penya) üzrə tətbiq ediləcək güzəştlərin müəyyən edilməsi Qaydası',
      web_url: 'https://e-qanun.az/framework/41773',
      file_url: 'https://uploads.cbar.az/assets/b1906687032d2e765ba11b44d.pdf',
      type: 'pdf',
    },
  ],
};
export const paymentsLawData = {
  title: 'Qanunlar',
  files: [
    {
      id: 1,
      title: 'Ödəniş xidmətləri və ödəniş sistemləri haqqında',
      web_url: 'https://e-qanun.az/framework/54872',
      file_url: 'https://uploads.cbar.az/assets/9978c9109b2193d28746e54d3.pdf',
      type: 'pdf',
    },
  ],
};
export const paymentsRegulationData = {
  title: 'Qaydalar',
  note: 'Aşağıda yerləşdirilmiş hüquqi aktların rekvizitlərinə, o cümlədən qüvvəyə minməsinə dair məlumatları hüquqi aktın burada yerləşdirilmiş e-qanun.az internet səhifəsində mövcud olan versiyasına (keçidə) daxil olduqdan sonra, səhifənin yuxarı sağ küncündəki açılan siyahı işarəsini (ꓦ) klikləməklə açılan rekvizitlər bölməsindən əldə edə bilərsiniz.',
  files: [
    {
      id: 1,
      title:
        'Azərbaycan Respublikası Mərkəzi Bankının normativ xarakterli aktlarının hazırlanması və qəbul edilməsi Qaydası”nın təsdiq edilməsi barədə',
      web_url: 'https://e-qanun.az/framework/22543',
      file_url: 'https://uploads.cbar.az/assets/83415682e48d5b3a9660242c2.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title:
        'Nəzarət zərfi dövlətə məxsus banklar tərəfindən öz vəsaitləri hesabına ipoteka kreditlərinin verilməsi Qaydası',
      web_url: 'https://e-qanun.az/framework/36659',
      file_url: 'https://uploads.cbar.az/assets/26c822988c41f7c2576841414.pdf',
      type: 'pdf',
    },
  ],
};

export const capitalMarketLawData = {
  title: 'Qanunlar',
  files: [
    {
      id: 1,
      title: 'Qiymətli kağızlar bazarı haqqında',
      web_url: 'https://e-qanun.az/framework/30333',
      file_url: 'https://uploads.cbar.az/assets/408427cbb4a3cdd5a7d1f52e0.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: 'İnvestisiya fondları haqqında',
      web_url: 'https://e-qanun.az/framework/20760',
      file_url: 'https://uploads.cbar.az/assets/13d2eee8717fe54fa0ef74123.pdf',
      type: 'pdf',
    },
  ],
};
export const capitalMarketPresidentActsData = {
  title: 'Azərbaycan Respublikası Prezidentinin aktları',
  files: [
    {
      id: 1,
      title:
        'Aqrar sığorta haqqında Azərbaycan Respublikasının 2019-cu il 27 iyun tarixli 1617-VQ nömrəli Qanununun tətbiqi və Aqrar Sığorta Fondunun yaradılması barədə',
      web_url: 'https://e-qanun.az/framework/43125',
      file_url: 'https://uploads.cbar.az/assets/c24152baa78df8790ac669483.pdf',
      type: 'pdf',
    },
  ],
};
export const capitalMarketCabinetMinistersactsData = {
  title: 'Nazirlər Kabinetinin aktları',
  files: [
    {
      id: 1,
      title:
        'Azərbaycan Respublikası Mərkəzi Bankının normativ xarakterli aktlarının hazırlanması və qəbul edilməsi Qaydası”nın təsdiq edilməsi barədə',
      web_url: 'https://e-qanun.az/framework/22543',
      file_url: 'https://uploads.cbar.az/assets/83415682e48d5b3a9660242c2.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title:
        'Nəzarət zərfi dövlətə məxsus banklar tərəfindən öz vəsaitləri hesabına ipoteka kreditlərinin verilməsi Qaydası',
      web_url: 'https://e-qanun.az/framework/36659',
      file_url: 'https://uploads.cbar.az/assets/26c822988c41f7c2576841414.pdf',
      type: 'pdf',
    },
  ],
};
export const capitalMarketRegulationData = {
  title: 'Qaydalar',
  note: 'Aşağıda yerləşdirilmiş hüquqi aktların rekvizitlərinə, o cümlədən qüvvəyə minməsinə dair məlumatları hüquqi aktın burada yerləşdirilmiş e-qanun.az internet səhifəsində mövcud olan versiyasına (keçidə) daxil olduqdan sonra, səhifənin yuxarı sağ küncündəki açılan siyahı işarəsini (ꓦ) klikləməklə açılan rekvizitlər bölməsindən əldə edə bilərsiniz.',
  files: [
    {
      id: 1,
      title: 'Banklarda korporativ idarəetmə standartları',
      web_url: 'https://e-qanun.az/framework/55125',
      file_url: 'https://uploads.cbar.az/assets/3ff8beba727780c6b2d6f9339.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: 'Bank hesablarının açılması, aparılması və bağlanması Qaydaları',
      web_url: 'https://e-qanun.az/framework/49456',
      file_url: 'https://uploads.cbar.az/assets/fbc1fc9dcdd6bc8424af2f984.pdf',
      type: 'pdf',
    },
    {
      id: 3,
      title:
        'Fiziki şəxslərin xarici valyutada olan kreditlərinin əsas məbləğinin devalvasiya nəticəsində manatla artmış hissəsinin ödənilməsi mexanizminin və həmin məbləğə hesablanmış faiz və dəbbə pulu (cərimə, penya) üzrə tətbiq ediləcək güzəştlərin müəyyən edilməsi Qaydası.Fiziki şəxslərin xarici valyutada olan kreditlərinin əsas məbləğinin devalvasiya nəticəsində manatla artmış hissəsinin ödənilməsi mexanizminin və həmin məbləğə hesablanmış faiz və dəbbə pulu (cərimə, penya) üzrə tətbiq ediləcək güzəştlərin müəyyən edilməsi Qaydası',
      web_url: 'https://e-qanun.az/framework/41773',
      file_url: 'https://uploads.cbar.az/assets/b1906687032d2e765ba11b44d.pdf',
      type: 'pdf',
    },
  ],
};

export const insuranceLawData = {
  title: 'Qanunlar',
  files: [
    {
      id: 1,
      title: 'Sığorta fəaliyyəti haqqında',
      web_url: 'https://e-qanun.az/framework/13983',
      file_url: 'https://uploads.cbar.az/assets/974703a88e83c6823a008663a.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: 'İcbari sığortalar haqqında',
      web_url: 'https://e-qanun.az/framework/22228',
      file_url: 'https://uploads.cbar.az/assets/789683cd1973ed0ef2e303c02.pdf',
      type: 'pdf',
    },
    {
      id: 3,
      title:
        'İstehsalatda bədbəxt hadisələr və peşə xəstəlikləri nəticəsində peşə əmək qabiliyyətinin itirilməsi hallarından icbari sığorta haqqında',
      web_url: 'https://e-qanun.az/framework/19789',
      file_url: 'https://uploads.cbar.az/assets/fc7e51fe6afb7f8d69ba0e488.pdf',
      type: 'pdf',
    },
    {
      id: 4,
      title: 'Tibbi sığorta haqqında',
      web_url: 'https://e-qanun.az/framework/80',
      file_url: 'https://uploads.cbar.az/assets/d4b8c83756bd3376b570c19b4.pdf',
      type: 'pdf',
    },
  ],
};
export const insurancePresidentActsData = {
  title: 'Azərbaycan Respublikası Prezidentinin aktları',
  files: [
    {
      id: 1,
      title:
        'Aqrar sığorta haqqında Azərbaycan Respublikasının 2019-cu il 27 iyun tarixli 1617-VQ nömrəli Qanununun tətbiqi və Aqrar Sığorta Fondunun yaradılması barədə',
      web_url: 'https://e-qanun.az/framework/43125',
      file_url: 'https://uploads.cbar.az/assets/c24152baa78df8790ac669483.pdf',
      type: 'pdf',
    },
  ],
};
export const insuranceCabinetMinistersactsData = {
  title: 'Nazirlər Kabinetinin aktları',
  files: [
    {
      id: 1,
      title:
        'İstehsalatda bədbəxt hadisələr və peşə xəstəlikləri nəticəsində peşə əmək qabiliyyətinin itirilməsi hallarından icbari sığorta üzrə sığorta ödənişinin təyin edilməsi üçün sənədlərin Siyahısı və İstehsalatda bədbəxt hadisələr və peşə xəstəlikləri nəticəsində peşə əmək qabiliyyətinin itirilməsi hallarından icbari sığorta üzrə sığorta ödənişinin təyin edilməsi, verilməsinin dayandırılması və bərpa olunması Qaydalarının təsdiq edilməsi barədə',
      web_url: 'https://e-qanun.az/framework/21011',
      file_url: 'https://uploads.cbar.az/assets/a85b72ca83d2b1992c57698bc.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title:
        'İstehsalatda bədbəxt hadisələr və peşə xəstəlikləri nəticəsində peşə əmək qabiliyyətinin itirilməsi hallarından icbari sığorta olunanların istehsalatda yerinə yetirilən əmək funksiyalarının xarakterinə görə kateqoriyalar üzrə bölgüsünün Qaydası',
      web_url: 'https://e-qanun.az/framework/20560',
      file_url: 'https://uploads.cbar.az/assets/2bdef91709a861f7783233307.pdf',
      type: 'pdf',
    },
  ],
};
export const insuranceRegulationData = {
  title: 'Qaydalar',
  note: 'Aşağıda yerləşdirilmiş hüquqi aktların rekvizitlərinə, o cümlədən qüvvəyə minməsinə dair məlumatları hüquqi aktın burada yerləşdirilmiş e-qanun.az internet səhifəsində mövcud olan versiyasına (keçidə) daxil olduqdan sonra, səhifənin yuxarı sağ küncündəki açılan siyahı işarəsini (ꓦ) klikləməklə açılan rekvizitlər bölməsindən əldə edə bilərsiniz.',
  files: [
    {
      id: 1,
      title:
        'Sağlamlaşdırma planına dair tələblər, onun icra müddətinin hesablanması, icrasına dair hesabatların forması və təqdim olunması Qaydası',
      web_url: 'https://e-qanun.az/framework/42775',
      file_url: 'https://uploads.cbar.az/assets/40b25b8ca20f91215da0e70e5.pdf',
      type: 'pdf',
    },
  ],
};

export const currencyRegulationLawData = {
  title: 'Qanunlar',
  files: [
    {
      id: 1,
      title: 'Valyuta tənzimi haqqında',
      web_url: 'https://e-qanun.az/framework/9238',
      file_url: 'https://uploads.cbar.az/assets/9d420fd09da171d6a46c6f256.pdf',
      type: 'pdf',
    },
  ],
};
export const currencyRegulationRegulationData = {
  title: 'Qaydalar',
  note: 'Aşağıda yerləşdirilmiş hüquqi aktların rekvizitlərinə, o cümlədən qüvvəyə minməsinə dair məlumatları hüquqi aktın burada yerləşdirilmiş e-qanun.az internet səhifəsində mövcud olan versiyasına (keçidə) daxil olduqdan sonra, səhifənin yuxarı sağ küncündəki açılan siyahı işarəsini (ꓦ) klikləməklə açılan rekvizitlər bölməsindən əldə edə bilərsiniz.',
  files: [
    {
      id: 1,
      title:
        'Valyuta mübadiləsi fəaliyyətinə lisenziyanın (lisenziyanın əlavəsinin) alınması üçün ərizə formasının, Valyuta mübadiləsi fəaliyyətinin həyata keçirilməsi üçün nizamnamə (şərikli) kapitalının minimum miqdarı, girov vəsaitinin məbləği və geri alınmasına dair rəyin forması ilə bağlı Tələblər”in və Valyuta mübadiləsi fəaliyyətinə lisenziya almış şəxslər tərəfindən valyuta mübadiləsi əməliyyatlarının aparılması və valyuta mübadiləsi fəaliyyətinə nəzarət Qaydasının təsdiq edilməsi barədə',
      web_url: 'https://e-qanun.az/framework/55846',
      file_url: 'https://uploads.cbar.az/assets/5cfd1fefaa00f3339e2d6a028.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: '',
      web_url: 'https://e-qanun.az/framework/55846',
      file_url: 'https://uploads.cbar.az/assets/5cfd1fefaa00f3339e2d6a028.pdf',
      type: 'pdf',
    },
    {
      id: 3,
      title:
        'Azərbaycan Respublikasının rezidentlərinin xarici valyutada, habelə qeyri-rezidentlərin milli və xarici valyutada əməliyyatlarının aparılması Qaydaları',
      web_url: 'https://e-qanun.az/framework/34248',
      file_url: 'https://uploads.cbar.az/assets/1977b4228849430998395a07d.pdf',
      type: 'pdf',
    },
    {
      id: 4,
      title:
        'Azərbaycan Respublikasının rezidentlərinin xarici valyutada, habelə qeyri-rezidentlərin milli və xarici valyutada əməliyyatlarının aparılması Qaydaları',
      web_url: 'https://e-qanun.az/framework/34248',
      file_url: 'https://uploads.cbar.az/assets/1977b4228849430998395a07d.pdf',
      type: 'pdf',
    },
    {
      id: 5,
      title:
        'Azərbaycan Respublikasının rezidentlərinin xarici valyutada, habelə qeyri-rezidentlərin milli və xarici valyutada əməliyyatlarının aparılması Qaydaları',
      web_url: 'https://e-qanun.az/framework/34248',
      file_url: 'https://uploads.cbar.az/assets/1977b4228849430998395a07d.pdf',
      type: 'pdf',
    },
    {
      id: 6,
      title:
        'Azərbaycan Respublikasının rezidentlərinin xarici valyutada, habelə qeyri-rezidentlərin milli və xarici valyutada əməliyyatlarının aparılması Qaydaları',
      web_url: 'https://e-qanun.az/framework/34248',
      file_url: 'https://uploads.cbar.az/assets/1977b4228849430998395a07d.pdf',
      type: 'pdf',
    },
    {
      id: 7,
      title:
        'Azərbaycan Respublikasının rezidentlərinin xarici valyutada, habelə qeyri-rezidentlərin milli və xarici valyutada əməliyyatlarının aparılması Qaydaları',
      web_url: 'https://e-qanun.az/framework/34248',
      file_url: 'https://uploads.cbar.az/assets/1977b4228849430998395a07d.pdf',
      type: 'pdf',
    },
  ],
};

export const legalActsStatisticsData = {
  title: 'Statistika',
  note: 'Aşağıda yerləşdirilmiş hüquqi aktların rekvizitlərinə, o cümlədən qüvvəyə minməsinə dair məlumatları hüquqi aktın burada yerləşdirilmiş e-qanun.az internet səhifəsində mövcud olan versiyasına (keçidə) daxil olduqdan sonra, səhifənin yuxarı sağ küncündəki açılan siyahı işarəsini (ꓦ) klikləməklə açılan rekvizitlər bölməsindən əldə edə bilərsiniz.',
  files: [
    {
      id: 1,
      title:
        'Kassa dövriyyəsi haqqında statistik hesabatın tərtibi və təqdim olunması haqqında Təlimat',
      web_url: 'https://e-qanun.az/framework/27171',
      file_url: 'https://uploads.cbar.az/assets/d7c488e97b73640d20e57137d.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title:
        'Qabaqcadan ödənişlərlə bağlı malların (xidmətlərin) ölkəyə daxil olması haqqında statistik hesabatın tərtibi və təqdim olunması haqqında Təlimat',
      web_url: 'https://e-qanun.az/framework/27172',
      file_url: 'https://uploads.cbar.az/assets/70c0fc4b2b0f623aee2a3d42a.pdf',
      type: 'pdf',
    },
  ],
};

export const legalActsMetodologyData = {
  title: 'Metodoloji sənədlər',
  files: [
    {
      id: 1,
      title:
        'Azərbaycan Respublikasının bank sistemi üçün Hesablar Planı və onun tətbiqinə dair Metodiki Göstərişlər',
      web_url: 'https://uploads.cbar.az/assets/bc3c85ca91195135278a0aae4.pdf',
      file_url: 'https://uploads.cbar.az/assets/bc3c85ca91195135278a0aae4.pdf',
      type: 'pdf',
    },
  ],
};

export const codesOtherLawsData = {
  title: 'Qanunlar',
  files: [
    {
      id: 1,
      title: 'Sığorta fəaliyyəti haqqında',
      web_url: 'https://e-qanun.az/framework/13983',
      file_url: 'https://uploads.cbar.az/assets/974703a88e83c6823a008663a.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: 'İcbari sığortalar haqqında',
      web_url: 'https://e-qanun.az/framework/22228',
      file_url: 'https://uploads.cbar.az/assets/789683cd1973ed0ef2e303c02.pdf',
      type: 'pdf',
    },
    {
      id: 3,
      title:
        'İstehsalatda bədbəxt hadisələr və peşə xəstəlikləri nəticəsində peşə əmək qabiliyyətinin itirilməsi hallarından icbari sığorta haqqında',
      web_url: 'https://e-qanun.az/framework/19789',
      file_url: 'https://uploads.cbar.az/assets/fc7e51fe6afb7f8d69ba0e488.pdf',
      type: 'pdf',
    },
    {
      id: 4,
      title: 'Tibbi sığorta haqqında',
      web_url: 'https://e-qanun.az/framework/80',
      file_url: 'https://uploads.cbar.az/assets/d4b8c83756bd3376b570c19b4.pdf',
      type: 'pdf',
    },
  ],
};
export const otherPresidentActsData = {
  title: 'Azərbaycan Respublikası Prezidentinin aktları',
  files: [
    {
      id: 1,
      title:
        'Aqrar sığorta haqqında Azərbaycan Respublikasının 2019-cu il 27 iyun tarixli 1617-VQ nömrəli Qanununun tətbiqi və Aqrar Sığorta Fondunun yaradılması barədə',
      web_url: 'https://e-qanun.az/framework/43125',
      file_url: 'https://uploads.cbar.az/assets/c24152baa78df8790ac669483.pdf',
      type: 'pdf',
    },
  ],
};
export const otherCabinetMinistersactsData = {
  title: 'Nazirlər Kabinetinin aktları',
  files: [
    {
      id: 1,
      title:
        'İstehsalatda bədbəxt hadisələr və peşə xəstəlikləri nəticəsində peşə əmək qabiliyyətinin itirilməsi hallarından icbari sığorta üzrə sığorta ödənişinin təyin edilməsi üçün sənədlərin Siyahısı və İstehsalatda bədbəxt hadisələr və peşə xəstəlikləri nəticəsində peşə əmək qabiliyyətinin itirilməsi hallarından icbari sığorta üzrə sığorta ödənişinin təyin edilməsi, verilməsinin dayandırılması və bərpa olunması Qaydalarının təsdiq edilməsi barədə',
      web_url: 'https://e-qanun.az/framework/21011',
      file_url: 'https://uploads.cbar.az/assets/a85b72ca83d2b1992c57698bc.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title:
        'İstehsalatda bədbəxt hadisələr və peşə xəstəlikləri nəticəsində peşə əmək qabiliyyətinin itirilməsi hallarından icbari sığorta olunanların istehsalatda yerinə yetirilən əmək funksiyalarının xarakterinə görə kateqoriyalar üzrə bölgüsünün Qaydası',
      web_url: 'https://e-qanun.az/framework/20560',
      file_url: 'https://uploads.cbar.az/assets/2bdef91709a861f7783233307.pdf',
      type: 'pdf',
    },
  ],
};
export const otherRegulationData = {
  title: 'Qaydalar',
  note: 'Aşağıda yerləşdirilmiş hüquqi aktların rekvizitlərinə, o cümlədən qüvvəyə minməsinə dair məlumatları hüquqi aktın burada yerləşdirilmiş e-qanun.az internet səhifəsində mövcud olan versiyasına (keçidə) daxil olduqdan sonra, səhifənin yuxarı sağ küncündəki açılan siyahı işarəsini (ꓦ) klikləməklə açılan rekvizitlər bölməsindən əldə edə bilərsiniz.',
  files: [
    {
      id: 1,
      title:
        'Sağlamlaşdırma planına dair tələblər, onun icra müddətinin hesablanması, icrasına dair hesabatların forması və təqdim olunması Qaydası',
      web_url: 'https://e-qanun.az/framework/42775',
      file_url: 'https://uploads.cbar.az/assets/40b25b8ca20f91215da0e70e5.pdf',
      type: 'pdf',
    },
  ],
};
