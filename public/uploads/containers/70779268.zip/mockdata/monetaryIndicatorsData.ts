export const monetaryIndicatorsData = {
  currencyreserved: {
    title: 'Rəsmi valyuta ehtiyatları',
    years: [2020, 2021, 2022, 2023, 2024, 2025],
    table: [
      { date: '15.03.2020', value: 12345.6 },
      { date: '10.06.2020', value: 12478.3 },
      { date: '25.11.2020', value: 12890.1 },

      { date: '12.01.2021', value: 13200.4 },
      { date: '05.06.2021', value: 13450.0 },
      { date: '18.12.2021', value: 13780.5 },

      { date: '08.02.2022', value: 14000.0 },
      { date: '21.05.2022', value: 14230.7 },
      { date: '10.09.2022', value: 14567.8 },

      { date: '01.03.2023', value: 14890.2 },
      { date: '21.06.2023', value: 15123.4 },
      { date: '21.12.2023', value: 15450.6 },

      { date: '15.01.2024', value: 15780.9 },
      { date: '12.04.2024', value: 16000.1 },
      { date: '30.07.2024', value: 16245.8 },

      { date: '12.01.2025', value: 16500.0 },
      { date: '10.05.2025', value: 16820.3 },
      { date: '18.09.2025', value: 17050.7 },
    ],
  },

  moneybase: {
    title: 'Pul bazası',
    years: [2020, 2021, 2022, 2023, 2024, 2025],
    table: [
      { date: '20.02.2020', value: 8750.0 },
      { date: '15.05.2020', value: 8900.2 },
      { date: '01.12.2020', value: 9150.5 },

      { date: '05.03.2021', value: 9400.8 },
      { date: '25.08.2021', value: 9600.0 },
      { date: '10.11.2021', value: 9830.3 },

      { date: '14.02.2022', value: 10050.7 },
      { date: '20.06.2022', value: 10230.9 },
      { date: '05.10.2022', value: 10480.4 },

      { date: '01.02.2023', value: 10700.1 },
      { date: '15.07.2023', value: 10900.6 },
      { date: '21.12.2023', value: 11145.0 },

      { date: '10.01.2024', value: 11360.3 },
      { date: '15.03.2024', value: 11540.2 },
      { date: '01.08.2024', value: 11780.7 },

      { date: '05.02.2025', value: 12030.9 },
      { date: '10.06.2025', value: 12250.4 },
      { date: '25.10.2025', value: 12475.6 },
    ],
    note: 'Beynəlxalq Valyuta Fondunun Pul və Maliyyə Statistikası metodologiyasına əsasən fərdi sahibkarlıqla məşğul olan fiziki şəxslərin əmanətləri daxil olmaqla.',
  },
};
