import { naxcivan1 } from './images';

export const nakhcivanData = {
  bulletin: {
    id: 1,
    title: 'Statistik Bülleten',
    type: 'bulletin',
    data: [
      {
        id: 1,
        title: '2025',
        files: [
          {
            id: 1,
            title: 'May',
            year: 2025,
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'xls',
          },
          {
            id: 2,
            title: 'May',
            year: 2025,
            coverTitle: 'Statistik Bülleten',
            web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'pdf',
          },
          {
            id: 3,
            title: 'Aprel',
            year: 2025,
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'xls',
          },
          {
            id: 4,
            title: 'Aprel',
            year: 2025,
            coverTitle: 'Statistik Bülleten',
            web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'pdf',
          },
        ],
      },
      {
        id: 2,
        title: '2024',
        files: [
          {
            id: 1,
            title: 'May',
            year: 2024,
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'xls',
          },
          {
            id: 2,
            title: 'May',
            year: 2024,
            coverTitle: 'Statistik Bülleten',
            web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'pdf',
          },
          {
            id: 3,
            title: 'Aprel',
            year: 2024,
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'xls',
          },
          {
            id: 4,
            title: 'Aprel',
            year: 2024,
            coverTitle: 'Statistik Bülleten',
            web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'pdf',
          },
        ],
      },
      {
        id: 3,
        title: '2023',
        files: [
          {
            id: 1,
            title: 'May',
            year: 2023,
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'xls',
          },
          {
            id: 2,
            title: 'May',
            year: 2023,
            coverTitle: 'Statistik Bülleten',
            web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'pdf',
          },
          {
            id: 3,
            title: 'Aprel',
            year: 2023,
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'xls',
          },
          {
            id: 4,
            title: 'Aprel',
            year: 2023,
            coverTitle: 'Statistik Bülleten',
            web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'pdf',
          },
        ],
      },
      {
        id: 4,
        title: '2022',
        files: [
          {
            id: 1,
            title: 'May',
            year: 2022,
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'xls',
          },
          {
            id: 2,
            title: 'May',
            year: 2022,
            coverTitle: 'Statistik Bülleten',
            web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'pdf',
          },
          {
            id: 3,
            title: 'Aprel',
            year: 2022,
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'xls',
          },
          {
            id: 4,
            title: 'Aprel',
            year: 2022,
            coverTitle: 'Statistik Bülleten',
            web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'pdf',
          },
        ],
      },
      {
        id: 5,
        title: '2021',
        files: [
          {
            id: 1,
            title: 'May',
            year: 2021,
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'xls',
          },
          {
            id: 2,
            title: 'May',
            year: 2021,
            coverTitle: 'Statistik Bülleten',
            web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'pdf',
          },
          {
            id: 3,
            title: 'Aprel',
            year: 2021,
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'xls',
          },
          {
            id: 4,
            title: 'Aprel',
            year: 2021,
            coverTitle: 'Statistik Bülleten',
            web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
            file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
            type: 'pdf',
          },
        ],
      },
    ],
  },
  publications: {
    id: 1,
    title: 'Nəşrlər',
    type: 'publications',
    data: [
      {
        id: 1,
        title:
          'Naxçıvan Muxtar Respublikasında nağdsız ödənişlər: mövcud vəziyyət və inkişaf perspektivləri',
        web_url: 'https://uploads.cbar.az/assets/0bea76b245ec5e4413c6ff369.pdf',
        file_url: 'https://uploads.cbar.az/assets/0bea76b245ec5e4413c6ff369.pdf',
        type: 'pdf',
      },
    ],
  },
  haydaraliyev: {
    id: 1,
    title: 'Heydər Əliyev 100 il',
    type: 'haydaraliyev',
    data: [
      {
        id: 1,
        title:
          'Azərbaycan Respublikası Mərkəzi Bankının Naxçıvan Muxtar Respublikası İdarəsi tərəfindən “Heydər Əliyev İli” ilə bağlı silsilə tədbirlər davam etdirilir.Azərbaycan Respublikası Mərkəzi Bankının Naxçıvan Muxtar Respublikası İdarəsi və Naxçıvan Dövlət Universitetinin birgə təşəbbüskarlığı ilə Ümummilli Lider Heydər Əliyevin anadan olmasının 100 illiyi münasibətilə “Maliyyə savadlılığı layihəsi” çərçivəsində “Açıq bankçılıq” mövzusunda təlim',
        content:
          '23 oktyabr tarixində Azərbaycan Respublikası Mərkəzi Bankının Naxçıvan Muxtar Respublikası İdarəsi və Naxçıvan Dövlət Universitetinin birgə təşəbbüskarlığı ilə Ümummilli Lider Heydər Əliyevin anadan olmasının 100 illiyi münasibətilə Universitetin müəllim və tələbə kollektivi üçün “Maliyyə savadlılığı layihəsi” çərçivəsində “Açıq bankçılıq” mövzusunda təlim keçirilmişdir.',
        images: [
          {
            id: 1,
            image: naxcivan1,
          },
          {
            id: 2,
            image: naxcivan1,
          },
          {
            id: 3,
            image: naxcivan1,
          },
          {
            id: 4,
            image: naxcivan1,
          },
          {
            id: 5,
            image: naxcivan1,
          },
        ],
      },
      {
        id: 2,
        title:
          'Azərbaycan Respublikası Mərkəzi Bankının Naxçıvan Muxtar Respublikası İdarəsi, Əmanətlərin Sığortalanması Fondu və Naxçıvan Universitetinin birgə təşəbbüsü ilə “Əmanətlərin sığortalanması sistemi və hüquqi bazanın öyrənilməsi” mövzusunda təlim',
        content:
          '23 oktyabr tarixində Azərbaycan Respublikası Mərkəzi Bankının Naxçıvan Muxtar Respublikası İdarəsi, Əmanətlərin Sığortalanması Fondu və Naxçıvan Universitetinin birgə təşəbbüsü ilə Əmanətlərin Sığortalanması Fondunun əməkdaşları tərəfindən “Naxçıvan” Universitetinin müəllim və tələbə heyəti üçün “Əmanətlərin sığortalanması sistemi və hüquqi bazanın öyrənilməsi” mövzusunda təlim keçirilmişdir.',
        images: [
          {
            id: 1,
            image: naxcivan1,
          },
          {
            id: 2,
            image: naxcivan1,
          },
          {
            id: 3,
            image: naxcivan1,
          },
          {
            id: 4,
            image: naxcivan1,
          },
          {
            id: 5,
            image: naxcivan1,
          },
        ],
      },
      {
        id: 3,
        title:
          'Azərbaycan Respublikası Mərkəzi Bankının Naxçıvan Muxtar Respublikası İdarəsinin təşəbbüsü və Naxçıvan Gənclər Fondunun təşkilati dəstəyilə Naxçıvan şəhərində Ümummilli Lider Heydər Əliyevin 100 illik yubileyinə həsr olunmuş banklararası “Lider” müsabiqəsi',
        content:
          '23 oktyabr tarixində Azərbaycan Respublikası Mərkəzi Bankının Naxçıvan Muxtar Respublikası İdarəsinin təşəbbüsü və Naxçıvan Gənclər Fondunun təşkilati dəstəyilə Naxçıvan şəhərində yerləşən Gənclik Mərkəzində Ümummilli Lider Heydər Əliyevin anadan olmasının 100-cü ildönümü münasibətilə regionda fəaliyyət göstərən banklararası “Lider” müsabiqəsi keçirilmişdir.',
        images: [
          {
            id: 1,
            image: naxcivan1,
          },
          {
            id: 2,
            image: naxcivan1,
          },
          {
            id: 3,
            image: naxcivan1,
          },
          {
            id: 4,
            image: naxcivan1,
          },
          {
            id: 5,
            image: naxcivan1,
          },
        ],
      },
      {
        id: 4,
        title:
          'Ümummilli Lider Heydər Əliyevin anadan olmasının 100 illiyi münasibətilə Mərkəzi Bankın Naxçıvan MR İdarəsi tərəfindən istedadlı bank əməkdaşlarının yaradıcılıq tədbiri keçirilib',
        content:
          'Ölkədə banklar arasında ilk dəfə keçirilən tədbirdə Mərkəzi Bankın baş direktoru Gülər Paşayeva, İR departamentinin direktoru Oksana İsmayılova, AR Milli Məclisinin deputatları Cəbi Quliyev və Ülviyyə Həmzəyeva, AR XİN NMR İdarəsinin rəisi Vüsal Ələkbərli və digər qonaqlar iştirak edib.',
        images: [
          {
            id: 1,
            image: naxcivan1,
          },
          {
            id: 2,
            image: naxcivan1,
          },
          {
            id: 3,
            image: naxcivan1,
          },
          {
            id: 4,
            image: naxcivan1,
          },
          {
            id: 5,
            image: naxcivan1,
          },
        ],
      },
    ],
  },
  events: {
    id: 1,
    title: 'Tədbirlər',
    type: 'events',
    data: [
      {
        id: 1,
        title: 'Naxçıvanda investorların hüquqlarının müdafiəsinə həsr olunmuş görüş keçirilib',
        content:
          'Mərkəzi Bankın Naxçıvan Muxtar Respublikası idarəsində regionda fəaliyyət göstərən səhmdar cəmiyyətlərin nümayəndələrinin iştirakı ilə görüş keçirilib. Tədbirdə investorların hüquqlarının müdafiəsinin möhkəmləndirilməsi, səhmdar cəmiyyətlərdə korporativ idarəetmənin təkmilləşdirilməsi, emitentlərin illik hesabatlarının qanunvericiliyə uyğun tərtibi və səhmdarların ümumi yığıncaqlarının düzgün qaydada çağırılması kimi mövzular müzakirə edilib.',
        images: [
          { id: 1, image: naxcivan1 },
          { id: 2, image: naxcivan1 },
          { id: 3, image: naxcivan1 },
          { id: 4, image: naxcivan1 },
          { id: 5, image: naxcivan1 },
        ],
      },
      {
        id: 2,
        title:
          'Azərbaycan Respublikası Mərkəzi Bankının Naxçıvan Muxtar Respublikası İdarəsi “Kiber cinayətkarlıq və ona qarşı mübarizə üsulları” mövzusunda maarifləndirici tədbir keçirib',
        content:
          'Azərbaycan Respublikası Mərkəzi Bankının Naxçıvan Muxtar Respublikası İdarəsi, Naxçıvan Muxtar Respublikası Prokurorluğu, Naxçıvan Muxtar Respublikası Daxili İşlər Nazirliyi və Naxçıvan Dövlət Universiteti tərəfindən regionda fəaliyyət göstərən idarə və təşkilatlarda “Kiber cinayətkarlıq və ona qarşı mübarizə üsulları” mövzusunda maarifləndirici tədbir keçirilib.',
        images: [
          { id: 1, image: naxcivan1 },
          { id: 2, image: naxcivan1 },
          { id: 3, image: naxcivan1 },
          { id: 4, image: naxcivan1 },
          { id: 5, image: naxcivan1 },
        ],
      },
      {
        id: 3,
        title:
          '“Naxçıvan Muxtar Respublikasının sosial-iqtisadi inkişafına dair 2023–2027-ci illər üçün Dövlət Proqramı”da nəzərdə tutulmuş tədbirlərin icrası məqsədilə Azərbaycan Respublikası Mərkəzi Bankının Naxçıvan Muxtar Respublikası İdarəsi və Şahbuz Rayon İcra Hakimiyyətinin birgə təşkilatçılığı ilə sığorta maarifləndirməsi ilə bağlı tədbir keçirilib',
        content:
          'Tədbir Naxçıvan Muxtar Respublikası Şahbuz Rayon İcra Hakimiyyətində təşkil olunub.Tədbir zamanı iştirakçılara sığorta sisteminin əsasları, müasir tendensiyalar, sığorta məhsullarının qiymətləndirilməsi və müvafiq sahədə istehlakçı hüquqlarının daha yaxşı öyrənilməsi mövzularında ətraflı məlumat verilib. Diskussiya şəraitində keçirilən tədbirin davamında iştirakçıların sualları cavablandırılıb.',
        images: [
          { id: 1, image: naxcivan1 },
          { id: 2, image: naxcivan1 },
          { id: 3, image: naxcivan1 },
          { id: 4, image: naxcivan1 },
          { id: 5, image: naxcivan1 },
        ],
      },
      {
        id: 4,
        title:
          'Azərbaycan Respublikası Mərkəzi Bankının Naxçıvan Muxtar Respublikası İdarəsi tərəfindən maliyyə savadlılığının artırılmasına yönəlmiş növbəti maarifləndirici tədbir keçirilibNaxçıvan şəhər Hüseyn Cavid adına 5 nömrəli tam orta məktəbdə baş tutan maarifləndirmə tədbirində şagirdlərə “Sığortanın həyatımızdakı rolu” mövzusunda ətraflı məlumat verilmişdir.Tədbirin ikinci hissəsində mövzu üzrə hazırlanmış suallar vasitəsi ilə şagirdlər arasında yarış keçirilərək qaliblərə hədiyyələr təqdim edilmişdir.',
        content: '',
        images: [
          { id: 1, image: naxcivan1 },
          { id: 2, image: naxcivan1 },
          { id: 3, image: naxcivan1 },
          { id: 4, image: naxcivan1 },
          { id: 5, image: naxcivan1 },
        ],
      },
      {
        id: 5,
        title:
          'Mərkəzi Bankın Naxçıvan Muxtar Respublikası İdarəsi tərəfindən Şərur rayonunda vətəndaşların səyyar qəbulu keçirilib',
        content:
          'Azərbaycan Respublikasının Mərkəzi Bankı tərəfindən maliyyə xidmətləri istehlakçılarının və investorların hüquqlarının müdafiəsinin möhkəmləndirilməsi istiqamətində tədbirlər davam etdirilir. Bu çərçivədə növbəti təşəbbüs Şərur rayonunda vətəndaşların səyyar qəbulunun keçirilməsi olub.',
        images: [
          { id: 1, image: naxcivan1 },
          { id: 2, image: naxcivan1 },
          { id: 3, image: naxcivan1 },
          { id: 4, image: naxcivan1 },
          { id: 5, image: naxcivan1 },
        ],
      },
      {
        id: 6,
        title: '“Kibercinayətkarlıq və ona qarşı mübarizə üsulları’’ mövzusunda tədbir keçirilib',
        content:
          'Mərkəzi Bankın Naxçıvan Muxtar Respublikası İdarəsi, Naxçıvan Muxtar Respublikası Prokurorluğu, Naxçıvan Muxtar Respublikası Daxili İşlər Nazirliyi və Naxçıvan Dövlət Universiteti tərəfindən regionda fəaliyyət göstərən idarə və təşkilatlarda “Kibercinayətkarlıq və ona qarşı mübarizə üsulları” mövzusunda maarifləndirici silsilə tədbirlər həyata keçirilib.',
        images: [
          { id: 1, image: naxcivan1 },
          { id: 2, image: naxcivan1 },
          { id: 3, image: naxcivan1 },
          { id: 4, image: naxcivan1 },
          { id: 5, image: naxcivan1 },
        ],
      },
    ],
  },
  contactus: {
    id: 1,
    title: 'Bizimlə Əlaqə',
    type: 'contactus',
    data: {
      text: 'Əlaqə Nömrəsi İdarənin (036) 550 59 10 nömrəsi ilə əlaqə saxlanılır. Whatsapp Aşağıda qeyd olunan istiqamətlər üzrə İdarənin +994 60-400-22-44 nömrəli whatsapp xidmətindən (xidmət) istifadə edilə bilər: 1.Dövlət orqanlarından İdarəyə ünvanlanmış və ya birbaşa olaraq İdarəyə daxil olmuş müraciətlərlə bağlı hər hansı səbəbdən cavab məktubları əldə edilmədikdə. Müraciət edən şəxsin şəxsiyyəti eyniləşdirilməklə cavab məktubu xidmət vasitəsi ilə ona təqdim edilir. 2. İdarənin nəzarət subyektləri ilə əlaqə saxlanılmasında çətinlik yarandıqda. Müraciət edən şəxs barədə məlumat, onunla əlaqə yaradılması məqsədi ilə İdarənin nəzarət subyektinə yönləndirilir. 3. Qəbulda iştirak etmək üçün qeydiyyatdan keçirildikdə. Vətəndaşlar İdarənin “Whatsapp” nömrəsi vasitəsilə qeydiyyatdan keçməklə İdarənin C.Məmmədquluzadə 32 ünvanında yerləşən inzibati binasına gəlməklə “Qəbulotağı”nda yerində qəbulda iştirak edə bilərlər.',
      map: 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3091.886750024249!2d45.418569!3d39.200022!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40142e083d6a5a41%3A0x93856510e63dabec!2zQXrJmXJiYXljYW4gUmVzcHVibGlrYXPEsSBNyZlya8mZemkgQmFua8SxIChOYXjDp8SxdmFuIE11eHRhciBSZXNwdWJsaWthc8SxIMSwZGFyyZlzaSk!5e0!3m2!1sen!2saz!4v1753868016552!5m2!1sen!2saz',
    },
  },
};
