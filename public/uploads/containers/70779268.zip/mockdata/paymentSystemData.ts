import anipayImg from '@/assets/images/aniPayImg.png';
import cardPayImg from '@/assets/images/cardPayImg.jpg';

export const paymentSystem = {
  text: '1992-ci ildə Mərkəzi Bank (həmin vaxt Milli Bank adlanırdı) haqqında qəbul edilmiş Qanuna əsasən, ödəniş sisteminin sabit fəaliyyət göstərməsi və maliyyə hesablaşmalarının həyata keçirilməsi üçün lazımi şəraitin yaradılması Mərkəzi Bankın əsas funksiyalarından birinə çevrilmişdir.',
};
export const settlementSystem = {
  text: 'Real Vaxt Rejimində Hesablaşmalar Sistemi (AZIPS) – real vaxt rejimində işləyən, köçürmələrin ayrı-ayrılıqda hər ödəniş sənədi üzrə emal olunmasını təmin edən məcmu ödənişlər sistemidir. AZIPS-də hesablaşmalar milli (Azərbaycan Manatı - AZN) və xarici valyutalarda aparılır. Sistem 9:20-dən 17:00-a kimi iştirakçılardan ödəniş sənədlərinin qəbulunu həyata keçirir. Əməliyyatlar hər bir iştirakçının Mərkəzi Bankda açılmış müvafiq müxbir hesablarında olan vəsaitlər və digər iştirakçılardan daxil olan vəsaitlər hesabına həyata keçirilir. Müxbir hesablarda vəsait çatışmazlığı yarandıqda ödəniş sənədləri növbədə saxlanılır və iştrakçı tərəfindən təyin olunmuş prioritetlər əsasında emal olunur. Bu prioritetlər çərçivəsində ödəniş sənədləri FIFO (1-ci daxil olan 1-ci emal olunur) prinsipi ilə işlənilir. Növbədə olan sənədlər iştirakçılar tərəfindən geri çağırıla və prioritetləri dəyişdirilə bilər. Vəsait çatışmazlığından gün ərzində növbədə qalan sənədlər günün sonunda sistem tərəfindən avtomatik rejimdə ləğv olunur və bu haqda iştirakçılara müvafiq məlumat göndərilir. Gün ərzində iştirakçıların sorğuları əsasında onlara müxbir hesablarında aparılan əməliyyatlar, növbədə olan sənədlər və qalıq haqqında məlumatlar verilir. İştirakçılar sistemə 10 gün əvvəldən gələcək valyutalaşma tarixi ilə ödəniş sənədləri göndərə bilərlər.',
  filesSection: [
    {
      id: 1,
      sectionTitle:
        'AZİPS-də istifadə edilən məlumat formatları və iştirakçı təşkilatların müxbir hesabları:',
      files: [
        {
          id: 1,
          title:
            'AZIPS-də istifadə edilən elektron ödəniş və xəbərdarlıq məlumatlarının formatları',
          file_url: 'https://uploads.cbar.az/assets/14872234569be8777dc2aa533.zip',
          type: 'zip',
        },
        {
          id: 2,
          title:
            'AZIPS-in iştirakçısı olan təşkilatların milli və xarici valyutalarda olan hesabları (08.08.2024)',
          file_url: 'https://uploads.cbar.az/assets/26c4eeca8c3c3d823b354625e.pdf',
          web_url: 'https://uploads.cbar.az/assets/26c4eeca8c3c3d823b354625e.pdf',
          type: 'pdf',
        },
      ],
    },
    {
      id: 2,
      sectionTitle: 'AZIPS-ə dair texniki sənədlər:',
      files: [
        {
          id: 1,
          title:
            'İştirakçı təşkilatlarla məlumat mübadiləsi üçün nəzərdə tutulmuş proqram təminatının (STP Adapter) quraşdırılma və istifadə qaydaları (ingilis dilində)',
          file_url: 'https://uploads.cbar.az/assets/14872234569be8777dc2aa533.zip',
          type: 'zip',
        },
      ],
    },
    {
      id: 3,
      sectionTitle: 'AZIPS-də istifadə olunan proqram təminatları:',
      files: [
        {
          id: 1,
          title: 'STP Adapter proqram təminatı',
          file_url: 'https://uploads.cbar.az/assets/14872234569be8777dc2aa533.zip',
          type: 'zip',
        },
        {
          id: 2,
          title: 'ChangePassword proqram təminatı',
          file_url: 'https://uploads.cbar.az/assets/14872234569be8777dc2aa533.zip',
          type: 'zip',
        },
        {
          id: 3,
          title: 'Kriptoqrafik kitabxanalar',
          file_url: 'https://uploads.cbar.az/assets/14872234569be8777dc2aa533.zip',
          type: 'zip',
        },
      ],
    },
  ],
};
export const clearingSettlementSystem = {
  text: 'Xırda Ödənişlər üzrə Hesablaşma Klirinq Sistemi (XÖHKS) – xırda, daimi təkrarlanan və təcili olmayan ödənişlərin həyata keçirilməsi üçün yaradılmış klirinq sistemidir. Bu sistemdə ödənişlər çoxtərəfli klirinq prosesi nəticəsində müəyyənləşdirilmiş təmiz mövqelər (netto) əsasında aparıır. Ödəniş sənədləri FİFO ( 1-ci daxil olan 1-ci emal olunur) prinsipi ilə işlənilir. Növbədə olan sənədlər iştirakçılar tərəfindən geri çağrıla və prioritetləri dəyişdirilə bilər. Vəsait çatışmazlığı səbəbindən gün ərzində növbədə qalan ödəniş paketləri günün sonunda sistem tərəfindən avtomatik rejimdə ləğv olunur və bu haqda iştirakçılara müvafiq məlumat göndərilir. Gün ərzində iştirakçıların sorğuları əsasında onlara müxbir hesablarında aparılan əməliyyatlar, növbədə olan ödəniş paketləri və qalıq haqqında məlumatlar verilir. İştirakçılar sistemə 10 gün əvvəldən gələcək valyutalaşma tarixi ilə ödəniş sənədlərini göndərə bilərlər.',
  filesSection: [
    {
      id: 1,
      sectionTitle: 'XÖHKS-də istifadə edilən məlumat formatları:',
      files: [
        {
          id: 1,
          title: 'Lorem ipsum',
          file_url: 'https://uploads.cbar.az/assets/14872234569be8777dc2aa533.zip',
          type: 'zip',
        },
      ],
    },
    {
      id: 2,
      sectionTitle: 'XÖHKS-ə dair texniki sənədlər:',
      files: [
        {
          id: 1,
          title: 'Lorem ipsum',
          file_url: 'https://uploads.cbar.az/assets/14872234569be8777dc2aa533.zip',
          type: 'zip',
        },
        {
          id: 2,
          title: 'Lorem ipsum',
          file_url: 'https://uploads.cbar.az/assets/14872234569be8777dc2aa533.zip',
          type: 'zip',
        },
        {
          id: 3,
          title: 'Lorem ipsum',
          file_url: 'https://uploads.cbar.az/assets/14872234569be8777dc2aa533.zip',
          type: 'zip',
        },
      ],
    },
  ],
};
export const aniPaymentSystem = {
  text: 'Müasir dövrün əsas çağırışı ödəniş xidmətlərinin fiziki və hüquqi şəxslər üçün hər yerdə, hər zaman əlçatan olması və əməliyyatlar üzrə tam hesablaşmaların 24/7/365 rejimində ödənişlərin həyata keçirildiyi anda başa çatdırıla bilməsidir. AÖS-ün yaradılmasında əsas məqsəd Azərbaycanda bank və digər bank olmayan ödəniş xidməti təchizatçılarının müştəriləri olan fiziki və hüquqi şəxslər arasında, həmçinin bu şəxslərlə dövlət orqanları arasında hesablaşmaların 24/7/365 rejimində aparıla bilməsinin təmin edilməsidir. Bu sistemdə vəsaiti ödəyənlə vəsaiti alan arasında aparılan hesablaşmalar 5-20 saniyə ərzində hər iki tərəfin xəbərdarlıq alması ilə tam başa çatdırılır. Sistemdə aparılan əməliyyatlar üzrə autentifikasiya, avtorizasiya, klirinq və hesablaşmalar vahid tranzaksiya formatında real rejimdə həyata keçirilir.',
  moduls: [
    {
      id: 1,
      slug: 'central-modul',
      title: 'Mərkəzi əlaqələndirmə modulu',
      short_description:
        '“Mərkəzi əlaqələndirmə” modulu Ani Ödənişlər Sistemi komponentlərindən biri olmaqla, bank müştərilərinin hesab rekvizitlərinin saxlanılması və identifikasiya vasitələri ilə əlaqələndirilməsinə xidmət edir, eləcə də məlumatların bir mərkəzdən idarə edilməsini təmin edir. Sadə identifikatorlar qismində müştərinin istəyinə uyğun olaraq fiziki şəxslər üzrə mobil nömrə, e-mail, FİN, fərdi sahibkar və hüquqi şəxslər üzrə isə mobil nömrə, e-mail, VÖEN, obyekt kodu və təsərrüfat subyektinin identifikatoru çıxış edə bilər. Hər bir identifikator müştərinin bank hesabı ilə əlaqələndirilməklə ödəniş və köçürmələr zamanı vəsaitin həmin hesaba mədaxil/məxaricini reallaşdırmış olur.',
    },
    {
      id: 2,
      slug: 'open-banking',
      title: 'Açıq bankçılıq',
      short_description:
        'Ənənəvi bankçılıq sistemlərində müştərilərin hesab məlumatlarına giriş hüququ yalnız onların banklarına məxsus olurdu. Açıq bankçılıq prinsiplərinə görə isə banklar müştəri məlumatlarının saxlanılması qismində iştirak etməklə, yalnız bank müştərilərinin icazəsi müqabilində maliyyə məlumatlarının etibarlı yol ilə 3-cü tərəf rəqəmsal platformalarda görünməsini və əməliyyat apara bilmələrini təmin edir.',
    },
    {
      id: 3,
      slug: 'anipay-portal',
      title: 'AniPay Portal',
      short_description:
        'Ani Ödənişlər Sistemi üzrə yaradılmış “AniPay” portalı, mobil tətbiq və veb sayt formasında vətandaşların istifadəsinə verilmişdir. Bütün bank hesablarının bir nöqtədən idarə olunduğu bu portal vasitəsi ilə istifadəçilər qeydiyyatdan keçə, hesablararası köçürmə və kommunal və büdcə təşkilatları xeyrinə ödəmələrini, eləcə də QR ödənişlərini sürətli və rahat bir şəkildə icra edə bilərlər.',
    },
    {
      id: 4,
      slug: 'pay-request',
      title: 'Ödəniş sorğusu',
      short_description:
        'Ani Ödənişlər Sistemində bir alıcının fiziki və ya onlayn istifadə halında bir ödəyicidən ödənişin başlanmasını tələb etməsinə imkan verən əməliyyat axını ödəniş sorğusu adlanır. Ödəniş sorğusu ödəmə vasitəsi və ya ödəmə aləti olmamaqla, yalnız ödənişin başlanmasını tələb etmək üçün sorğulama funksiyadır.',
    },
  ],
  integratedOrganizations: {
    title: 'Ani Ödənişlər Sisteminə inteqrasiya olunmuş təşkilatlar',
    text: 'burada editordan gelecek',
  },
  faqSection: {
    title: 'Tez- tez verilən suallar',
    faq: [
      {
        id: 1,
        title: 'AniPay nədir?',
        description:
          'Mərkəzi Bank tərəfindən yaradılmış və fiziki şəxslər, biznes qurumları və dövlət orqanları arasında ödəniş əməliyyatlarının 24/7 rejimində bank hesabları üzərindən sadələşdirilmiş identifikatorlar vasitəsilə (FİN kod, VÖEN, mobil nömrə, e-poçt) aparılmasına imkan verən sistemdir.',
      },
      {
        id: 2,
        title: 'AniPay sistemində qeydiyyatdan necə keçib istifadə edə bilərəm?',
        description:
          'AniPay sisteminə qoşulmuş bankın müştərisisinizsə həmin bankın mobil tətbiqi, AniPay mobil tətbiqi və ya internet bankçılıq xidməti vasitəsilə sistemdə qeydiyyatdan keçib istifadə edə bilərsiniz.',
      },
      {
        id: 3,
        title: 'AniPay sistemi ilə hansı valyutalarla əməliyyat aparmaq mümkündür?',
        description: 'AniPay sistemi ilə yalnız Azərbaycan manat ilə əməliyyat aparmaq mümkündür.',
      },
    ],
  },
};
export const moduleData = {
  title: 'Lorem ipsum',
  description: 'editordan gelecek',
};
export const interbankCardCenter = {
  text: 'Banklararası Kart Mərkəzi (BKM) – ölkədə prosessinq fəaliyyəti göstərən və Beynəlxalq Kart Təşkilatlarına (BKT) birbaşa çıxışı olan bütün təşkilatların xidmət şəbəkələri arasında interfeysin təmin edilməsi, rezident banklar tərəfindən emissiya edilmiş ödəniş kartları ilə ölkə daxilində aparılan kart əməliyyatlarının emalı prosessinin bu infrastruktur vasitəsi ilə həyata keçirilməsi ilə təhlükəsizlik səviyyəsinin yüksəldilməsi, aparılan kart əməliyyatlarının effektivliyinin artırılması üçün tətbiq olunan banklararası xidmət haqlarının bazar tələblərinə uyğun çevik tənzimlənməsi, kart infrastrukturu iştirakçılarının xərclərinin aşağı salınması məqsədi ilə yaradılmışdır.',
};
export const hop = {
  text: 'Hökumət Ödəniş Portalı (HÖP) – dövlət orqanları tərəfindən göstərilən elektron xidmətlər üzrə ödənişlərin elektron qaydada toplanılmasının təmin edilməsi, büdcə ödənişlərinin aparılması prosesinin sadələşdirilməsi və birbaşa emalının təşkili, kommunal, rabitə, sığorta və digər ödənişlərin vahid platformadan toplanılmasının təmin edilməsi məqsədilə yaradılmışdır. HÖP-ün yaradılmasında başlıca məqsədlərdən biri də Milli Ödəniş Sistemi infrastrukturundan daha səmərəli istifadənin təmin olunması, ölkənin bütün regionlarında elektron ödəniş xidmətlərinə çıxış imkanlarının genişləndirilməsi olmuşdur.',
};
export const reglamentsTariffs = {
  filesSection: [
    {
      id: 1,
      sectionTitle: 'Reqlament',
      files: [
        {
          id: 1,
          title:
            'Mərkəzi Bankda açılmış hesablar üzrə hesablaşma-kassa xidmətinin göstərilməsi reqlamenti (01.09.2022-ci il tarixindən etibarən)',
          file_url: 'https://uploads.cbar.az/assets/336c1296baaf2895b27b0ee08.pdf',
          web_url: 'https://uploads.cbar.az/assets/336c1296baaf2895b27b0ee08.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title: 'Ani Ödənişlər Sistemi vasitəsilə əməliyyatların aparılması reqlamenti',
          file_url: 'https://uploads.cbar.az/assets/2adf5beead73949646747b629.pdf',
          web_url: 'https://uploads.cbar.az/assets/2adf5beead73949646747b629.pdf',
          type: 'pdf',
        },
      ],
    },
    {
      id: 2,
      sectionTitle: 'Tariflər',
      files: [
        {
          id: 1,
          title:
            'Mərkəzi Bank tərəfindən banklararası mərkəzləşdirilmiş ödəniş sistemləri üzrə tətbiq edilən xidmət haqqı tarifləri (01.09.2022-ci il tarixindən etibarən)',
          file_url: 'https://uploads.cbar.az/assets/e09924ef4eec02cc67c66cd6f.pdf',
          web_url: 'https://uploads.cbar.az/assets/e09924ef4eec02cc67c66cd6f.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title: 'Ani Ödənişlər Sistemi üzrə tətbiq edilən xidmət haqqı tarifləri',
          file_url: 'https://uploads.cbar.az/assets/b0421fb77f1cee8fca37ae243.pdf',
          web_url: 'https://uploads.cbar.az/assets/b0421fb77f1cee8fca37ae243.pdf',
          type: 'pdf',
        },
      ],
    },
  ],
};
export const participants = {
  filesSection: [
    {
      id: 1,
      files: [
        {
          id: 1,
          title:
            'Azərbaycan Respublikasında fəaliyyət göstərən, AZİPS sisteminə üzv olan təşkilatların rekvizitləri (08.08.2024)',
          file_url: 'https://uploads.cbar.az/assets/336c1296baaf2895b27b0ee08.pdf',
          web_url: 'https://uploads.cbar.az/assets/336c1296baaf2895b27b0ee08.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title:
            'Azərbaycan Respublikasında fəaliyyət göstərən, XÖHKS sisteminə üzv olan təşkilatların rekvizitləri (08.08.2024)',
          file_url: 'https://uploads.cbar.az/assets/2adf5beead73949646747b629.pdf',
          web_url: 'https://uploads.cbar.az/assets/2adf5beead73949646747b629.pdf',
          type: 'pdf',
        },
        {
          id: 3,
          title:
            'Azərbaycan Respublikasında fəaliyyət göstərən, AÖS sisteminə üzv olan təşkilatların rekvizitləri (08.08.2024)',
          file_url: 'https://uploads.cbar.az/assets/2adf5beead73949646747b629.pdf',
          web_url: 'https://uploads.cbar.az/assets/2adf5beead73949646747b629.pdf',
          type: 'pdf',
        },
      ],
    },
    {
      id: 2,
      sectionTitle: 'Milli Ödəniş Sistemi iştirakçılarının məlumat kitabçası (Format PDF):',
      files: [
        {
          id: 1,
          title:
            'Azərbaycan Respublikasında fəaliyyət göstərən maliyyə institutlarının məlumat kitabçası (03.09.2025)',
          file_url: 'https://uploads.cbar.az/assets/336c1296baaf2895b27b0ee08.pdf',
          web_url: 'https://uploads.cbar.az/assets/336c1296baaf2895b27b0ee08.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title: 'Məlumat kitabçasında dəyişiklik (03.09.2025)',
          file_url: 'https://uploads.cbar.az/assets/f15ed2b0db555c847ae73a25c.zip',
          type: 'zip',
        },
      ],
    },
    {
      id: 3,
      sectionTitle: 'Milli Ödəniş Sistemi iştirakçılarının məlumat kitabçası (Format XML):',
      files: [
        {
          id: 1,
          title: 'Məlumat kitabçası (baş ofislər və filiallar - 03.09.2025)',
          web_url: 'https://www.cbar.az/bankinfonew/banks.xml',
          file_url: 'https://www.cbar.az/bankinfonew/banks.xml',
          type: 'xml',
        },
        {
          id: 2,
          title: 'Məlumat kitabçası (baş ofislər - (03.09.2025)',
          web_url: 'https://www.cbar.az/bankinfonew/headoffices.xml',
          file_url: 'https://www.cbar.az/bankinfonew/headoffices.xml',
          type: 'xml',
        },
      ],
    },
    {
      id: 4,
      sectionTitle:
        'Elektron pul təşkilatları və ödəniş təşkilatlarının məlumat kitabçası (Format PDF):',
      files: [
        {
          id: 1,
          title:
            'Azərbaycan Respublikasında fəaliyyət göstərən elektron pul təşkilatları və ödəniş təşkilatlarının məlumat kitabçası (01.08.2025)',
          file_url: 'https://uploads.cbar.az/assets/336c1296baaf2895b27b0ee08.pdf',
          web_url: 'https://uploads.cbar.az/assets/336c1296baaf2895b27b0ee08.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title: 'Məlumat kitabçasında dəyişiklik (01.08.2025)',
          file_url: 'https://uploads.cbar.az/assets/19eddafb628f756c0e439bf3e.zip',
          type: 'zip',
        },
      ],
    },
    {
      id: 5,
      sectionTitle:
        'Azərbaycan Respublikasında fəaliyyət göstərən elektron pul təşkilatları və ödəniş təşkilatlarının məlumat kitabçası (Format XML):',
      files: [
        {
          id: 1,
          title: 'Məlumat kitabçası (01.08.2025)',
          web_url: 'https://www.cbar.az/bankinfonew/NBPSP_headoffices.xml',
          file_url: 'https://www.cbar.az/bankinfonew/NBPSP_headoffices.xml',
          type: 'xml',
        },
        {
          id: 2,
          title: 'Məlumat kitabçasında dəyişiklik (01.08.2025)',
          web_url: 'https://www.cbar.az/bankinfonew/NBPSP_updatehistory.xml',
          file_url: 'https://www.cbar.az/bankinfonew/NBPSP_updatehistory.xml',
          type: 'xml',
        },
      ],
    },
  ],
};
export const ISO20022 = {
  text: 'Azərbaycan Respublikası Prezidentinin 26 sentyabr 2018-ci il tarixli, 508 saylı Sərəncamı ilə təsdiq edilmiş “2018–2020-ci illərdə Azərbaycan Respublikasında rəqəmsal ödənişlərin genişləndirilməsi üzrə Dövlət Proqramı”nda göstərilən tədbirlərin icrası çərçivəsində “Azərbaycan Respublikasının Milli Ödəniş Sistemi infrastrukturunda ISO20022 beynəlxalq standartının tətbiq edilməsi üzrə Tədbirlər Planı” hazırlanaraq təsdiq edilmişdir.',
  files: [
    {
      id: 1,
      title:
        'Azərbaycan Respublikasının Milli Ödəniş Sistemi infrastrukturunda ISO20022 beynəlxalq standartının tətbiq edilməsi üzrə Tədbirlər Planı',
      file_url: 'https://uploads.cbar.az/assets/c07c2a59fab92eef2cbbf39ed.pdf',
      web_url: 'https://uploads.cbar.az/assets/c07c2a59fab92eef2cbbf39ed.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: 'ISO 20022 haqqında kitabça',
      file_url: 'https://uploads.cbar.az/assets/7168164e058bd42357c59d561.pdf',
      web_url: 'https://uploads.cbar.az/assets/7168164e058bd42357c59d561.pdf',
      type: 'pdf',
    },
  ],
  faq: [
    {
      id: 1,
      title: 'ISO 20022 nədir?',
      description:
        'Bu standart, qurumların ardıcıl bir şəkildə istifadə etməyi qəbul etdikləri elə ümumi bir mesaj və dil vasitəsidir ki, qlobal miqyasda maliyyə qurumları arasında ödənişlərin klirinq və hesablaşmasının daha səmərəli təşkilinə imkan verir. Fərqli maliyyə bazarlarındakı iştirakçılara və sistemlərə (məsələn, ödəmələr, qiymətli kağızlar, xarici valyuta, kartlar) ödəniş mesajları daxilində qarşılıqlı əlaqəni və daha çox pul köçürmə məlumatını dəstəkləyən ardıcıl terminologiya və ya sintaksis istifadə edərək ünsiyyət qurmağa imkan verir. Hər kəsin istifadə edə biləcəyi və hər kəsin töhfə verə biləcəyi açıq bir standartdır.',
    },
    {
      id: 2,
      title: 'Mərkəzi Bank niyə Azərbaycanda ISO 20022 standartını tətbiq edir?',
      description:
        'Azərbaycanın əsas ödəmə infrastrukturu illərdir yaxşı performans üçün, eləcə də klirinq və hesablaşma dövrləri üçün yerli maliyyə sektorunu dəstəkləmişdir. Rəqəmsal texnologiyaların dəyişməsi, istifadəçi tələblərinin, yeni iştirakçıların və qlobal ödəniş sisteminin dəyişməsi Azərbaycan iqtisadiyyatına da təsir etmişdir. Ölkədə nağdsız ödəniş əməliyyatlarının effektivliyini artırmaq, ödənişlərdə avtomatik emal əmsalını yüksəltmək, hesablaşmaları daha qısa müddətə aparmaq üçün ISO 20022 standartının tətbiqi “2018-2020-ci illərdə rəqəmsal ödənişlərin genişləndirilməsi üzrə Dövlət Proqramı”nda prioritet hesab olunmuşdur.',
    },
    {
      id: 3,
      title: 'Genişləndirilmiş ödəniş məlumatı nədir?',
      description:
        'Ödənişlər haqqında məlumatın genişləndirilməsi dedikdə, ödənişi alacaq sistemlərin hesablarında kommersiya fakturalarda olduğu kimi ödəniş məlumatının daxil olunmasını, uyğunlaşdırılması və uzlaşdırılmasını nəzərdə tutur.',
    },
  ],
};
export const iban = {
  text: 'IBAN - Bankçılıq Standartları üzrə Avropa Komitəsi (ECBS) və Standartlaşdırma üzrə Beynəlxalq Təşkilat (ISO) tərəfindən müəyyən edilmiş ISO 136161 beynəlxalq standartına uyğun olaraq yaradılan və maliyyə institutları tərəfindən müştərilərə təqdim edilən bank hesab nömrəsidir. Azərbaycanda bank hesab nömrələrinə IBAN-ın tətbiqinin məqsədi banklarda, poçt-maliyyə xidmətləri göstərən poçt rabitəsi milli operatorunda və Maliyyə Nazirliyinin Dövlət Xəzinədarlıq Agentliyində (bundan sonra - maliyyə institutları) mövcud olan hesab nömrələrinin beynəlxalq standartlar əsasında unifikasiya olunmasıdır.',
  files: [
    {
      id: 1,
      title: 'Standart bank hesab nömrəsi (IBAN) üzrə metodoloji rəhbərlik',
      file_url: 'https://uploads.cbar.az/assets/3e17089bf968ea353e9f9246e.pdf',
      web_url: 'https://uploads.cbar.az/assets/3e17089bf968ea353e9f9246e.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: 'IBAN strukturlu bank hesabinin generasiyası və yoxlanılması',
      file_url: 'https://uploads.cbar.az/assets/c37440293894da1496857be5e.xls',
      type: 'xls',
    },
  ],
  faq: [
    {
      id: 1,
      title: 'IBAN nədir?',
      description:
        'Bankçılıq Standartları üzrə Avropa Komitəsi (ECBS) və Standartlaşdırma üzrə Beynəlxalq Təşkilat (ISO) tərəfindən müəyyən edilmiş ISO 13616 beynəlxalq standartına uyğun olaraq yaradılan və banklar, poçt-maliyyə xidmətləri göstərən poçt rabitəsi milli operatoru və Maliyyə Nazirliyinin Dövlət Xəzinədarlıq Agentliyi (maliyyə institutları) tərəfindən müştərilərə təqdim edilən standart bank hesab nömrəsidir.',
    },
    {
      id: 2,
      title: 'IBAN-ın tətbiq edilməsində məqsəd nədir?',
      description:
        'Elektron ödəniş məkanında bank müştərilərinin identifikasiya edilməsini təkmilləşdirmək, ödənişlərin emalı zamanı avtomatlaşdırılma səviyyəsini yüksəltmək, bank hesablarının strukturundakı pərakəndəliyi aradan qaldırmaq və əməliyyat risklərini minimallaşdırmaqdır.',
    },
    {
      id: 3,
      title: 'IBAN layihəsinə nə vaxtdan start verilmişdir?',
      description:
        'Mərkəzi Bankın, Vergilər Nazirliyinin, Maliyyə Nazirliyinin, Dövlət Sosial Müdafiə Fondunun, Banklar Assosiasiyasının və kommersiya banklarının (Beynəlxalq Bank, Kapital Bank, Unibank, Bank Respublika və Muğanbank) nümayəndələrindən ibarət 17.06.2010-cu il tarixində yaradılmış İşçi Qrupu (İQ) tərəfindən IBAN layihəsinin tətbiqinə başlanılmışdır.',
    },
  ],
};
export const governmentPrograms = {
  text: 'Ölkə ərazisində ödəniş sistemlərinin sabit, etibarlı, təhlükəsiz fəaliyyətinin təşkili, əlaqələndirilməsi, tənzimlənməsi və nəzarəti, habelə müasir trendlər nəzərə alınmaqla davamlı olaraq inkişaf etdirilməsi Mərkəzi Bankın əsas fəaliyyət istiqamətlərindən biridir. Qarşıya qoyulan hədəflərə nail olmaq məqsədilə Mərkəzi Bank aidiyyəti dövlət qurumları, beynəlxalq təşkilatlar və bank sektoru ilə birlikdə ölkədə elektron ödəniş sistemlərinin inkişafı və nağdsız ödənişlərin genişləndirilməsi istiqamətində davamlı olaraq ölkə miqyaslı layihələr reallaşdırır və strateji təşəbbüslər həyata keçirir.',
  filesSection: [
    {
      id: 1,
      sectionTitle: 'Dövlət proqramları:',
      files: [
        {
          id: 1,
          title: 'lorem ipsum',
          file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
          web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title: 'lorem ipsum',
          file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
          web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
          type: 'pdf',
        },
      ],
    },
    {
      id: 2,
      sectionTitle: 'Dövlət Proqramlarının icrası haqda hesabatlar:',
      files: [
        {
          id: 1,
          title: 'Lorem ipsum',
          file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
          web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title: 'Lorem ipsum',
          file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
          web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
          type: 'pdf',
        },
      ],
    },
  ],
};
export const digitalPaymentStrategy = {
  files: [
    {
      id: 1,
      title:
        'Azərbaycan Respublikası Mərkəzi Bankının 2021-2023-cü illər üçün Rəqəmsal Ödəniş Strategiyası',
      file_url: 'https://uploads.cbar.az/assets/cf20ce4afe5762718226b3dc0.pdf',
      web_url: 'https://uploads.cbar.az/assets/cf20ce4afe5762718226b3dc0.pdf',
      type: 'pdf',
    },
  ],
};
export const nominations = {
  text: 'Mərkəzi Bank tərəfindən banklar arasında maliyyə vasitəçiliyində innovasiyaların tətbiqinin genişləndirilməsi, elektron bankçılıq xidmətlərinin inkişaf etdirilməsi, nağdsız ödəniş alətlərindən istifadənin artırılması məqsədi ilə 2013-cü ildən illik əsasda nominasiya müsabiqəsi keçirilir. Müsabiqə çərçivəsində statistik məlumatlar təhlil edilərək bankların illik fəaliyyətləri qiymətləndirilir və elan edilmiş nominasiya şərtləri üzrə daha yüksək göstəriciyə malik olan banklar mükafatlandırılır.',
  filesSection: [
    {
      id: 1,
      sectionTitle: 'Nominasiya şərtləri:',
      files: [
        {
          id: 1,
          title: '2020-ci il üzrə nominasiya şərtləri',
          file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
          web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
          type: 'pdf',
        },
      ],
    },
    {
      id: 2,
      sectionTitle: 'Nominasiya müsabiqələrinin qalibləri:',
      files: [
        {
          id: 1,
          title: '2020-ci il üzrə qalib banklar',
          file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
          web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
          type: 'pdf',
        },
      ],
    },
  ],
};
export const payWithAniPay2021 = {
  title: '“AniPay ilə ödə və qazan” adlı stimullaşdırıcı lotereya',
  image: anipayImg,
  description:
    'Cəmiyyətdə rəqəmsal ödəniş vərdişlərinin formalaşdırılması və iqtisadiyyatda nağdsız dövriyyənin artırılması, habelə innovativ ödəniş həlləri təqdim edən Ani Ödənişlər Sistemindən (AÖS) istifadənin təşviqi məqsədilə Mərkəzi Bank tərəfindən 2021-ci ilin noyabr ayı ərzində “AniPay ilə ödə və qazan” adlı stimullaşdırıcı lotereya keçiriləcək.',
  files: [
    {
      id: 1,
      title: 'Lotereyanın şərtləri',
      file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      type: 'pdf',
    },
  ],
};
export const payWithCard2020 = {
  title: '“Kartla ödə, kartla qazan” adlı stimullaşdırıcı lotereya',
  image: cardPayImg,
  description:
    'Geniş əhali təbəqəsinin ödəniş kartlarından istifadəyə stimullaşdırılması, cəmiyyətdə nağdsız ödəniş vərdişlərinin formalaşdırılması və iqtisadiyyatda nağdsız dövriyyənin artırılması məqsədilə Mərkəzi Bank tərəfindən 1 noyabr 2020-ci il tarixindən başlayaraq “Kartla ödə, kartla qazan” adlı stimullaşdırıcı lotereya keçiriləcək.',
  files: [
    {
      id: 1,
      title: 'Lotereyanın şərtləri',
      file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: 'Lotereya qaliblərinin siyahısı',
      file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      type: 'pdf',
    },
  ],
};
export const payWithCard2019 = {
  title: '“Kartla ödə, kartla qazan” adlı stimullaşdırıcı lotereya',
  image: cardPayImg,
  description:
    'Rəqəmsal ödənişlərin stimullaşdırılması və nağdsız ödəniş vərdişlərinin formalaşdırılması məqsədilə Mərkəzi Bank tərəfindən 1 fevral 2019-cu il tarixindən başlayaraq geniş əhali təbəqəsini əhatə edən 3 aylıq “Kartla ödə, kartla qazan” adlı stimullaşdırıcı lotereya keçiriləcək. Üç tiraj üzrə keçiriləcək stimullaşdırıcı lotereya, müvafiq olaraq fevral, mart və aprel ayları ərzində Azərbaycan bankları tərəfindən emissiya edilmiş bütün növ ödəniş kartları ilə ölkədə fəaliyyət göstərən təsərrüfat subyektlərində (mağaza, restoran və s.) quraşdırılmış POS-terminallarda minimum 5 (beş) manat məbləğində nağdsız əməliyyat aparan kart istifadəçiləri avtomatik olaraq kampaniyada iştirak hüququ əldə edəcəklər. Lotereyanın uduş məbləği 50 (əlli) manat məbləğində kart sahibinin bank hesabına daxil edilərək “cashback” şəklində təqdim olunacaq. Bu barədə kart hesabına xidmət edən bank tərəfindən müştərilər məlumatlandırılacaq.',
  videos: [
    {
      id: 1,
      title: 'Lotereya haqqında video çarx',
      videoUrl: 'https://youtu.be/jkqFeDYmwaM',
    },
    {
      id: 2,
      title: 'ATV kanalına müsahibə',
      videoUrl: 'https://youtu.be/1BJOxwjOLek',
    },
  ],
  files: [
    {
      id: 1,
      title: 'Lotereyanın şərtləri',
      file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: 'Tiraj komissiyası',
      file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      type: 'pdf',
    },
    {
      id: 3,
      title: '"Kartla ödə, kartla qazan" - lotereyasının 1-ci tirajının qalibləri',
      file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      type: 'pdf',
    },
  ],
  faq: [
    {
      id: 1,
      title: 'Lotereyada necə iştirak edə bilərəm?',
      description:
        'Lotereyaya qoşulmaq üçün xüsusi müraciət tələb olunmur. Pos-terminal vasitəsilə minimum 5 (beş) manat məbləğində nağdsız əməliyyat aparan hər bir kart istifadəçisi avtomatik olaraq lotereyada iştirak hüququ əldə edəcəkdir',
    },
    {
      id: 2,
      title: 'Lotereyanın uduş məbləği nə qədərdir?',
      description: 'Hər qalib 50 (əlli) manat məbləğində uduş məbləği əldə edəcək.',
    },
    {
      id: 3,
      title: 'Lotereya neçə tirajdan ibarət olacaq və tirajlar nə vaxt keçiriləcək?',
      description:
        'Lotereya 1 fevral 2019-cu il tarixindən 30 aprel 2019-cu il tarixinədək 3 tirajda təşkil ediləcəkdir. 1-ci tirajın uduş fondu 15 mart 2019-cu il, 2-ci tirajın uduş fondu 12 aprel 2019-cu il, 3-cü tirajın uduş fondu isə 15 may 2019-cu il tarixində oynanılacaqdır.',
    },
  ],
};
export const payWithVisa = {
  title: '“Visa kartları ilə ödəniş qazandırır!” adlı tirajlı stimullaşdırıcı lotereya',
  description:
    'Geniş əhali təbəqəsinin ödəniş kartlarından istifadəyə stimullaşdırılması, cəmiyyətdə nağdsız ödəniş vərdişlərinin formalaşdırılması və iqtisadiyyatda nağdsız dövriyyənin artırılması məqsədilə Mərkəzi Bank Visa Beynəlxalq Xidmət Assosiasiyasının dəstəyi ilə 1 mart 2020-ci il tarixindən başlayaraq geniş əhali təbəqəsini əhatə edən 2 aylıq “Visa kartları ilə ödəniş qazandırır!” adlı stimullaşdırıcı lotereya keçirəcək. İki tiraj üzrə keçiriləcək stimullaşdırıcı lotereyada Azərbaycan bankları tərəfindən emissiya edilmiş “Visa” brendli ödəniş kartları ilə ölkədə fəaliyyət göstərən təsərrüfat subyektlərində (mağaza, restoran və s.) quraşdırılmış POS-terminallarda minimum 5 (beş) manat məbləğində nağdsız əməliyyat aparan kart istifadəçiləri avtomatik olaraq kampaniyada iştirak hüququ əldə edəcəklər. Lotereyanın uduş məbləği 100 (bir yüz) manat məbləğində kart sahibinin bank hesabına daxil edilərək “cashback” şəklində təqdim olunacaq. Bu barədə müştərilər kart hesabına xidmət edən bank tərəfindən məlumatlandırılacaq.',
  files: [
    {
      id: 1,
      title: 'Lotereyanın şərtləri',
      file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: 'Visa kartları ilə ödəniş qazandırır - lotereyasının 1-ci tirajının qalibləri',
      file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      type: 'pdf',
    },
    {
      id: 3,
      title: 'Visa kartları ilə ödəniş qazandırır - lotereyasının 2-ci tirajının qalibləri',
      file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      type: 'pdf',
    },
  ],
};
export const legalBasisPaymentSystem = {
  files: [
    {
      id: 1,
      title: 'Azərbaycan Respublikası Mərkəzi Bankının ödəniş sistemləri üzrə nəzarət konsepsiyası',
      file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title:
        'Maliyyə bazarı infrastrukturları üçün prinsiplər: Açıqlanma çərçivəsi və Qiymətləndirmə metodologiyası',
      file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      type: 'pdf',
    },
    {
      id: 3,
      title:
        'AZIPS-in iştirakçılarının fövqəladə hallar zamanı Fəaliyyətinin Davamlılığının təmin edilməsi üzrə Tövsiyələr',
      file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
      type: 'pdf',
    },
  ],
};
export const oversightSystemicallyBanks = {
  text: '“Azərbaycan Respublikası Mərkəzi Bankının ödəniş sistemləri üzrə nəzarət konsepsiyasın”a və “Azərbaycan Respublikasında banklararası mərkəzləşdirilmiş ödəniş sistemlərində hesablaşmaların təşkili Qaydaları”na əsasən hər il Mərkəzi Bankın operatoru olduğu AZİPS üzrə il ərzində iştirakçılar tərəfindən aparılmış əməliyyatların ümumi həcminin 2 faizindən çox paya malik olan iştirakçılar sistem əhəmiyyətli iştirakçı kimi qiymətləndirilir. Sistem əhəmiyyətli iştirakçı fövqəladə hallarda sistemlərin fəaliyyətinin davamlılığını təmin etmək məqsədi ilə ehtiyat mərkəz yaratmalı və fövqəladə hallara hazırlıq səviyyəsini yoxlamaq üçün ən azı rübdə bir dəfə real vaxt rejimində ödəniş sistemlərində iştirakını ehtiyat mərkəz vasitəsilə təmin etməlidir. Sistem əhəmiyyətli iştirakçı ehtiyat mərkəzdə həyata keçirdiyi fəaliyyəti başa çatdırdıqdan sonra nəticəsi barədə hesabatı Qaydaların 1 nömrəli əlavəsinə uyğun dolduraraq Mərkəzi Banka yazılı formada təqdim etməlidir.',
};
export const oversightPaymentInstruments = {
  text: 'Azərbaycan Respublikasının Mərkəzi Bankı ödəniş alətlərinə nəzarət tədbirlərini ”Azərbaycan Respublikası Mərkəzi Bankının ödəniş sistemləri üzrə nəzarət konsepsiyası”, “Ödəniş kartlarının emissiyası və istifadə Qaydaları”, beynəlxalq kart təşkilatlarının və ümumqəbul edilmiş prinsiplər əsasında həyata keçirir. Ödəniş alətlərinə nəzarətin əsas məqsədləri aşağıdakılardır:',
};
export const moneyTransferSystems = {
  text: 'editorden gelecek',
};
export const serviceCenterProssingActivities = {
  serviceCenters: [
    {
      id: 1,
      title: '"AZƏRİKARD" MƏHDUD MƏSULİYYƏTLİ CƏMİYYƏTİ',
      description: 'editordan gelecek',
    },
    {
      id: 2,
      title: '"MİLLİKART" MƏHDUD MƏSULİYYƏTLİ CƏMİYYƏTİ',
      description: 'editordan gelecek',
    },
  ],
  prossingActivities: {
    text: '1. “Kapital Bank” ASC, 2. “Paşa Bank” ASC, 3. “UniBank” ASC, 4. “Bank of Baku” ASC, 5. “Yapı-Kredi Bank Azərbaycan” QSC, 6. “Azər-Türk Bank” ASC',
  },
};
export const digitalPaymentsOverview = [
  {
    id: 1,
    title: '2024',
    files: [
      {
        id: 1,
        title: 'Rəqəmsal ödənişlər icmalı - 2024',
        file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
        web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
        type: 'pdf',
      },
    ],
  },
  {
    id: 2,
    title: '2023',
    files: [
      {
        id: 1,
        title: 'Rəqəmsal ödənişlər icmalı - 2023',
        file_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
        web_url: 'https://uploads.cbar.az/assets/c2dca9e0e958e8e02ea4593bf.pdf',
        type: 'pdf',
      },
    ],
  },
];
