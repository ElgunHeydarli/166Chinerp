export const banks = {
  text: 'Azərbaycan Respublikasının bank sistemi maliyyə bazarlarına nəzarət orqanı olan Azərbaycan Respublikasının Mərkəzi Bankından (Mərkəzi Bank) və kredit təşkilatlarından ibarətdir.Bank - fiziki və hüquqi şəxslərdən depozitlərin və ya digər qaytarılan vəsaitlərin cəlb edilməsi, öz adından və öz hesabına kreditlərin verilməsini, habelə müştərilərin tapşırığı ilə köçürmə və hesablaşma-kassa əməliyyatlarını məcmu halda həyata keçirən hüquqi şəxsdir.Mərkəzi Bank bankların, filialların, şöbələrin və nümayəndəliklərin ictimaiyyət üçün açıq olan mərkəzi reyestrini tərtib edir.',
  files: [
    {
      id: 1,
      title: 'Banklar',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
  ],
  accordions: [
    {
      id: 1,
      title: '“ACCESSBANK” QSC',
      detail: 'editordan gelen data',
    },
    {
      id: 2,
      title: '“AZƏRBAYCAN BEYNƏLXALQ BANKI” ASC',
      detail: 'editordan gelen data',
    },
  ],
};
export const bokts = {
  text: 'Bank olmayan kredit təşkilatı (BOKT) xüsusi razılıq (lisenziya) əsasında kreditlərin verilməsi və “Bank olmayan kredit təşkilatları haqqında” Azərbaycan Respublikasının Qanunu nəzərdə tutulmuş digər fəaliyyət növlərini həyata keçirən ixtisaslaşmış kredit təşkilatıdır.',
  files: [
    {
      id: 1,
      title: 'Boktlar',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
  ],
  accordions: [
    {
      id: 1,
      title: 'BOKT "Avrasiya-kredit" MMC',
      detail: 'editordan gelen data',
    },
    {
      id: 2,
      title: '“Azərbaycan Mikro-Kredit BOKT” ASC',
      detail: 'editordan gelen data',
    },
  ],
};
export const creditUnions = {
  text: 'Kredit ittifaqı mənafe ümumiliyi əsasında könüllü birləşən fiziki şəxslərin və (və ya) kiçik sahibkarlıq subyekti olan hüquqi şəxslərin sərbəst pul vəsaitlərini cəmləşdirmək yolu ilə özlərinin qarşılıqlı kreditləşdirilməsi üçün yaratdıqları bank olmayan kredit təşkilatıdır.',
};
export const banksPaymentAgents = {
  text: 'Bank, ödəniş təşkilatı və elektron pul təşkilatı “Ödəniş xidmətləri və ödəniş sistemləri haqqında” Qanunun 3.1.1-ci, 3.1.2-ci və 3.1.4-cü maddələrində nəzərdə tutulmuş ödəniş xidmətlərinin göstərilməsi, bank və elektron pul təşkilatı eyni zamanda elektron pulun satışı və elektron pulun qalıq dəyərinin geri ödənilməsi üçün ölkə daxilində ödəniş agentini cəlb edə bilərlər. Ödəniş xidməti təchizatçısı cəlb etdiyi ödəniş agentlərinin ödəniş xidmətləri üzrə fəaliyyətinə görə tam məsuliyyət daşıyır.',
  files: [
    {
      id: 1,
      title: 'Bankların ödəniş agentləri',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
  ],
};

export const registrationSecurities = {
  text: 'Kapital bazarının əsas iştirakçılarından biri emitentlərdir. Emitent investisiya qiymətli kağızlarının emissiyasını “Qiymətli kağızlar bazarı haqqında” Azərbaycan Respublikasının Qanununun 2-ci fəsli ilə müəyyən edilmiş qaydada həyata keçirən hüquqi şəxs, dövlət (müvafiq qaydada buna səlahiyyətləndirilmiş dövlət orqanı vasitəsilə) və ya bələdiyyədir. Emitent buraxdığı qiymətli kağızların mülkiyyətçisi deyildir.',
  accordions: [
    {
      id: 1,
      title: 'İnvestisiya qiymətli kağızlarının buraxılışının dövlət qeydiyyatına alınması',
      detail: 'editordan gelen data',
    },
    {
      id: 2,
      title:
        'Hüquqi şəxslərin yenidən təşkili zamanı investisiya qiymətli kağızlarının emissiyası və konvertasiyasıC',
      detail: 'editordan gelen data',
    },
  ],
};
export const meetShareholders = {
  text: '1.1. Bu Təlimat fövqəladə hallarda, o cümlədən pandemiya şəraitində səhmdar cəmiyyətinin səhmdarlarının ümumi yığıncağının (bundan sonra – ümumi yığıncaq) onlayn keçirilməsinin mümkünlüyü ilə əlaqədar Azərbaycan Respublikasının Mərkəzi Bankına (bundan sonra – Mərkəzi Bank) daxil olan müraciətlər nəzərə alınmaqla hazırlanmışdır.1.2. Bu Təlimat ümumi yığıncaqların məsafədən (onlayn) keçirilməsi ilə bağlı minimum tövsiyələri müəyyən edir.1.3. Azərbaycan Republikasının ərazisində fəaliyyət göstərən səhmdar cəmiyyətlərinə tövsiyə edilir ki, Azərbaycan Respublikasının Mülki Məcəlləsi, həmçinin “Banklar haqqında”, “Sığorta fəaliyyəti haqqında”, “Qiymətli kağızlar bazarı haqqında” və s. qanunlarının tələblərini, habelə bu Təlimatı nəzərə almaqla ümumi yığıncaqların məsafədən (onlayn) təşkili, keçirilməsi və qərarlarının qəbuluna dair daxili reqlament qəbul etsinlər.1.4. Bu Təlimat Azərbaycan Respublikasının Mülki Məcəlləsinə uyğun olaraq qiyabi səsvermə qaydasında keçirilən ümumi yığıncaqlara şamil edilmir.1.5. Bu Təlimat növbəti və növbədənkənar ümumi yığıncağın təşkili, keçirilməsi, qərarların qəbul edilməsi və nəticələrinin rəsmiləşdirilməsi ilə bağlı qanunvericiliyin tələblərini istisna etmir.',
};
export const informationIssuers = {
  text: '1.1. Bu Təlimat “Qiymətli kağızlar bazarı haqqında” Azərbaycan Respublikasının Qanunu (bundan sonra - Qanun) və ləğv edilmiş Qiymətli Kağızlar üzrə Dövlət Komitəsinin 3 fevral 2016-cı il tarixli 15-q nömrəli Qərarı ilə təsdiq edilmiş “Qiymətli kağızlar bazarında emitentlər tərəfindən məlumatların açıqlanması Qaydaları”na (bundan sonra - Qaydalar) uyğun hazırlanmışdır.1.2. Bu Təlimat Azərbaycan Respublikasının ərazisində qiymətli kağızları kütləvi təklif edilmiş (və ya edilməsi nəzərdə tutulan) və tənzimlənən bazarda ticarətə buraxılmış (və ya buraxılması nəzərdə tutulan) emitentlər (bundan sonra – emitentlər) tərəfindən Qanun və Qaydalara müvafiq olaraq məlumatların açıqlanması zamanı yardımçı vasitə rolunu oynayır.',
  files: [
    {
      id: 1,
      title: 'Emitentlər tərəfindən məlumatların açıqlanmasına dair Təlimat',
      file_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
      web_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
      type: 'pdf',
    },
  ],
};
export const stockExchange = {
  text: 'Fond birjası  - fond birjası fəaliyyəti üçün lisenziyaya malik olan, fəaliyyətinin müstəsna predmeti tənzimlənən bazarların təşkili və idarə edilməsi olan, səhmdar cəmiyyəti formasında yaradılan hüquqi şəxsdir. Fond birjası dövlət qiymətli kağızları bazarının, korporativ qiymətli kağızlar bazarının və törəmə maliyyə alətləri bazarının ticarətini təşkil edir.',
  files: [
    {
      id: 1,
      title: 'Bakı Fond Birjası',
      file_url: 'https://uploads.cbar.az/assets/ca632048f06ce4c63c656cdc2.pdf',
      web_url: 'https://uploads.cbar.az/assets/ca632048f06ce4c63c656cdc2.pdf',
      type: 'pdf',
    },
  ],
  accordions: [
    {
      id: 1,
      title: 'Bakı Fond Birjası',
      detail: 'editordan gelen data',
    },
  ],
};
export const depositoryCenter = {
  text: 'Depozitar sistemi qiymətli kağızların sənədsizləşdirilməsi, saxlanılması, uçotu, onlarla təsbit edilmiş hüquqların təsdiqi, öhdəliklərlə yüklənməsi, qiymətli kağız mülkiyyətçilərinin hesablarının uçotunun aparılması, “İnvestisiya fondları haqqında” Azərbaycan Respublikasının Qanunu ilə müəyyən edilmiş qaydada pul hesablarının açılması, həmin hesablar üzrə əməliyyatlar aparılması və pul köçürmələrinin həyata keçirilməsi ilə əlaqədar mərkəzi depozitar və onun üzvləri arasında olan münasibətlər sistemidir. Depozitar fəaliyyəti “Qiymətli Kağızlar Bazarı haqqında“ və “İnvestisiya fondları haqqında” Azərbaycan Respublikasının Qanunları ilə tənzimlənir.',
};
export const investmentCompanies = {
  text: 'İnvestisiya şirkəti investisiya şirkəti fəaliyyəti üçün lisenziyaya malik olan, fəaliyyətinin müstəsna predmeti “Qiymətli kağızlar bazarı haqqında” Qanunun 30.3-cü və 30.4-cü maddələri ilə müəyyən edilmiş əsas və yardımçı investisiya xidmətlərinin göstərilməsi olan səhmdar cəmiyyəti formasında yaradılan hüquqi şəxsdir.',
  files: [
    {
      id: 1,
      title: 'İnvestisiya şirkətləri',
      file_url: 'https://uploads.cbar.az/assets/66aef129f26b7472e1e785b4f.pdf',
      web_url: 'https://uploads.cbar.az/assets/66aef129f26b7472e1e785b4f.pdf',
      type: 'pdf',
    },
  ],
  accordions: [
    {
      id: 1,
      title: '"CFİ Financial İnvestisiya Şirkəti" QSC',
      detail: 'editordan gelen data',
    },
    {
      id: 2,
      title: '"Unicapital İnvestisiya Şirkəti" ASC',
      detail: 'editordan gelen data',
    },
  ],
};
export const banksServicesInvestment = {
  text: '“Qiymətli kağızlar bazarı haqqında” Qanunun (bundan sonra – Qanun) 30.3-cü və 30.4-cü maddələri ilə müəyyən edilmiş investisiya xidmətləri Azərbaycan Respublikasında fəaliyyət göstərən banklar və xarici bankların yerli filialları tərəfindən Qanunun 8-1-ci fəsli ilə müəyyən edilmiş qaydada lisenziya alınmaqla Mərkəzi Bank tərəfindən müəyyən edilən həcmdə və qaydada həyata keçirilir.',
  files: [
    {
      id: 1,
      title: 'İnvestisiya xidmətlərini (əməliyyatlarını) həyata keçirən banklar',
      file_url: 'https://uploads.cbar.az/assets/85fbefb1633e71e858f699636.pdf',
      web_url: 'https://uploads.cbar.az/assets/85fbefb1633e71e858f699636.pdf',
      type: 'pdf',
    },
  ],
  accordions: [
    {
      id: 1,
      title: '"ASC Xalq Bankı',
      detail: 'editordan gelen data',
    },
  ],
};
export const clearingHouse = {
  text: 'Klirinq təşkilatı müstəsna olaraq klirinq fəaliyyəti ilə məşğul olan, bu fəaliyyət növü üzrə lisenziyaya malik olan və səhmdar cəmiyyəti formasında yaradılan hüquqi şəxsdir.',
};
export const equityFundManager = {
  text: '“İnvestisiya fondu səhmdar və ya paylı investisiya fondu formasında yaradılan, vəsaitlərin cəlb edilib mənfəət əldə edilməsi məqsədi ilə investisiya bəyannaməsində nəzərdə tutulmuş qaydada yatırılması ilə məşğul olan maliyyə qurumudur.',
  files: [
    {
      id: 1,
      title: 'İnvestisiya fondunun idarəçisi fəaliyyəti üzrə lisenziyaya malik şirkətlər',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
  ],
  accordions: [
    {
      id: 1,
      title: '"AzFinance Asset Management" MMC”',
      detail: 'editordan gelen data',
    },
    {
      id: 2,
      title: '"İnvestAz Asset Management MMC”',
      detail: 'editordan gelen data',
    },
  ],
};
export const qualificationCertificates = {
  text: 'İnvestisiya xidmətlərinin (əməliyyatlarının) həyata keçirilməsinə və investisiya fondlarının idarə edilməsinə dair ixtisas şəhadətnamələrinə malik olan şəxslərin siyahısı',
  files: [
    {
      id: 1,
      title: 'İxtisas şəhadətnamələri',
      file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      type: 'pdf',
    },
  ],
};
export const informationMemorandums = {
  text: '“Qiymətli kağızlar bazarı haqqında” Azərbaycan Respublikasının Qanununa (bundan sonra – Qanun) əsasən, investisiya qiymətli kağızlarının kütləvi təklifi və ya onların tənzimlənən bazarda ticarətə buraxılması zamanı emitent tərəfindən emissiya prospekti və ya informasiya memorandumu tərtib olunmalıdır.',
  files: [
    {
      id: 1,
      title: 'İnformasiya memorandumu (emitent xarici dövlət orqanı olduqda)',
      file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title: 'İnformasiya memorandumu (səhm)',
      file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      type: 'pdf',
    },
    {
      id: 3,
      title: 'Baza emissiya prospekti (adi)',
      file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      type: 'pdf',
    },
    {
      id: 4,
      title: 'Baza emissiya prospekti (emitent bank olduqda)',
      file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      type: 'pdf',
    },
  ],
};
export const licensingProcesses = {
  text: '“Qiymətli kağızlar bazarı haqqında” Azərbaycan Respublikasının Qanununun (bundan sonra – Qanun) 64.1-ci maddəsinə əsasən Azərbaycan Respublikası ərazisində fond birjası, klirinq, investisiya fondunun depozitarı və investisiya şirkəti fəaliyyətləri (bundan sonra – lisenziyalaşdırılan fəaliyyət) ilə yalnız Qanunun 8-ci fəslinə uyğun qaydada lisenziya almış hüquqi şəxslər məşğul olurlar. Bundan əlavə, investisiya xidmətlərinin (əməliyyatlarının) həyata keçirilməsi fəaliyyəti ilə Qanunun 8-1-ci fəslinə uyğun qaydada lisenziya almış banklar və xarici bankların yerli filialları da məşğul olurlar.',
  files: [
    {
      id: 1,
      title: 'Fond birjasının lisenziyalaşdırılması',
      file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title:
        'Fond birjasının ticarəti təşkil edəcəyi bazarları genişləndirmək üçün icazə almasına dair tələblər',
      file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      type: 'pdf',
    },
    {
      id: 3,
      title:
        'Xarici investisiya fondunun idarəçisinin nümayəndəliyinin fəaliyyətinə icazə verilməsinə dair tələblər',
      file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      type: 'pdf',
    },
    {
      id: 4,
      title:
        'Xarici investisiya fondunun nümayəndəliyinin fəaliyyətinə icazə verilməsinə dair tələblər',
      file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
      type: 'pdf',
    },
  ],
};
export const investmentSecurities = {
  accordions: [
    {
      id: 1,
      title: '2025',
      files: [
        {
          id: 1,
          title: 'Avqust',
          file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title: 'İyul',
          file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          type: 'pdf',
        },
        {
          id: 3,
          title: 'İyun',
          file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          type: 'pdf',
        },
        {
          id: 4,
          title: 'May',
          file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          type: 'pdf',
        },
      ],
    },
  ],
};

export const insurers = {
  text: 'Azərbaycan Respublikasının Mərkəzi Bankı “Sığorta fəaliyyəti haqqında” Azərbaycan Respublikası Qanununun 95-ci maddəsinə əsasən sığorta sektorunda dövlət tənzimlənməsini və nəzarəti həyata keçirir.',
  files: [
    {
      id: 1,
      title: 'SIĞORTAÇILARIN VƏ TƏKRARSIĞORTAÇILARIN REYESTR MƏLUMATLARI',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
  ],
  accordions: [
    {
      id: 1,
      title: '"A-Qroup Sığorta Şirkəti" ASC',
      detail: 'editordan gelen data',
    },
    {
      id: 2,
      title: '"AtaSığorta" ASC',
      detail: 'editordan gelen data',
    },
  ],
};
export const insuranceIntermediaries = {
  text: 'Azərbaycan Respublikasının Mərkəzi Bankı “Sığorta fəaliyyəti haqqında” Azərbaycan Respublikası Qanununun 95-ci maddəsinə əsasən sığorta sektorunda dövlət tənzimlənməsini və nəzarəti həyata keçirir.',
  files: [
    {
      id: 1,
      title: 'Fiziki şəxs sığorta agentləri',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
    {
      id: 2,
      title: 'Hüquqi şəxs sığorta agentləri',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
    {
      id: 3,
      title: 'Hüquqi şəxs sığorta brokerləri',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
    {
      id: 4,
      title: 'Fiziki şəxs olan sığorta brokerləri',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
  ],
};
export const foreignInsuranceBrokers = {
  text: 'Azərbaycan Respublikasının Mərkəzi Bankı “Sığorta fəaliyyəti haqqında” Azərbaycan Respublikası Qanununun 95-ci maddəsinə əsasən sığorta sektorunda dövlət tənzimlənməsini və nəzarəti həyata keçirir.',
  files: [
    {
      id: 1,
      title: 'Xarici sığortaçılar, təkrarsığortaçılar və sığorta brokerləri',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
  ],
};
export const lossAdjusters = {
  text: 'Azərbaycan Respublikasının Mərkəzi Bankı “Sığorta fəaliyyəti haqqında” Azərbaycan Respublikası Qanununun 95-ci maddəsinə əsasən sığorta sektorunda dövlət tənzimlənməsini və nəzarəti həyata keçirir.',
  files: [
    {
      id: 1,
      title: 'Hüquqi şəxs müstəqil eskpertlər',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
    {
      id: 2,
      title: 'Fiziki şəxs müstəqil eskpertlər',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
    {
      id: 3,
      title: 'Yardımçı yerli hüquqi şəxslər',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
    {
      id: 4,
      title: 'Yardımçı xarici hüquqi şəxslər',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
  ],
};
export const actuaries = {
  text: 'Azərbaycan Respublikasının Mərkəzi Bankı “Sığorta fəaliyyəti haqqında” Azərbaycan Respublikası Qanununun 95-ci maddəsinə əsasən sığorta sektorunda dövlət tənzimlənməsini və nəzarəti həyata keçirir.',
  files: [
    {
      id: 1,
      title: 'Aktuari',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
  ],
};
export const attestation = {
  accordions: [
    {
      id: 1,
      title: 'Sığorta vasitəçiləri',
      detail:
        'Sığorta vasitəçiliyi fəaliyyətinə lisenziya almaq istəyən fiziki şəxslər, həmçinin sığorta agenti fəaliyyətinə lisenziya almaq istəyən hüquqi şəxsin əmək müqaviləsi əsasında işçisi hesab olunan şəxslər Mərkəzi Bankda müvafiq attestasiyadan keçməlidir. Həmin şəxslər aşağıda qeyd olunan sənədləri Azərbaycan Respublikasının Mərkəzi Bankına rəsmi qaydada təqdim etməlidir',
      files: [
        {
          id: 1,
          title: 'Müraciət ərizəsi "Sığorta agenti"',
          file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title: 'Müraciət ərizəsi "Sığorta brokeri"',
          file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          type: 'pdf',
        },
      ],
    },
    {
      id: 2,
      title: 'Hüquqi şəxs sığorta vasitəçilərinin icra orqanının rəhbəri',
      detail:
        'Hüquqi şəxs olan sığorta brokerinin və müstəsna olaraq sığorta agenti olmaq üçün təsis edilmiş hüquqi şəxsin icra orqanının rəhbəri vəzifəsinə təyinatı nəzərdə tutulan şəxslər Mərkəzi Bankda müvafiq attestasiyadan keçməlidirlər. Həmin şəxslər aşağıdakı sənədləri Azərbaycan Respublikasının Mərkəzi Bankına rəsmi qaydada təqdim edilməlidir:',
      files: [
        {
          id: 1,
          title: 'Hüquqi şəxs sığorta brokerinin icra orqanının rəhbərinin anketi',
          file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title:
            'Müstəsna olaraq sığorta agenti fəaliyyəti ilə məşğul olan icra orqanının rəhbərinin anketi',
          file_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          web_url: 'https://uploads.cbar.az/assets/9ff6b4114dbc866415db3600f.pdf',
          type: 'pdf',
        },
      ],
    },
  ],
};

export const electronMoneyInstitutions = {
  text: '“Ödəniş xidmətləri və ödəniş sistemləri haqqında” Qanunun 48.1-ci maddəsinə əsasən elektron pul təşkilatı ödəniş xidmətləri sahəsində fəaliyyətini lisenziya aldıqdan sonra həyata keçirə bilərlər.Elektron pul təşkilatı – Qanunla müəyyən olunmuş qaydada aldığı lisenziya əsasında elektron pulu emissiya və elektron pul ilə əlaqəli ödəniş əməliyyatlarını icra edən, eyni zamanda lisenziyasında nəzərdə tutulduğu halda digər ödəniş xidmətlərini həyata keçirmək hüququ olan hüquqi şəxsdir.',
  files: [
    {
      id: 1,
      title: 'Elektron pul təşkilatları',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
  ],
  accordions: [
    {
      id: 1,
      title: '“A-Solutions Elektron Pul Təşkilatı” MMC',
      detail: 'editordan gelen data',
    },
    {
      id: 2,
      title: '“United Payment” MMC',
      detail: 'editordan gelen data',
    },
  ],
};
export const paymentInstitutions = {
  text: '“Ödəniş xidmətləri və ödəniş sistemləri haqqında” Qanunun 48.1-ci maddəsinə əsasən ödəniş təşkilatı ödəniş xidmətləri sahəsində fəaliyyətini lisenziya aldıqdan sonra həyata keçirə bilərlər.',
  files: [
    {
      id: 1,
      title: '“Ödəniş təşkilatları',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
  ],
  accordions: [
    {
      id: 1,
      title: '“Token Azərbaycan” MMC',
      detail: 'editordan gelen data',
    },
    {
      id: 2,
      title: '"Global İnnovations" MMC',
      detail: 'editordan gelen data',
    },
  ],
};
export const paymentSystemOperations = {
  text: '“Ödəniş xidmətləri və ödəniş sistemləri haqqında” Qanunun 48.1-ci maddəsinə əsasən ödəniş sistemi operatoru (Mərkəzi Bank istisna olmaqla) ödəniş sistemləri sahəsində fəaliyyətini lisenziya aldıqdan sonra həyata keçirə bilərlər.Ödəniş sistemi – ödəniş əməliyyatlarının emalı, klirinqi və (və ya) hesablaşmaların aparılması üzrə rəsmiləşdirilmiş və standartlaşdırılmış ümumi mexanizm və qaydalara malik, üç və daha artıq iştirakçının üzv olduğu pul vəsaitinin köçürülməsi sistemi;',
  files: [
    {
      id: 1,
      title: 'Ödəniş sistemi operatorları',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
  ],
  accordions: [
    {
      id: 1,
      title: '"Azərikard" MMC',
      detail: 'editordan gelen data',
    },
    {
      id: 2,
      title: '"Millikart" MMC',
      detail: 'editordan gelen data',
    },
  ],
};
export const paymentAgents = {
  text: 'Bank, ödəniş təşkilatı və elektron pul təşkilatı “Ödəniş xidmətləri və ödəniş sistemləri haqqında” Qanunun 3.1.1-ci, 3.1.2-ci və 3.1.4-cü maddələrində nəzərdə tutulmuş ödəniş xidmətlərinin göstərilməsi, bank və elektron pul təşkilatı eyni zamanda elektron pulun satışı və elektron pulun qalıq dəyərinin geri ödənilməsi üçün ölkə daxilində ödəniş agentini cəlb edə bilərlər. Ödəniş xidməti təchizatçısı cəlb etdiyi ödəniş agentlərinin ödəniş xidmətləri üzrə fəaliyyətinə görə tam məsuliyyət daşıyır.',
  files: [
    {
      id: 1,
      title: 'Ödəniş agentləri',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
  ],
};

export const postalCommunication = {
  text: 'Poçt rabitəsinin milli operatoru (milli operator) - müvafiq icra hakimiyyəti orqanı tərəfindən universal poçt rabitəsi və poçt-maliyyə xidmətləri göstərilməsi üçün təyin olunmuş poçt operatorudır.',
  files: [
    {
      id: 1,
      title: 'Bank fəaliyyətinə lisenziya almış poçt bölmələri',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
  ],
};
export const currencyExchangeOffices = {
  text: 'Valyuta mübadiləsi fəaliyyəti - Azərbaycan Respublikasında xarici valyutanın qanunla müəyyən edilmiş qaydada alınması, satılması və dəyişdirilməsidir.',
  files: [
    {
      id: 1,
      title: 'Valyuta mübadiləsi məntəqələri - Reyestr',
      file_url: 'https://uploads.cbar.az/assets/d074239702a14c2fa82e56c8b.xlsx',
      type: 'xls',
    },
  ],
};

export const operatorBanks = {
  text: 'Mərkəzi Bank tərəfindən nağd pulla bağlı biznes proseslərin optimallaşdırılması, eləcə də banklarda müasir texnoloji sistem və avadanlıqların tətbiqi ilə nağd pulun idarə edilməsində səmərəliliyin yüksəldilməsi məqsədilə bir sıra biznes proseslərin banklara ötürülməsi həyata keçirilir.',
  list: [
    {
      id: 1,
      title: '"Kapital Bank" ASC',
    },
    {
      id: 2,
      title: '“ABB” ASC',
    },
  ],
};

export const supervisoryActions={
  organizationTypes:[
    {
      id:1,
      title:"Bank"
    },
    {
      id:2,
      title:"BOKT"
    },
    {
      id:3,
      title:"Kredit Ittifaqları"
    },
  ],
  years:[2023,2024,2025],
  months:[
    {
      id:1,
      month:"Yanvar"
    },
    {
      id:2,
      month:"Fevral"
    },
    {
      id:3,
      month:"Mart"
    },
    {
      id:4,
      month:"Aprel"
    },
    {
      id:5,
      month:"May"
    },
    {
      id:6,
      month:"Iyun"
    },
    {
      id:7,
      month:"Iyul"
    },
    {
      id:8,
      month:"Avqust"
    },
    {
      id:9,
      month:"Sentyabr"
    },
    {
      id:10,
      month:"Oktyabr"
    },
    {
      id:11,
      month:"Noyabr"
    },
    {
      id:12,
      month:"Dekabr"
    }
  ],
  actions:[
    {
      id:1,
      type:"Bank",
      year:2025,
      month:"Avqust",
      title:"“Rabitəbank” ASC-yə maliyyə sanksiyasının tətbiq olunması haqqında məlumat",
      description:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut error labore libero enim nihil itaque ea quisquam atque at magni pariatur et vitae iusto, rerum nobis accusamus provident facere consequuntur."
    },
    {
      id:2,
      type:"BOKT",
      year:2024,
      month:"Iyun",
      title:"“Finca Azerbaijan” MM QBKT-nin vəzifəli şəxsinin inzibati məsuliyyətə cəlb olunması barədə",
      description:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut error labore libero enim nihil itaque ea quisquam atque at magni pariatur et vitae iusto, rerum nobis accusamus provident facere consequuntur."
    },
    {
      id:3,
      type:"Kredit Ittifaqları",
      year:2023,
      month:"Yanvar",
      title:"“Stimul” Kredit İttifaqı MMC-yə icrası məcburi göstərişin verilməsi barədə məlumat",
      description:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut error labore libero enim nihil itaque ea quisquam atque at magni pariatur et vitae iusto, rerum nobis accusamus provident facere consequuntur."
    }
  ]
}
