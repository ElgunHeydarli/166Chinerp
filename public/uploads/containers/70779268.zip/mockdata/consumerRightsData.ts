import yevlaxImg from '../images/yevlaxOffice.png';
import bilesuvarImg from '../images/bilesuvarOffice.png';

export const consumerInvestorRights = {
  text: 'Azərbaycan Respublikasının Mərkəzi Bankının mühüm vəzifələrindən biri maliyyə xidmətləri istehlakçılarının və investorların hüquqlarını müdafiə etməkdir. Bununla əlaqədar, Mərkəzi Bank istehlakçıların və investorların hüquqlarının müdafiəsi sahəsində aşağıdakı işləri görür:',
};
export const applyCB = {
  reviewApplications: [
    {
      id: 1,
      title: 'Vətəndaş müraciətlərinə dair qanunvericilik',
      files: [
        {
          id: 1,
          title: 'lorem ipsum',
          file_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
          web_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title: 'lorem ipsum',
          file_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
          web_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
          type: 'pdf',
        },
        {
          id: 3,
          title: 'lorem ipsum',
          file_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
          web_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
          type: 'pdf',
        },
      ],
    },
    {
      id: 2,
      title: 'Müraciətlərə baxılması qaydası',
      description:
        'Mərkəzi Bankın əsas vəzifələrindən biri maliyyə xidmətləri istehlakçılarının və investorların hüquqlarının müdafiəsini və onların pozulmasının qarşısının alınmasını təmin etməkdir. Bunun üçün Mərkəzi Bank hüquqi və fiziki şəxslərdən daxil olan maliyyə xidmətləri istehlakçılarının və investorların hüquqlarının pozulması ilə bağlı müraciətlər üzrə araşdırmalar aparır və hüquq pozuntularına qarşı tədbirlər görür. Mərkəzi Bank tərəfindən həmin şəxslərdən daxil olmuş bank, bank olmayan kredit təşkilatları, sığorta, qiymətli kağızlar bazarı, səhmdar cəmiyyətlərində korporativ idarəetmə sahələri, investisiya fondları və poçt rabitəsinin milli operatoruna və Mərkəzi Bankın digər nəzarət subyektlərinə aid müraciətlərə baxılır.',
    },
    {
      id: 3,
      title: 'Müraciət et',
      description:
        'Qeyd: Aşağıdakı formalarda Mərkəzi Banka yazılı müraciət edə bilərsiniz. Mərkəzi Bankın rəsmi internet səhifəsində onlayn müraciət etməklə',
      links: [
        {
          id: 1,
          linkName: 'Rəsmi müraciət et',
          url: 'https://contact.e-cbar.az/',
        },
      ],
    },
    {
      id: 4,
      title: 'Videotəqdimat',
      videos: [
        {
          id: 1,
          title: 'Vətəndaşların Mərkəzi Banka müraciət qaydası (Azərbaycan dilində)',
          url: 'https://www.youtube.com/watch?v=MEKxG_2kQxg',
        },
        {
          id: 2,
          title: 'Vətəndaşların Mərkəzi Banka müraciət qaydası (İngilis dilində)',
          url: 'https://www.youtube.com/watch?v=HgdmqKNaXNY',
        },
        {
          id: 3,
          title: 'Vətəndaşların Mərkəzi Banka müraciət qaydası (Rus dilində)',
          url: 'https://www.youtube.com/watch?v=08AzTE6Gw20',
        },
      ],
    },
  ],
  receptionCitizens: [
    {
      id: 1,
      title: 'Qəbul qaydası və qəbul cədvəli',
      tabs: [
        {
          id: 1,
          tabTitle: 'Qəbul qaydası',
          description:
            'Azərbaycan Respublikasının Mərkəzi Bankı tərəfindən vətəndaşların qəbul edilməsi “Vətəndaşların müraciətləri haqqında” Azərbaycan Respublikasının Qanununa, Azərbaycan Respublikası Prezidentinin 23 iyun 2016-cı il tarixli, 950 nömrəli Fərmanı ilə təsdiq edilmiş “Dövlət və bələdiyyə orqanlarında, dövlət və ya bələdiyyə mülkiyyətində olan və ya paylarının (səhmlərinin) nəzarət zərfi dövlətə və ya bələdiyyəyə məxsus olan hüquqi şəxslərdə və büdcə təşkilatlarında vətəndaşların müraciətləri ilə bağlı kargüzarlığın aparılması Qaydası”na və Azərbaycan Respublikası Mərkəzi Bankının “Azərbaycan Respublikasının Mərkəzi Bankında istehlakçıların və investorların müraciətlərinə baxılması və qəbulu” Qaydalarında nəzərdə tutulmuş qaydada həyata keçirilir.',
        },
        {
          id: 2,
          tabTitle: 'Qəbul cədvəli',
          description:
            'Mərkəzi Bankın müvafiq struktur bölməsinin səlahiyyətli əməkdaşları tərəfindən vətəndaşların qəbul günləri iş günləri hesab edilən bazar ertəsi-cümə axşamı günü saat 09:00-16:00-dək, cümə günü isə 09:00-13:00-dək (nahar fasiləsi 13:00-14:00) müəyyən edilir. Vətəndaşların müvafiq struktur bölmənin səlahiyyətli əməkdaşları tərəfindən qəbulu günləri Mərkəzi Bankın inzibati binasının girişində məlumat stendində yerləşdirilir.',
          files: [
            {
              id: 1,
              title: 'Mərkəzi Bankda rəhbər şəxslərin qəbul cədvəli',
              file_url: 'https://uploads.cbar.az/assets/dcbc84a961ea5f4ed1eb5fc83.pdf',
              web_url: 'https://uploads.cbar.az/assets/dcbc84a961ea5f4ed1eb5fc83.pdf',
              type: 'pdf',
            },
          ],
        },
        {
          id: 3,
          tabTitle: 'Qəbul qaydası',
          description:
            'Azərbaycan Respublikasının Mərkəzi Bankı tərəfindən vətəndaşların qəbul edilməsi “Vətəndaşların müraciətləri haqqında” Azərbaycan Respublikasının Qanununa, Azərbaycan Respublikası Prezidentinin 23 iyun 2016-cı il tarixli, 950 nömrəli Fərmanı ilə təsdiq edilmiş “Dövlət və bələdiyyə orqanlarında, dövlət və ya bələdiyyə mülkiyyətində olan və ya paylarının (səhmlərinin) nəzarət zərfi dövlətə və ya bələdiyyəyə məxsus olan hüquqi şəxslərdə və büdcə təşkilatlarında vətəndaşların müraciətləri ilə bağlı kargüzarlığın aparılması Qaydası”na və Azərbaycan Respublikası Mərkəzi Bankının “Azərbaycan Respublikasının Mərkəzi Bankında istehlakçıların və investorların müraciətlərinə baxılması və qəbulu” Qaydalarında nəzərdə tutulmuş qaydada həyata keçirilir.',
        },
        {
          id: 4,
          tabTitle: 'Qəbul cədvəli',
          description:
            'Mərkəzi Bankın müvafiq struktur bölməsinin səlahiyyətli əməkdaşları tərəfindən vətəndaşların qəbul günləri iş günləri hesab edilən bazar ertəsi-cümə axşamı günü saat 09:00-16:00-dək, cümə günü isə 09:00-13:00-dək (nahar fasiləsi 13:00-14:00) müəyyən edilir. Vətəndaşların müvafiq struktur bölmənin səlahiyyətli əməkdaşları tərəfindən qəbulu günləri Mərkəzi Bankın inzibati binasının girişində məlumat stendində yerləşdirilir.',
          files: [
            {
              id: 1,
              title: 'Mərkəzi Bankda rəhbər şəxslərin qəbul cədvəli',
              file_url: 'https://uploads.cbar.az/assets/dcbc84a961ea5f4ed1eb5fc83.pdf',
              web_url: 'https://uploads.cbar.az/assets/dcbc84a961ea5f4ed1eb5fc83.pdf',
              type: 'pdf',
            },
          ],
        },
      ],
    },
    {
      id: 2,
      title: 'Qəbula yazıl',
      description:
        'Vətəndaşlar Azərbaycan Respublikasının Mərkəzi Bankının inzibati binasına yaxınlaşmaqla, "966" qaynar xətt vasitəsilə, onlayn müraciət və "WhatsApp" nömrəsinə müraciət etməklə qəbulda iştirak edə bilərlər.',
      links: [
        {
          id: 1,
          linkName: 'Onlayn növbə əldə et',
          url: 'https://randevu.e-cbar.az/home',
        },
        {
          id: 2,
          linkName: 'Rəsmi müraciət et',
          url: 'https://contact.e-cbar.az/',
        },
      ],
    },
    {
      id: 4,
      title: 'Qəbulla bağlı videotəqdimat',
      videos: [
        {
          id: 1,
          url: 'https://youtu.be/Kbbe0DJKCO4',
        },
        {
          id: 2,
          url: 'https://youtu.be/3LLc58f10tE',
        },
      ],
    },
  ],
  contactUs: [
    {
      id: 1,
      title: 'Qaynar xətt',
      description:
        'Mərkəzi Bankın “966 qaynar xətti” iş günlərində fasiləsiz olaraq saat 09:00-dan 18:00-dək daxil olan zənglərin cavablandırılmasını həyata keçirir. Daxil olan zənglərin yerində cavablandırılması mümkündürsə, vətəndaşların şifahi müraciətləri ilə əlaqədar onlara müvafiq izahat verilərək müraciətləri cavablandırılır. Əks halda zənglər cavablandırılması üçün müvafiq struktur bölmələrə və ya daxil olan rəsmi yazılı müraciətləri üzrə icraçılara yönəldilir. Mərkəzi Banka daxil olan zənglər telefonçu-operatorlar tərəfindən qəbul edilir və bütün zənglərin qeydiyyatı aparılır.',
    },
    {
      id: 2,
      title: 'Əlaqə nömrələri',
      description:
        'Mərkəzi Bankla (+994 12) 493 5058 telefon nömrələri vasitəsilə əlaqə saxlanılır.',
    },
    {
      id: 3,
      title: 'Whatsapp',
      description:
        'Aşağıda qeyd olunan istiqamətlər üzrə Mərkəzi Bankın 055-966-19-66 nömrəli whatsapp xidmətindən (xidmət) istifadə edilə bilər:',
    },
    {
      id: 4,
      title: 'Ünvan',
      map: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7033.458232298222!2d49.83433391102833!3d40.380069062841734!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40307da6571f6cc7%3A0x8c29ed401e1df1e7!2sCentral%20Bank%20of%20the%20Republic%20of%20Azerbaijan!5e0!3m2!1saz!2saz!4v1757873921696!5m2!1saz!2saz',
    },
  ],
  feedback: {
    description:
      'Mərkəzi Bankın qaynar xətt nömrələri ilə hər hansı səbəbə görə əlaqənin yaradılmasında çətinlik yarandıqda Mərkəzi Bankın whatsapp xidmətinə keçid etməklə geri əlaqə yaradılması üçün müraciət edilə bilər. Eyni zamanda qaynar xətt nömrələri ilə əlaqə saxlanıldığı zaman “1” düyməsi seçilməklə geri əlaqə yaradılması sifariş edilə bilər. Müraciət edildikdən qısa müddət ərzində müraciət müəllifi ilə əlaqə yaradılacaq.',
    links: [
      {
        id: 1,
        linkName: 'Bizimlə əlaqə',
        url: '+994559661966',
      },
    ],
  },
  proposals: {
    description:
      'Azərbaycan Respublikası Mərkəzi Bankının maliyyə xidmətləri istehlakçılarının və investorların hüquqlarının müdafiəsi üzrə səlahiyyətlərinə aid məsələlərə dair təkliflərinizi suggest@cbar.az elektron poçt ünvanına göndərə bilərsiniz.',
  },
  territorialOffices: [
    {
      id: 1,
      title: 'Yevlax Ehtiyat Mərkəzi',
      regionBox: {
        regionImg: yevlaxImg,
        title: 'Yevlax Ehtiyat Mərkəzi',
        director: 'Bayramov Ədalət Aydın oğlu',
        phone: '(+994 2233) 6-10-59',
        location: 'AZ 6600, Yevlax şəhəri, H.Əliyev pr. 82',
      },
      description:
        'Azərbaycan Respublikasının Mərkəzi Bankı tərəfindən Ərazi İdarələrində vətəndaşların qəbul edilməsi “Vətəndaşların müraciətləri haqqında” Azərbaycan Respublikasının Qanununa, Azərbaycan Respublikası Prezidentinin 23 iyun 2016-cı il tarixli, 950 nömrəli Fərmanı ilə təsdiq edilmiş “Dövlət və bələdiyyə orqanlarında, dövlət və ya bələdiyyə mülkiyyətində olan və ya paylarının (səhmlərinin) nəzarət zərfi dövlətə və ya bələdiyyəyə məxsus olan hüquqi şəxslərdə və büdcə təşkilatlarında vətəndaşların müraciətləri ilə bağlı kargüzarlığın aparılması Qaydası”na və Azərbaycan Respublikası Mərkəzi Bankının “Azərbaycan Respublikasının Mərkəzi Bankında istehlakçıların və investorların müraciətlərinə baxılması və qəbulu” Qaydalarında nəzərdə tutulmuş qaydada həyata keçirilir.',
      statistics: [
        {
          id: 1,
          title: '2025',
          description: 'editordan table gelecek',
        },
        {
          id: 2,
          title: '2024',
          description: 'editordan table gelecek',
        },
        {
          id: 3,
          title: '2023',
          description: 'editordan table gelecek',
        },
      ],
    },
    {
      id: 2,
      title: 'Biləsuvar Regional Mərkəzi',
      regionBox: {
        regionImg: bilesuvarImg,
        title: 'Biləsuvar Regional Mərkəzi',
        director: 'Rüstəmov Nəbi İsrafil oğlu',
        phone: '(+994 159) 5-00-15',
        location: 'AZ 1300 Biləsuvar şəhəri, H.Əliyev küçəsi 2B',
      },
      description:
        'Azərbaycan Respublikasının Mərkəzi Bankı tərəfindən Ərazi İdarələrində vətəndaşların qəbul edilməsi “Vətəndaşların müraciətləri haqqında” Azərbaycan Respublikasının Qanununa, Azərbaycan Respublikası Prezidentinin 23 iyun 2016-cı il tarixli, 950 nömrəli Fərmanı ilə təsdiq edilmiş “Dövlət və bələdiyyə orqanlarında, dövlət və ya bələdiyyə mülkiyyətində olan və ya paylarının (səhmlərinin) nəzarət zərfi dövlətə və ya bələdiyyəyə məxsus olan hüquqi şəxslərdə və büdcə təşkilatlarında vətəndaşların müraciətləri ilə bağlı kargüzarlığın aparılması Qaydası”na və Azərbaycan Respublikası Mərkəzi Bankının “Azərbaycan Respublikasının Mərkəzi Bankında istehlakçıların və investorların müraciətlərinə baxılması və qəbulu” Qaydalarında nəzərdə tutulmuş qaydada həyata keçirilir.',
      statistics: [
        {
          id: 1,
          title: '2025',
          description: 'editordan table gelecek',
        },
        {
          id: 2,
          title: '2024',
          description: 'editordan table gelecek',
        },
        {
          id: 3,
          title: '2023',
          description: 'editordan table gelecek',
        },
      ],
    },
  ],
};
export const statisticsCitizensAppeals = {
  categories: [
    {
      id: 1,
      title: 'Yazılı müraciətlər üzrə statistika',
    },
    {
      id: 2,
      title: 'Vətəndaş qəbulu üzrə statistika',
    },
    {
      id: 3,
      title: 'Daxil olan zənglər üzrə statistika',
    },
    {
      id: 4,
      title: 'Whatsapp üzrə statistika',
    },
  ],
  statistics: [
    {
      id: 1,
      category: 'Yazılı müraciətlər üzrə statistika',
      month: 'May',
      creditInstitutions: 1071,
      paymentSystems: 7,
      currencyExchangeOffices: 0,
      insurers: 266,
      capitalMarket: 47,
      other: 212,
      total: 1603,
    },
    {
      id: 2,
      category: 'Vətəndaş qəbulu üzrə statistika',
      month: 'Avqust',
      creditInstitutions: 1071,
      paymentSystems: 7,
      currencyExchangeOffices: 0,
      insurers: 266,
      capitalMarket: 47,
      other: 212,
      total: 1603,
    },
    {
      id: 3,
      category: 'Daxil olan zənglər üzrə statistika',
      month: 'Yanvar',
      creditInstitutions: 1071,
      paymentSystems: 7,
      currencyExchangeOffices: 0,
      insurers: 266,
      capitalMarket: 47,
      other: 212,
      total: 1603,
    },
    {
      id: 4,
      category: 'Whatsapp üzrə statistika',
      month: 'Mart',
      creditInstitutions: 1071,
      paymentSystems: 7,
      currencyExchangeOffices: 0,
      insurers: 266,
      capitalMarket: 47,
      other: 212,
      total: 1603,
    },
  ],
  infographicsFiles: [
    {
      id: 1,
      title:
        '2025-ci ilin iyul ayı üzrə Azərbaycan Respublikasının Mərkəzi Bankına daxil olan müraciətlərə dair statistik hesabat',
      file_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
      web_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
      type: 'pdf',
    },
    {
      id: 2,
      title:
        '2025-ci ilin iyun ayı üzrə Azərbaycan Respublikasının Mərkəzi Bankına daxil olan müraciətlərə dair statistik hesabat',
      file_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
      web_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
      type: 'pdf',
    },
    {
      id: 3,
      title:
        '2025-ci ilin may ayı üzrə Azərbaycan Respublikasının Mərkəzi Bankına daxil olan müraciətlərə dair statistik hesabat',
      file_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
      web_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
      type: 'pdf',
    },
  ],
};
export const complaintIndex = {
  years: [2025, 2024, 2023, 2022, 2021, 2020],
  months: [
    {
      id: 1,
      month: 'Yanvar',
    },
    {
      id: 2,
      month: 'Fevral',
    },
    {
      id: 3,
      month: 'Mart',
    },
    {
      id: 4,
      month: 'Aprel',
    },
    {
      id: 5,
      month: 'May',
    },
    {
      id: 6,
      month: 'Iyun',
    },
    {
      id: 7,
      month: 'Iyul',
    },
    {
      id: 8,
      month: 'Avqust',
    },
    {
      id: 9,
      month: 'Sentyabr',
    },
    {
      id: 10,
      month: 'Oktyabr',
    },
    {
      id: 11,
      month: 'Noyabr',
    },
    {
      id: 12,
      month: 'Dekabr',
    },
  ],
  complaintTypes: [
    {
      id: 1,
      title: 'Bank xidmətlərindən istifadə üzrə şikayət indeksi',
    },
    {
      id: 2,
      title: 'Avto-icbari sığorta üzrə şikayət indeksi',
    },
  ],
  files: [
    {
      id: 1,
      title:
        'Bank müştərilərinin bank xidmətlərindən istifadəsi üzrə şikayət indeksi (2025-ci ilin may ayı üzrə)',
      file_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
      web_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
      type: 'pdf',
    },
  ],
};
export const events = [
  {
    id: 1,
    title: 'Mərkəzi Bankın səyyar qəbulu Gəncə şəhərində keçirilib',
    description:
      'Azərbaycan Respublikasının Mərkəzi Bankı tərəfindən maliyyə xidmətləri istehlakçılarının və investorların hüquqlarının müdafiəsinin möhkəmləndirilməsi istiqamətində tədbirlər davam etdirilir. Bu çərçivədə növbəti təşəbbüs 4 iyun tarixində Gəncə şəhərində vətəndaşların səyyar qəbulunun keçirilməsi olub. Qəbul zamanı vətəndaşların müraciətləri üzrə müvafiq izahatlar verilib, əlavə araşdırma tələb olunan məsələlərlə bağlı vətəndaşların ərizə yazmaların ərizələri qeydə alınıb. Qəbulda müraciətlərini şifahi şəkildə ünvanlayan vətəndaşlardan araşdırma üçün zəruri məlumatlar əldə olunub. Qeyd edək ki, maliyyə xidmətləri istehlakçılarının hüquqlarının müdafiəsi məqsədilə səyyar qəbulların keçirilməsi davam etdiriləcəkdir.',
  },
  {
    id: 2,
    title: 'İsmayıllı şəhərində səyyar vətəndaş qəbulu keçirilib',
    description:
      'Mərkəzi Bankı tərəfindən maliyyə xidmətləri istehlakçılarının və investorların hüquqlarının müdafiəsi çərçivəsində növbəti səyyar qəbul 3 sentyabr tarixində İsmayıllı şəhərində keçirilib. Səyyar qəbul İsmayıllı, Ağsu, Qobustan, Şamaxı inzibati rayonlarında yaşayan vətəndaşları əhatə edib. Qəbul zamanı vətəndaşların maliyyə xidmətləri ilə bağlı müraciətləri üzrə müvafiq izahatlar verilib, əlavə araşdırma tələb olunan məsələlərlə bağlı ərizələri qeydə alınıb. Müraciətlərini şifahi şəkildə ünvanlayan vətəndaşlardan araşdırma üçün zəruri məlumatlar əldə olunub.',
  },
  {
    id: 3,
    title: 'Biləsuvar rayonunda səyyar vətəndaş qəbulu keçirilib',
    description:
      'Mərkəzi Bank tərəfindən bölgələrdə yaşayan və nəzarət subyektləri ilə narazılıqları yaranan maliyyə xidmətləri istehlakçılarının Mərkəzi Bankın Bakı şəhərində yerləşən inzibati binasına yaxınlaşmadan müraciət etmək imkanının davam etdirilməsi və istehlakçı məmnuniyyətinin yüksəldilməsinin təmin edilməsi məqsədi ilə növbəti vətəndaş qəbulu 6 avqust tarixində Biləsuvar rayonunda keçirilib. Qəbul Cəbrayıl, Kəlbəcər, Qubadlı, Zəngilan, Laçın inzibati rayonlarında yaşayan vətəndaşları əhatə edib. Vətəndaşlar kredit istəyi, kredit üzrə güzəşt istəyi, məlumatların MKR-dən silinməməsi, kredit üzrə borcun düzgün hesablanmaması, ATM quraşdırılması, bank filiallarının açılması barədə müraciətlərini səsləndiriblər.',
  },
];
export const documents = {
  accordions: [
    {
      id: 1,
      title: 'Səhmdarların hüquq və vəzifələri',
      description:
        'Səhmdarların hüquqları:Cəmiyyətin idarə edilməsində Mülki Məcəllə, digər qanunvericiliklə və cəmiyyətin nizamnaməsi ilə müəyyən edilmiş qaydada iştirak etmək, onun idarəetmə və icra orqanlarına seçmək və seçilmək;',
    },
    {
      id: 2,
      title: 'Emitentlərin illik və yarımillik hesabatlarının təqdim edilməsi',
      description:
        'Emitentlər “Qiymətli kağızlar bazarı haqqında” Qanunun (Qanun) 75-ci maddəsi ilə nəzərdə tutulan hesabatları Mərkəzi Banka təqdim edilməklə ictimaiyyətə açıqlamalıdır. Emitentin illik hesabatı ilin nəticələri üzrə hazırlanır, onun ali idarəetmə orqanı tərəfindən təsdiq edilməklə Mərkəzi Banka təqdim edilir və Qanunun 75.5-ci maddəsi ilə müəyyən edilmiş qaydada Mərkəzi Bank həmin hesabatların açıqlanmasının dayandırılması haqqında göstəriş vermədikdə, onlar ictimaiyyətə açıqlanmalı və həmin hesabatın növbəti beş il ərzində ictimaiyyət üçün açıq olması təmin edilməlidir.',
      files: [
        {
          id: 1,
          title:
            '"Emitentin idarəetmə hesabatlarına dair tələblər haqqında Qaydalar" ın təsdiq edilməsi barədə Qərar',
          file_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
          web_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title: 'Emitentlər tərəfindən təqdim edilməli olan məlumatlar',
          file_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
          web_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
          type: 'pdf',
        },
      ],
    },
  ],
  paymentServices: [
    {
      id: 1,
      title:
        'Lisenziya əldə etmədən qanunsuz fəaliyyət göstərən ödəniş xidməti təchizatçıları barədə Mərkəzi Bankın məlumatlandırılması üzrə Təlimat',
      file_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
      web_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
      type: 'pdf',
    },
  ],
};
export const newsLetter = [
  {
    id: 1,
    title: '2024',
    files: [
      {
        id: 1,
        title:
          '2024-cü ilin yanvar ayı ücün İstehlakçıların hüquqlarının müdafiəsi və Maliyyə savadlılığı üzrə informasiya bülleteni',
        file_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
        web_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
        type: 'pdf',
      },
    ],
  },
  {
    id: 2,
    title: '2023',
    files: [
      {
        id: 1,
        title:
          '2023-cü ilin dekabr ayı ücün İstehlakçıların hüquqlarının müdafiəsi və Maliyyə savadlılığı üzrə informasiya bülleteni',
        file_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
        web_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
        type: 'pdf',
      },
      {
        id: 2,
        title:
          '2023-cü ilin noyabr ayı ücün İstehlakçıların hüquqlarının müdafiəsi və Maliyyə savadlılığı üzrə informasiya bülleteni',
        file_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
        web_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
        type: 'pdf',
      },
      {
        id: 3,
        title:
          '2023-cü ilin oktyabr ayı ücün İstehlakçıların hüquqlarının müdafiəsi və Maliyyə savadlılığı üzrə informasiya bülleteni',
        file_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
        web_url: 'https://uploads.cbar.az/assets/eed4e72e53ac8265c817ceb14.pdf',
        type: 'pdf',
      },
    ],
  },
];
