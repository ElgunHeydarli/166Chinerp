import { volunteer1, volunteer2, volunteer3, volunteer4, volunteer5 } from './images';

export const careerContentData = {
  text: 'İşə qəbul prosesinin mərhələləri:İşə qəbul prosesi Mərkəzi Bankın “İşə qəbul qaydaları”na əsasən bərabərlik və ədalətlilik prinsiplərinin təmin olunmaqla vəzifə tələblərinə ən uyğun namizədin seçilməsinə xidmət edir. Elan olunmuş vakansiyalar üzrə işə qəbul prosesi mərhələli qaydada həyata keçirilir və aşağıdakı mərhələlərdən ibarətdir: Müraciətlərin seçimi (Skrininq) İlkin müsahibə Test imtahanı və ya xüsusi yoxlama Panel müsahibə və yekun seçim Hər bir mərhələnin nəticəsi barədə namizədlərə email vasitəsilə bildiriş xarakterli məlumat təqdim edilir.',
};
export const vacancies = [
  {
    id: 1,
    slug: 'fwefr',
    vacancyName:
      'İnformasiya texnologiyaları əməliyyatları departamenti  Sistem inzibatçılığı bölməsi  Böyük sistem inzibatçısı (Microsoft üzrə)',
    deadline: '31.07.2025',
  },
  {
    id: 2,
    slug: 'fwefr',
    vacancyName:
      'Maliyyə sektorunun dayanıqlı inkişafı departamenti  Maliyyə inklüzivliyi bölməsi  Bölmə rəhbəri',
    deadline: '31.07.2025',
  },
  {
    id: 3,
    slug: 'fwefr',
    vacancyName:
      'Bazar davranışlarının tənzimlənməsi departamenti  Bazar davranışlarına nəzarətin metodologiyası şöbəsi  Şöbə rəisi',
    deadline: '31.07.2025',
  },
  {
    id: 4,
    slug: 'fwefr',
    vacancyName: 'Maliyyə monitorinqi departamenti  1-ci monitorinq şöbəsi  Aparıcı mütəxəssis',
    deadline: '31.07.2025',
  },
  {
    id: 5,
    slug: 'fwefr',
    vacancyName:
      'Maliyyə sektorunun dayanıqlı inkişafı departamenti  Maliyyə inklüzivliyi bölməsi  Bölmə rəhbəri',
    deadline: '31.07.2025',
  },
  {
    id: 6,
    slug: 'fwefr',
    vacancyName: 'Maliyyə monitorinqi departamenti  1-ci monitorinq şöbəsi  Aparıcı mütəxəssis',
    deadline: '31.07.2025',
  },
];

export const vacanyDetail = {
  id: 1,
  vacancyTitle: 'Bazar davranışları siyasəti şöbəsi  Böyük analitik',
  slug: 'fwefr',
  url: 'https://digital.login.gov.az/auth',
  department: 'Bazar davranışları siyasəti şöbəsi',
  employmentType: 'Tam iş günü',
  deadline: '08.07.2025',
  workplace: 'Bakı, Azərbaycan',
  details: [
    {
      id: 1,
      title: 'Vəzifə tələbləri',
      description:
        'Təhsil İqtisadiyyat/maliyyə - Ali təhsil Biznesin idarə edilməsi - Ali təhsil Texniki biliklər Bazar davranışı risklərinin təhlili (Bank üzrə) - Yüksək səviyyədə Təcrübə Bank tənzimlənməsi və ya bank sektorunda - 4 il Dil bilikləri Azərbaycan dili - Yüksək səviyyədə',
    },
    {
      id: 2,
      title: 'Test mövzuları',
      description:
        '– Məntiq– Ümumi iqtisadiyyat və bankçılıq– Bank qanunvericiliyi – Ümumi kompüter bilikləri – İngilis dili – Riyazi statistika və riyazi modelləşdirmə – Bankda risklərin idarə olunması – Əməliyyat riskləri',
    },
    {
      id: 3,
      title: 'Vəzifə öhdəlikləri',
      description:
        'Maliyyə xidmətlərində (məhsullarında) baş verən dəyişiklikləri və yenilikləri dövri izləyərək maliyyə xidmətlərinin (məhsullarının) test məqsədli alışların həyata keçirilməsini təşkil edir; Bank sahəsi üzrə maliyyə xidmətlərinin istehlakçıların şikayətləri və ya hüquq pozuntuları üzrə analitik hesabatlar hazırlayır; Bank sahəsi üzrə bazar davranışları risklərini təhlil edir;Bank sahəsi üzrə bazar davranışları alətlərinin tətbiq imkanlarını qiymətləndirir;Bank sahəsi üzrə bazar davranışlarının tənzimləmə və nəzarəti üzrə Mərkəzi Bankın strateji hədəflərinə, yerli və qlobal maliyyə sisteminin mövcud vəziyyətinin və inkişaf perspektivlərinin təhlilinin nəticələrinə əsaslanaraq maliyyə bazarlarının iştirakçılarının reputasiyasının, istehlakçı və investorların hüquqlarının qorunmasına yönəldilmiş tənzimləmə və nəzarət siyasəti üzrə təkliflərin hazırlanmasında Mərkəzi Bankın digər aidiyyəti struktur bölmələri ilə birgə iştirak edir',
    },
  ],
};

export const internship = {
  text: 'Azərbaycan Respublikasının Mərkəzi Bankı tərəfindən həyata keçirilən “Maliyyəçisən” təcrübə proqramı ölkənin yüksək potensiallı gənclərinə biliklərini təkmilləşdirmək və praktiki təcrübələrini artırmaq imkanı təqdim edir. Mərkəzi bankçılıq sistemi üzrə əvəzsiz təcrübə qazandıracaq bu proqram gənclərə uğurlu karyera yolunda inamla irəliləməyə təkan verəcək. İştirakçılar təcrübə müddəti ərzində seçilən istiqamətlər üzrə təyin olunan mentorların dəstəyi ilə ən mühüm bacarıqlara yiyələnəcək, müxtəlif bankdaxili təlimlərə qatılacaqlar. Proqramı uğurla bitirən təcrübəçilərə Mərkəzi Bank tərəfindən sertifikat və tövsiyə məktubu təqdim olunacaq.',
  internshipDirection: {
    category: 'directions',
    title: '2025-ci il üzrə təcrübə proqramının əhatə etdiyi istiqamətlər',
    directions: [
      {
        id: 1,
        icon: '/icons/internship1.svg',
        title: 'Tədqiqatlar departamenti',
        description:
          'Departamentinin fəaliyyətinin əsas məqsədi makroiqtisadi göstəricilərin proqnozlarının hazırlanması və Mərkəzi Bankda siyasət qərarlarının qəbuluna dəstək məqsədilə tədqiqat işlərinin həyata keçirilməsidir. Proqnozların keyfiyyətinin yaxşılaşdırılmasına xidmət edən yeni modellərin qurulması, onların mütəmadi təkmilləşdirilməsi departamentin əsas məqsədidir.',
      },
      {
        id: 2,
        icon: '/icons/internship2.svg',
        title: 'Pul siyasəti departamenti',
        description:
          'Departamentin fəaliyyətinin əsas məqsədi pul siyasətinin optimal çərçivəsini formalaşdırmaq və onun realizasiyasının monitorinqini aparmaqdan ibarətdir. Departamentin əsas fəaliyyəti isə pul siyasətinin əsas istiqamətlərinin işlənilib hazırlanması, pul siyasəti çərçivəsinin və əməliyyat prosedurlarının təkmilləşdirilməsi, pul siyasəti alətlərinin tətbiqi və təkmilləşdirilməsi və inflyasiya proseslərinin təhlili və onun əsas faktorlarını qiymətləndirilməsindən ibarətdir. Təşkilati struktur olaraq 3 şöbədən ibarətdir: Pul və məzənnə siyasəti şöbəsi, İqtisadi siyasətin təhlili şöbəsi, Pul siyasətinin hesabatlılığı şöbəsi. Pul siyasətinin hesabatlılığı şöbəsi 2025-ci ildə Pul siyasətinin hesabatlılığı şöbəsi təcrübəçi qəbul edəcək. Sözügedən şöbə pul siyasəti qərarlarının əsaslandırılması və qarşıya qoyulan hədəflərə nail olunması vəziyyəti ilə bağlı ictimaiyyətin məlumatlandırılmasını təmin edir, qanunvericiliyə uyğun olaraq müvafiq dövlət orqanlarına hesabatların ümumiləşdirilməsini təmin edir, müxtəlif dövlət proqramları və dövlət əhəmiyyətli strateji sənədlərdə pul siyasətinin yerinə yetirilməsi ilə bağlı hesabatlar hazırlayır. ',
      },
      {
        id: 3,
        icon: '/icons/internship3.svg',
        title: 'Maliyyə sabitliyi departamenti',
        description:
          'Departamentinfəaliyyətinin əsas məqsədi ölkədə maliyyə sektorunun sabitliyini və dayanıqlığını müəyyən edən amilləri qiymətləndirmək, sistem risklərini identifikasiya etmək, onların maliyyə sabitliyinə təsirini ölçmək məqsədilə müxtəlif model və alətlər formalaşdırmaq, o cümlədən stress-testlər keçirmək, risklərin neytrallaşdırılması üzrə siyasət alətlərinin formalaşdırılmasında iştirak etmək və maliyyə sabitliyinin təhlili üzrə analitik diaqnostika çərçivəsini inkişaf etdirməkdir. Maliyyə sabitliyi departamentində 2 şöbə mövcuddur: Makro-maliyyə risklərinin modelləşdirilməsi şöbəsi və Maliyyə sabitliyinin təhlili şöbəsi.',
      },
      {
        id: 4,
        icon: '/icons/internship4.svg',
        title: 'Bazar davranışlarının tənzimlənməsi departamenti',
        description:
          'Departamentin fəaliyyətinin əsas məqsədi maliyyə sektorunda istehlakçı və investorların hüquqlarının qorunmasına yönəldilmiş tənzimləmə və nəzarət siyasətini müəyyən etmək, maliyyə sektorunda ədalətli rəftara və biznes davranışlarına təsir edən riskləri müəyyən etmək, həmin risklərin minimallaşdırılması üzrə maliyyə xidmətləri istehlakçılarının və investorların hüquqlarının müdafiəsi siyasətini və nəzarət çərçivəsini formalaşdırmaqdır. Bazar davranışlarının tənzimlənməsi departamentdə 3 şöbə mövcuddur: Bazar davranışları siyasəti şöbəsi, Bazar davranışlarına nəzarətin metodologiyası şöbəsi, Maliyyə məlumatlılığı və peşəkar inkişaf şöbəsi.',
      },
      {
        id: 5,
        icon: '/icons/internship5.svg',
        title: 'Rezolyusiya departamenti',
        description:
          'Departamentin fəaliyyətinin əsas məqsədi ölkədə maliyyə sektorunun sabitliyinin dəstəklənməsi, qanunvericiliklə müəyyən olunmuş qaydada maliyyə bazarlarındakı problemli nəzarət subyektləri ilə bağlı rezolyusiya tədbirlərinin planlaşdırılması və təşkili, ləğv prosesində olan nəzarət subyektlərinin ləğvedicilərinin (ləğvetmə komissiyalarının, əmlak inzibatçılarının) fəaliyyətinə nəzarətin həyata keçirilməsi, rezolyusiya və ləğvetmə çərçivəsinin təkmilləşdirilməsi və bu çərçivədə kreditorların maraqlarının müdafiəsini təmin etməkdir. Rezolyusiya departamentində 2 şobə mövcuddur: Rezolyusiyanın planlaşdırılması və təşkili şöbəsi və Problemli maliyyə institutları ilə iş şöbəsi.',
      },
      {
        id: 6,
        icon: '/icons/internship6.svg',
        title: 'Sığorta fəaliyyətinin tənzimlənməsi departamenti',
        description:
          'Departamentin fəaliyyətinin əsas məqsədi sığorta fəaliyyətinin tənzimlənməsi çərçivəsinin formalaşdırılması və inkişaf etdirilməsi, bununla sığorta bazarının maliyyə sabitliyinin, habelə davamlı inkişafının təmin edilməsidir. Sığorta fəaliyyətinin tənzimlənməsi departamentində 2 şöbə mövcuddur: Tənzimləmə siyasəti şöbəsi, Sığortaçılara prudensial nəzarətin metodologiyası şöbəsi.',
      },
    ],
  },

  programDetails: {
    category: 'program',
    title: 'Proqrama müraciət ilə bağlı məlumat',
    text: 'Kimlər müraciət edə bilər? Təcrübə proqramına bakalavr pilləsinin 2-ci, 3-cü və 4-cü (və ya sonuncu) kurs tələbələri, magistratura pilləsində təhsil alan tələbələr və son iki ilin bakalavr və magistr məzunları müraciət edə bilər. Müraciət üçün son tarix hansıdır? Təcrübə proqramına müraciət etmək üçün son tarix 22 aprel 2025-ci ildir.Necə müraciət etmək olar? Müraciətlərin qəbulu yalnız aşağı sətrdə yerləşdirilən xüsusi müraciət forması vasitəsi ilə mümkündür. Müraciət forması https://forms.office.com/r/zNbL3QX0ti Əlavə suallarınız yaranarsa maliyyecisen@cbar.az ünvanına müraciət edə bilərsiniz.',
  },
  volunteer: {
    category: 'volunteers',
    title: '2024-cü ilin Maliyyəçisən təcrübəçilərinin hekayələri',
    volunteers: [
      {
        id: 1,
        image: volunteer1,
        fullName: 'Aysu Veysova',
        description:
          '2 ay təcrübə müddətində mentorumla yanaşı departamentimizin bütün üzvləri öz dəstəyini göstərdi. İstər texniki biliklərimin inkişafına, istərsə də şəxsi inkişafıma bu təcrübə proqramının böyük töhfəsi oldu. Təcrübə yoldaşlarımla qurduğum ünsiyyət bu proqramı daha da maraqlı etdi. Bizim üçün təşkil edilən təlimlər həmçinin faydalı və maraqlı idi.Bu müddətdə yadda qalan ən vacib məsələ mənim əsl komanda işini nümayiş etdirməyimiz oldu. İdeyalar formalaşdırmaq, araşdırmalar etmək və yoldaşlarımızla bölüşüb müzakirələr aparmaq aramızdakı əlaqəni gücləndirdi. Təcrübə müddətində tanıdığım bir neçə yoldaşlarım var ki, onlarla münasibətimiz bundan sonra da davam edəcək. Yaddaqalan anlardan növbətisi isə departamentlə edilən korparativ naharlar idi. Başda rəhbərim və mentorum olmaqla hər kəsin mənlə həmsöhbət olması, fikir mübadiləsi etməsi mənə çox xoş bir təsir buraxdı.Son olaraq vurğulamaq istəyirəm ki,”Maliyyəçisən” proqramı mənim üçün öz bacarıqlarımı təkmilləşdirdiyim, yeni əlaqələr qurduğum və mühüm layihədə iştirak etdiyim bir təcrübə oldu.',
      },
      {
        id: 2,
        image: volunteer2,
        fullName: 'Aytac Süleymanova',
        description:
          'Maliyyəçisən təcrübə proqramına qəbul olmaq mənim üçün böyük bir addım idi.Proqram ərzində əldə etdiyim şəxsi və peşəkar nailiyyətlər mənim üçün çox dəyərli oldu. Yüksək peşəkar korporativ mədəniyyətə sahib olan Mərkəzi Bankda çalışdığım müddətdə komanda mənə böyük dəstək göstərdi. Onların peşəkarlığı isə mənə ilham verdi.Layihə komandamla birlikdə hazırladığımız təqdimatda qarşılaşdığımız çətinliklər və bu çətinlikləri aşmaq üçün göstərdiyimiz səylər mənim üçün unudulmaz təcrübə oldu. Layihə komandasının bir hissəsi olmaq mənə komanda işinin əhəmiyyətini və effektiv ünsiyyətin vacibliyini öyrətdi. Hər bir komanda üzvünün fərqli bacarıqları və perspektivləri layihələrimizin uğuruna böyük töhfə verdi.Bu təcrübə mənim karyera hədəflərimə böyük təsir göstərdi və mənə gələcəkdə daha böyük uğurlar əldə etmək üçün motivasiya oldu. Bu proqramda iştirak etdiyim üçün çox şadam və gələcək təcrübəçilərə də bu proqramı tövsiyə edirəm.',
      },
      {
        id: 3,
        image: volunteer3,
        fullName: 'Cavad Faiqli',
        description:
          'Maliyyəçisən ilə tanışlığım 2023-cü ilə təsadüf edir. Özümə Addıma mərkəzdən başla deyərək proqrama müraciət etmək qərarına gəldim. Həmin il uğursuz olsam da, həvəsimi itirmədən növbəti ili gözlədim. Həmin zaman gəlib çatdı. Hər bir mərhələni uğurla keçdikcə özümə güvənim daha da artdı. Nəhayət 1 il öncə qərar verdiyim, xəyalını qurduğum yerə qəbul oldum. Təbii ki, işinə töhfə verə biləcəyimi düşündüyüm, hər iki ildə də müraciət etdiyim Pul siyasəti departamentində təcrübə keçmək imkanı qazandım. Əməkdaşlarla, təcrübəçilərlə, bütünlükdə Mərkəzi Bank ailəsi ilə yeni yaranan münasibətlər, professional iş təcrübəsi, yumşaq və texniki bacarıqlar, sahənin mütəxəssislərindən mentor dəstəyi, layihə komandamla görüşlər, müzakirələr, birlikdə çalışdığımız saatlar, İnsan resursları komandasının təlimləri, görüşlər mənim üçün çox dəyərlidir. Belə peşəkar bir mühitdə olduğum, əvəzsiz təcrübə qazandığım üçün Mərkəzi Bank ailəsinə təşəkkür edirəm.Mənim Mərkəzi Bank hekayəm burada bitmir. 2 ay öncə təcrübəçi olaraq daxil olduğum ailənin artıq bir üzvüyəm!',
      },
      {
        id: 4,
        image: volunteer4,
        fullName: 'Cəmilə Mehdiyeva',
        description:
          'Maliyyəçisən təcrübə proqramında iştirak üçün bütün mərhələləri uğurla keçdim. Təcrübə müddətində Mərkəzi Bankın əməkdaşları ilə tanışlıq məni yaxşı mənada təəccübləndirdi. O qədər səmimi, mehriban bir mühit var idi ki, hər gün işə gəlmək istəyirdim. Məsul olduğum departamentlə bir neçə dəfə nahar etdik. Bizdən gələcək planlarımızla bağlı soruşub məsləhətlər verirdilər. Bundan əlavə departament rəhbərliyinin təcrübəçilərlə nahar zamanı təəssüratlarını öyrənməsi, şəxsi karyera yolundan danışaraq məsləhətlər verməsi bizə daha da ruhlandırmışdı. Mükəmməl olaraq keçirdiyim 2 ay ərzində iş yoldaşlarımın mənə hər dəfə çox çalışqan biri olduğumu bildirməsi, nə olursa olsun hər zaman irəli gedə biləcəyimi vurğulaması məni motivasiya edirdi. Sonda məzun günündə cənab sədrə təcrübəçi kimi hansı departamenti seçməyi ilə bağlı sual veriləndə cavabında Maliyyə sabitliyi demişdi. Bu cavabla düzgün seçim etdiyimə daha əmin oldum.',
      },
      {
        id: 5,
        image: volunteer5,
        fullName: 'Elxan İsayev',
        description:
          'Maliyyəçisən təcrübə proqramı mənim üçün maraqlı və bir o qədər də fərqliliklərlə dolu marafon oldu. Bu təcrübə proqramı mənə korporativ leqonun ayrılmaz bir hissəsi olmaqdan əlavə, peşəkar əməkdaşlar tərəfindən olunan dəstək ilə real təcrübələrin vacib parçası olmaq imkanı verdi. Mentorumla hər zaman komanda şəklində üzərimizə düşən öhdəlikləri böyük həvəslə həll etdik. Bəzən bu nəticələr uzun-uzun, müxtəlif fikirlərin debatı nəticəsində ortaya çıxırdı. Təsadüfi deyil ki, ən mükəmməl qərarlar məhz bu kimi aktiv debatlar nəticəsində doğur.Düşünürəm ki, Maliyyəçisən təcrübə proqramı karyeram boyunca unudulmaz bir xatirə olaraq qalacaq.',
      },
    ],
  },
};
