export const exchangeRateList = {
  text: 'Qeyd-1: 02.10.2005-ci il tarixindən etibarən 100 Özbəkistan somunun, 100 Livan funtunun, 100 Yaponiya yeninin və 100 İran rialının 1 Azərbaycan manatına qarşı rəsmi məzənnələrinin müəyyən edildiyi nəzərə alınmalıdır. Qeyd-2: 01.01.2006-cı il tarixində Azərbaycan manatının 5000:1 nisbətində denominasiyası həyata keçirilmişdir. Qeyd-3: 01.07.2016-cı il tarixinədək 100 Belarus rublunun və 02.10.2005-12.01.2009-cu il tarixlərində 100 Türkmənistan manatının 1 Azərbaycan manatına qarşı rəsmi məzənnələrinin müəyyən edildiyi nəzərə alınmalıdır. Qeyd-4: 18.11.2024-cü il tarixindən etibarən 100 Rus rublunun, 100 Qazaxıstan tengəsinin və 10.000 İran rialının 1 Azərbaycan manatına qarşı rəsmi məzənnələrinin müəyyən edildiyi nəzərə alınmalıdır.',
  exchangeRates: {
    id: 1,
    excelUrL: 'lisntewdwed',
    list: [
      {
        id: 1,
        exchange: '1 ABŞ dolları',
        code: 'USD',
        course: '1.7000',
        status: 'constant',
      },
      {
        id: 2,
        exchange: '1 Avro',
        code: 'EUR',
        course: '2.0029',
        status: 'decrease',
      },
      {
        id: 3,
        exchange: '1 Avstraliya dolları',
        code: 'AUD',
        course: '1.1172',
        status: 'increase',
      },
      {
        id: 4,
        exchange: '1 Belarus rublu',
        code: 'BYN',
        course: '0.5728',
        status: 'constant',
      },
    ],
  },
};

export const oneExchangeRateList = {
  currency: [
    {
      id: 1,
      value: '1 Avro',
    },
    {
      id: 2,
      value: '1 Dollar',
    },
    {
      id: 3,
      value: '1 Avro',
    },
    {
      id: 4,
      value: '1 Dollar',
    },
  ],
  resultData: {
    id: 1,
    title: ' 1 Avro',
    excelUrL: 'lisntewdwed',
    list: [
      {
        id: 1,
        date: ' 31.01.2025 ',
        course: '1.7000',
      },
      {
        id: 2,
        date: ' 31.01.2025 ',
        course: '1.7000',
      },
      {
        id: 3,
        date: ' 31.01.2025 ',
        course: '1.7000',
      },
    ],
  },
};
export const changeCurrency = {
  currencyFrom: [
    {
      id: 1,
      value: 'Azərbaycan Manatı',
    },
    {
      id: 2,
      value: 'ABŞ Dolları',
    },
  ],
  currencyTo: [
    {
      id: 1,
      value: 'Azərbaycan Manatı',
    },
    {
      id: 2,
      value: 'ABŞ Dolları',
    },
  ],
  resultData: {
    id: 1,
    resutl: 5,
  },
};
