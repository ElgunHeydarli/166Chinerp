import aboutBg from '../images/aboutBg.png';
import bilesuvarOffice from '../images/bilesuvarOffice.png';
import chairman from '../images/chairman.png';
import chairmanVice1 from '../images/chairmanVice1.png';
import chairmanVice2 from '../images/chairmanVice2.png';
import chairmanVice3 from '../images/chairmanVice3.png';
import chairmanVice4 from '../images/chairmanVice4.png';
import chairmanVice5 from '../images/chairmanVice5.png';
import eventsImage from '../images/eventsImage.png';
import financialLiteracyPortal from '../images/financialLiteracyPortal.png';
import footerLogo from '../images/footer-logo.svg';
import footerDecoration from '../images/footerDecoration.svg';
import HeyderEliyev from '../images/HeyderEliyev.svg';
import homeHeroBg from '../images/homeHeroBg.png';
import infoSearch1 from '../images/infoSearch1.png';
import infoSearch2 from '../images/infoSearch2.png';
import infoSearch3 from '../images/infoSearch3.png';
import InfoSearchSystem from '../images/InfoSearchSystem.png';
import internationalEvent1 from '../images/internationalEvent1.jpg';
import internationalEvent2 from '../images/internationalEvent2.jpg';
import internationalEvent3 from '../images/internationalEvent3.jpg';
import internationalEvent4 from '../images/internationalEvent4.jpg';
import internationalEvent5 from '../images/internationalEvent5.jpg';
import internationalEvent6 from '../images/internationalEvent6.jpg';
import internationalEvent7 from '../images/internationalEvent7.jpg';
import internationalEvent8 from '../images/internationalEvent8.jpg';
import internationalEvent9 from '../images/internationalEvent9.jpg';
import internationalEvent10 from '../images/internationalEvent10.jpg';
import leaderShip1 from '../images/leaderShip1.png';
import leaderShip2 from '../images/leaderShip2.png';
import leaderShip3 from '../images/leaderShip3.png';
import leaderShip4 from '../images/leaderShip4.png';
import leaderShip5 from '../images/leaderShip5.png';
import leaderShip6 from '../images/leaderShip6.png';
import leaderShip7 from '../images/leaderShip7.png';
import leaderShip8 from '../images/leaderShip8.png';
import navbarlogo from '../images/logo-navbar.svg';
import media1_1 from '../images/media1_1.jpg';
import media1_2 from '../images/media1_2.jpg';
import media1_3 from '../images/media1_3.jpg';
import media2_1 from '../images/media2_1.jpg';
import media2_2 from '../images/media2_2.jpg';
import media2_3 from '../images/media2_3.jpg';
import media3_1 from '../images/media3_1.jpg';
import media3_2 from '../images/media3_2.jpg';
import media3_3 from '../images/media3_3.jpg';
import naxcivan1 from '../images/naxcivan1.png';
import naxcivanOffice from '../images/naxcivanOffice.png';
import portalImg1 from '../images/portalImg1.png';
import portalImg2 from '../images/portalImg2.png';
import portalImg3 from '../images/portalImg3.png';
import poster from '../images/poster.jpg';
import topVokus from '../images/topVokus.png';
import videoCover1 from '../images/videoCover1.jpg';
import videoCover2 from '../images/videoCover2.jpg';
import videoCover3 from '../images/videoCover3.jpg';
import virtualEdu1 from '../images/virtualEdu1.png';
import virtualEdu2 from '../images/virtualEdu2.png';
import virtualEdu3 from '../images/virtualEdu3.png';
import virtualEducationPlatform from '../images/virtualEducationPlatform.png';
import volunteer1 from '../images/volunteer1.jpg';
import volunteer2 from '../images/volunteer2.jpg';
import volunteer3 from '../images/volunteer3.jpg';
import volunteer4 from '../images/volunteer4.jpg';
import volunteer5 from '../images/volunteer5.jpg';
import yevlaxOffice from '../images/yevlaxOffice.png';

export {
  aboutBg,
  bilesuvarOffice,
  chairman,
  chairmanVice1,
  chairmanVice2,
  chairmanVice3,
  chairmanVice4,
  chairmanVice5,
  eventsImage,
  financialLiteracyPortal,
  footerDecoration,
  footerLogo,
  HeyderEliyev,
  homeHeroBg,
  infoSearch1,
  infoSearch2,
  infoSearch3,
  InfoSearchSystem,
  internationalEvent1,
  internationalEvent2,
  internationalEvent3,
  internationalEvent4,
  internationalEvent5,
  internationalEvent6,
  internationalEvent7,
  internationalEvent8,
  internationalEvent9,
  internationalEvent10,
  leaderShip1,
  leaderShip2,
  leaderShip3,
  leaderShip4,
  leaderShip5,
  leaderShip6,
  leaderShip7,
  leaderShip8,
  media1_1,
  media1_2,
  media1_3,
  media2_1,
  media2_2,
  media2_3,
  media3_1,
  media3_2,
  media3_3,
  navbarlogo,
  naxcivan1,
  naxcivanOffice,
  portalImg1,
  portalImg2,
  portalImg3,
  poster,
  topVokus,
  videoCover1,
  videoCover2,
  videoCover3,
  virtualEdu1,
  virtualEdu2,
  virtualEdu3,
  virtualEducationPlatform,
  volunteer1,
  volunteer2,
  volunteer3,
  volunteer4,
  volunteer5,
  yevlaxOffice,
};
