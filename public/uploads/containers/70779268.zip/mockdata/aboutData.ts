export const structure = {
  chairman: {
    name: 'Taleh Kazımov',
    title: 'Azərbaycan Mərkəzi Bankının İdarə Heyətinin Sədri',
  },
  department: {
    name: 'Departamentlər və şöbələr',
    children: [
      { name: 'İnformasiya və kibertəhlükəsizlik', person: 'Elnur Eyvazlı' },
      { name: 'Daxili audit', person: 'Elçin Əliyev' },
      { name: 'Təhlükəsizlik', person: 'Namiq Quliyev' },
      {
        name: 'Tədqiqatlar və Statistika',
        person: 'Asif Qasımov / Samir Nəsirov',
      },
      {
        name: 'Beynəlxalq əməkdaşlıq və kommunikasiya',
        person: 'Tural İsmayılov',
      },
      { name: 'Sədrlik ofisi', person: 'Xəqani Dədəzadə' },
    ],
  },
  headDirector: {
    name: 'Baş direktor',
    person: 'Vüqar Əhmədov',
    children: [
      {
        name: 'Tədqiqatlar və Statistika',
        children: [
          { name: 'Tədqiqatlar', person: 'Asif Qasımov' },
          { name: 'Statistika', person: 'Samir Nəsirov' },
        ],
      },
      {
        name: 'Monetar siyasət',
        children: [{ name: 'Pul siyasəti', person: 'Azər Ələsgərov' }],
      },
    ],
  },
  vicechairmans: [
    {
      name: 'Sədrin 1-ci müavini',
      person: 'Ələyar Məmmədov',
      children: [
        {
          name: 'Baş direktor',
          person: 'Şahin Mahmudzadə',
          children: [
            {
              name: 'Maliyyə sabitliyi',
              children: [
                { name: 'Maliyyə sabitliyi', person: 'Ataxan Həsənov' },
                {
                  name: 'Maliyyə sektorunun dayanıqlı inkişafı',
                  person: 'Rüstəm Tahirov',
                },
                {
                  name: 'Bazar davranışlarının tənzimlənməsi',
                  person: 'Tamerlan Əliyev',
                },
                { name: 'Rezolyusiya', person: 'Anar Muxtarov' },
              ],
            },
          ],
        },
        {
          name: 'Baş direktor',
          person: 'Vüsal Qurbanov',
          children: [
            {
              name: 'Sığorta fəaliyyətinin tənzimlənməsi',
              children: [
                {
                  name: 'Sığorta fəaliyyətinin tənzimlənməsi',
                  person: 'Pənah Bənnayev',
                },
                { name: 'Sığorta fəaliyyətinə nəzarət' },
              ],
            },
          ],
        },
      ],
    },
    {
      name: 'Sədrin müavini',
      person: 'Toğrul Əliyev',
      children: [
        {
          name: 'Baş direktor',
          person: 'Fuad İsayev',
          children: [
            {
              name: 'Kredit təşkilatlarının fəaliyyətinin tənzimlənməsi',
              children: [
                {
                  name: 'Kredit təşkilatlarının fəaliyyətinə dair siyasət və tənzimlənmə',
                  person: 'Leyla Nəbiyeva',
                },
                {
                  name: 'Bankların fəaliyyətinə nəzarət',
                  person: 'Samir Rzayev',
                },
                {
                  name: 'Bank olmayan kredit təşkilatlarının fəaliyyətinə nəzarət',
                  person: 'Xəyyam İsmayılov',
                },
              ],
            },
            {
              name: 'Maliyyə monitorinqi',
              children: [
                {
                  name: 'Maliyyə monitorinqi üzrə siyasət və tənzimlənmə',
                  person: 'Zaur Hacılı',
                },
                { name: 'Maliyyə monitorinqi', person: 'Orxan Abdullayev' },
              ],
            },
          ],
        },
      ],
    },
    {
      name: 'Sədrin müavini',
      person: 'Əli Əhmədov',
      children: [
        {
          name: 'Baş direktor',
          person: 'Tərlan Rəsulov',
          children: [
            {
              name: 'Kapital bazarı fəaliyyətinin tənzimlənməsi',
              children: [
                {
                  name: 'Kapital bazarı fəaliyyətinə dair siyasət və tənzimlənmə',
                  person: 'Umeyra İbrahimova',
                },
                {
                  name: 'Kapital bazarı fəaliyyətinə nəzarət',
                  person: 'Müşfiq Əmirov',
                },
              ],
            },
          ],
        },
        {
          name: 'Baş direktor',
          person: 'Elrad Seydiyev',
          children: [
            {
              name: 'Ehtiyatların idarəedilməsi və bazar əməliyyatları',
              children: [
                {
                  name: 'Valyuta ehtiyatlarının idarəedilməsi',
                },
                {
                  name: 'Maliyyə bazarlarında əməliyyatlar',
                  person: 'Rəxşəndə Əlili',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      name: 'Sədrin müavini',
      person: 'Vüsal Xəlilov',
      children: [
        {
          name: 'Texnologiya, Data və İnnovasiyalar',
          children: [
            {
              name: 'Maliyyə texnologiyaları və innovasiyalar',
              person: 'Fidan Tofidi',
            },
            {
              name: 'İT Əməliyyatları',
              person: 'Sadiq Axundov',
            },
            { name: 'Rəqəmsal Mühəndislik' },
            { name: 'Data' },
            { name: 'İT idarəetmə və arxitektura' },
          ],
        },
        {
          name: 'Ödəniş xidmətləri və ödəniş sistemləri fəaliyyətinin tənzimlənməsi',
          children: [
            {
              name: 'Ödəniş xidmətləri və ödəniş sistemləri üzrə fəaliyyətə nəzarət və siyasət',
              person: 'Kəmalə Qurbanova',
            },
            {
              name: 'Ödəniş sistemləri və məhsulların inkişafı',
              person: 'Əfqan Abbasov',
            },
          ],
        },
      ],
    },
    {
      name: 'Sədrin müavini',
      person: 'Gülər Paşayeva',
      children: [
        {
          name: 'Baş direktor',
          person: 'Rəşad Məmmədov',
          children: [
            {
              name: 'Əməliyyat',
              children: [
                {
                  name: 'Nağd pul və hesablaşmalar',
                  person: 'Fətullah Ələkbərov',
                },
                {
                  name: 'Xəzinə',
                  person: 'Elnur Ağayev',
                },
                {
                  name: 'İstehlakçılarla iş',
                  person: 'Murad Məmmədov',
                },
                { name: 'Regional Ərazi İdarələri' },
              ],
            },
          ],
        },
        {
          name: 'Baş direktor',
          person: 'Rəna Məlikova',
          children: [
            {
              name: 'Hüquq',
              children: [
                {
                  name: 'Maliyyə bazarlarının hüquqi təminatı',
                  person: 'Mehriban Məmmədova',
                },
                {
                  name: 'Hüquq və təşkilati işlər',
                  person: 'Ayaz Mirzəzadə',
                },
              ],
            },
          ],
        },
        {
          name: 'Baş direktor',
          person: 'Anar Mansurov',
          children: [
            {
              name: 'Təşkilati inkişaf',
              children: [
                { name: 'Maliyyə idarəetməsi' },
                {
                  name: 'Risklərin idarəedilməsi',
                  person: 'Məhəmməd Məhərrəmli',
                },
                { name: 'İnzibati işlər', person: 'Fərhad Vəliyev' },
                { name: 'Satınalmalar', person: 'Ayaz Nağıyev' },
              ],
            },
          ],
        },
      ],
      others: [
        {
          name: 'İnsan resursları',
          person: 'Oksana İsmayılova',
        },
        {
          name: 'Strategiya və layihə idarəetməsi',
          person: 'Fuad Cəfərov',
        },
      ],
    },
  ],
};
