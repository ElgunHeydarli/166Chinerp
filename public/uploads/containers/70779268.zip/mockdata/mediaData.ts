import newsDetail1 from '../images/newsDetail1.jpg';
import newsDetail2 from '../images/newsDetail2.jpg';
import newsDetail3 from '../images/newsDetail3.jpg';
import newsDetail4 from '../images/newsDetail4.jpg';
import newsDetail5 from '../images/newsDetail5.jpg';
import newsDetail6 from '../images/newsDetail6.jpg';
import newsDetail7 from '../images/newsDetail7.jpg';
import eventItemInner1 from '../images/eventItemInner1.jpg';
import eventItemInner2 from '../images/eventItemInner2.jpg';
import eventItemInner3 from '../images/eventItemInner3.jpg';
import eventItemInner4 from '../images/eventItemInner4.jpg';
import eventItemInner5 from '../images/eventItemInner5.jpg';
import eventItemInner6 from '../images/eventItemInner6.jpg';
import eventItemInner7 from '../images/eventItemInner7.jpg';
import eventItemInner8 from '../images/eventItemInner8.jpg';
import eventItemInner9 from '../images/eventItemInner9.jpg';
import eventItemInner10 from '../images/eventItemInner10.jpg';
import eventItemInner11 from '../images/eventItemInner11.jpg';
import eventItemInner12 from '../images/eventItemInner12.jpg';
import cbar_105_1 from '../images/cbar_105_1.jpg';
import cbar_105_2 from '../images/cbar_105_2.jpg';
import cbar_105_3 from '../images/cbar_105_3.jpg';
import cbar_105_4 from '../images/cbar_105_4.jpg';
import cbar_105_5 from '../images/cbar_105_5.jpg';
import stampImage from '../images/stampImage.jpg';
import anniversaryCoinImg from '../images/anniversaryCoin.jpg';
import training1 from '../images/training1.jpg';
import training2 from '../images/training2.jpg';
import training3 from '../images/training3.jpg';
import training4 from '../images/training4.jpg';
import training5 from '../images/training5.jpg';
import training6 from '../images/training6.jpg';
import training7 from '../images/training7.jpg';
import training8 from '../images/training8.jpg';
import training9 from '../images/training9.jpg';
import cbar_100_1 from '../images/cbar_100_1.jpg';
import cbar_100_2 from '../images/cbar_100_2.jpg';
import cbar_100_3 from '../images/cbar_100_3.jpg';
import cbar_100_4 from '../images/cbar_100_4.jpg';
import cbar_100_5 from '../images/cbar_100_5.jpg';
import cbar_100_6 from '../images/cbar_100_6.jpg';
import cbar_100_7 from '../images/cbar_100_7.jpg';
import cbar_100_8 from '../images/cbar_100_8.jpg';

import {
  media1_1,
  media1_2,
  media1_3,
  media2_1,
  media2_2,
  media2_3,
  media3_1,
  media3_2,
  media3_3,
  videoCover1,
  videoCover2,
  videoCover3,
} from './images';

export const mediaInnerData = {
  text: 'Mərkəzi Bankın kommunikasiyası onun missiyası, strateji və əməliyyat hədəfləri, fəaliyyət nəticələri haqqında bütün hədəf qruplarının məlumatlandırılması məqsədi ilə təşkil edilir. Operativ, əhatəli, aydın və dəqiq məlumatların ictimaiyyətə açıqlanması əsas hədəf qrupları tərəfindən Mərkəzi Bankın həyata keçirdiyi siyasətin daha yaxşı qavranılmasına, bununla da iqtisadi-monetar gözləntilərin formalaşdırılmasına imkan verir və gözləntilərin yönəldilməsi hədəf qruplarının adekvat davranışlarını təmin edir. Beləliklə, effektiv kommunikasiya siyasəti və onun uğurlu əməliyyat çərçivəsi hədəf qruplarının gözləntilərinin yönəldilməsinin başlıca vasitəsidir.Mərkəzi Bankın kommunikasiyasının hədəfi onun etimad imicinin qorunması və daim inkişaf etdirilməsi ilə hədəf qruplarının adekvat iqtisadi gözləntilərinin formalaşdırılmasına və yönəldilməsinə nail olmaqla missiyasının daha effektiv realizasiyasının təmin olunmasından ibarətdir.',
};
export const newsData = [
  {
    id: 1,
    title:
      'Mərkəzi Bankın rəhbər şəxsləri üçün ADA Universitetində keçirilən “Liderlik səriştələri” üzrə təlim proqramı yekunlaşıb',
    description:
      'Mərkəzi Bank ilə ADA Universitetinin İxtisasartırma Proqramının əməkdaşlığı çərçivəsində keçirilən “Liderlik səriştələri” üzrə təlim proqramının bağlanış mərasimi təşkil olunub.',
    date: '17.06.2025',
    slug: 'afesf',
  },
  {
    id: 2,
    title:
      'Mərkəzi Bankın rəhbər şəxsləri üçün ADA Universitetində keçirilən “Liderlik səriştələri” üzrə təlim proqramı yekunlaşıb',
    description:
      'Mərkəzi Bank ilə ADA Universitetinin İxtisasartırma Proqramının əməkdaşlığı çərçivəsində keçirilən “Liderlik səriştələri” üzrə təlim proqramının bağlanış mərasimi təşkil olunub.',
    date: '17.06.2025',
    slug: 'afesf',
  },
  {
    id: 3,
    title:
      'Mərkəzi Bankın rəhbər şəxsləri üçün ADA Universitetində keçirilən “Liderlik səriştələri” üzrə təlim proqramı yekunlaşıb',
    description:
      'Mərkəzi Bank ilə ADA Universitetinin İxtisasartırma Proqramının əməkdaşlığı çərçivəsində keçirilən “Liderlik səriştələri” üzrə təlim proqramının bağlanış mərasimi təşkil olunub.',
    date: '17.06.2025',
    slug: 'afesf',
  },
  {
    id: 4,
    title:
      'Mərkəzi Bankın rəhbər şəxsləri üçün ADA Universitetində keçirilən “Liderlik səriştələri” üzrə təlim proqramı yekunlaşıb',
    description:
      'Mərkəzi Bank ilə ADA Universitetinin İxtisasartırma Proqramının əməkdaşlığı çərçivəsində keçirilən “Liderlik səriştələri” üzrə təlim proqramının bağlanış mərasimi təşkil olunub.',
    date: '17.06.2025',
    slug: 'afesf',
  },
  {
    id: 5,
    title:
      'Mərkəzi Bankın rəhbər şəxsləri üçün ADA Universitetində keçirilən “Liderlik səriştələri” üzrə təlim proqramı yekunlaşıb',
    description:
      'Mərkəzi Bank ilə ADA Universitetinin İxtisasartırma Proqramının əməkdaşlığı çərçivəsində keçirilən “Liderlik səriştələri” üzrə təlim proqramının bağlanış mərasimi təşkil olunub.',
    date: '17.06.2025',
    slug: 'afesf',
  },
];
export const announceData = [
  {
    id: 1,
    title: 'Təkliflərin cəlb edilməsi barədə elan',
    description:
      '1. Azərbaycan Respublikasının Mərkəzi Bankı (Bakı şəhəri, R.Behbudov küçəsi 90) “Dövlət satınalmaları haqqında” Azərbaycan Respublikasının Qanununa uyğun olaraq, elektrikli yükqaldıran (stekker) və yükdaşıyan arabalara texniki xidmətin satın alınması üzrə kotirovka sorğusu keçirir.',
    date: '18.06.2025',
    slug: 'afesf',
  },
  {
    id: 2,
    title: 'Təkliflərin cəlb edilməsi barədə elan',
    description:
      '1. Azərbaycan Respublikasının Mərkəzi Bankı (Bakı şəhəri, R.Behbudov küçəsi 90) “Dövlət satınalmaları haqqında” Azərbaycan Respublikasının Qanununa uyğun olaraq, elektrikli yükqaldıran (stekker) və yükdaşıyan arabalara texniki xidmətin satın alınması üzrə kotirovka sorğusu keçirir.',
    date: '18.06.2025',
    slug: 'afesf',
  },
  {
    id: 3,
    title: 'Təkliflərin cəlb edilməsi barədə elan',
    description:
      '1. Azərbaycan Respublikasının Mərkəzi Bankı (Bakı şəhəri, R.Behbudov küçəsi 90) “Dövlət satınalmaları haqqında” Azərbaycan Respublikasının Qanununa uyğun olaraq, elektrikli yükqaldıran (stekker) və yükdaşıyan arabalara texniki xidmətin satın alınması üzrə kotirovka sorğusu keçirir.',
    date: '18.06.2025',
    slug: 'afesf',
  },
  {
    id: 4,
    title: 'Təkliflərin cəlb edilməsi barədə elan',
    description:
      '1. Azərbaycan Respublikasının Mərkəzi Bankı (Bakı şəhəri, R.Behbudov küçəsi 90) “Dövlət satınalmaları haqqında” Azərbaycan Respublikasının Qanununa uyğun olaraq, elektrikli yükqaldıran (stekker) və yükdaşıyan arabalara texniki xidmətin satın alınması üzrə kotirovka sorğusu keçirir.',
    date: '18.06.2025',
    slug: 'afesf',
  },
  {
    id: 5,
    title: 'Təkliflərin cəlb edilməsi barədə elan',
    description:
      '1. Azərbaycan Respublikasının Mərkəzi Bankı (Bakı şəhəri, R.Behbudov küçəsi 90) “Dövlət satınalmaları haqqında” Azərbaycan Respublikasının Qanununa uyğun olaraq, elektrikli yükqaldıran (stekker) və yükdaşıyan arabalara texniki xidmətin satın alınması üzrə kotirovka sorğusu keçirir.',
    date: '18.06.2025',
    slug: 'afesf',
  },
];
export const newsInnerData = {
  id: 1,
  slug: 'deswfw',
  date: '17.06.2025',
  title:
    'Mərkəzi Bankın rəhbər şəxsləri üçün ADA Universitetində keçirilən “Liderlik səriştələri” üzrə təlim proqramı yekunlaşıb',
  description:
    'Mərkəzi Bank ilə ADA Universitetinin İxtisasartırma Proqramının əməkdaşlığı çərçivəsində keçirilən “Liderlik səriştələri” üzrə təlim proqramının bağlanış mərasimi təşkil olunub. Tədbirdə çıxış edən Mərkəzi Bankın sədr müavini Gülər Paşayeva ADA Universiteti ilə əməkdaşlıq çərçivəsində təşkil olunan bu növ təlimlərin ölkədə insan kapitalının inkişafında və liderlərin yetişdirilməsində mühüm rol oynadığını vurğulayıb. O, bu təlim proqramı ərzində idarəetmə sahəsində qazanılmış müasir səriştə və bacarıqların təşkilatın ümumi uğuruna töhfə verəcəyini qeyd edib.Mərkəzi Bankın sədr müavini Vüsal Xəlilov təlimin əhəmiyyətindən danışarkən əldə olunmuş yeni bacarıqların tətbiqinin ölkə üçün dəyər yaradacağına dair əminliyini bildirib.Mərkəzi Bankın sədr müavini Toğrul Əliyev bu inkişaf proqramının həm şəxsi, həm də peşəkar müstəvidə mühüm rol oynayacağını qeyd edib və iştirakçılara uğurlar arzulayıb.ADA Universitetinin Akademik işlər üzrə prorektoru Dr. Elkin Nurməmmədov təlimlərin komanda ruhunu gücləndirdiyini bildirib. O, təlimin iştirakçılara çevik qərarvermə və effektiv idarəetmə bacarıqları qazandırmaqla onların peşəkar inkişafında mühüm rol oynayacağına dair əminliyini ifadə edib. ADA Universitetinin akademik işlər üzrə prorektorunun müşaviri və İxtisasartırma proqramının rəhbəri Aygün Hacıyeva öz çıxışında proqramın peşəkar inkişaf baxımından mühüm əhəmiyyət kəsb etdiyini vurğulayıb və iştirakçılara gələcək fəaliyyətlərində uğurlar arzulayıb. Bağlanış mərasiminin sonunda iştirakçılara sertifikatlar təqdim edilib və xatirə fotosu çəkilib. Qeyd edək ki, ötən ilin sentyabr ayından başlamış proqramda Mərkəzi Bankın 119 nəfər rəhbər şəxsi iştirak edib. 9 moduldan ibarət bu proqramın əsas məqsədi iştirakçıların peşəkar potensiallarının gücləndirilməsinə və bacarıqlarının daha da təkmilləşdirilməsinə töhfə vermək olub. İştirakçılar peşəkar təlimçilər tərəfindən müasir dövrün trendlərinə uyğun mövzuların əhatə olunduğu proqram çərçivəsində interaktiv təlimlərə qatılıb.',
  images: [
    {
      id: 1,
      image: newsDetail1,
    },
    {
      id: 2,
      image: newsDetail2,
    },
    {
      id: 3,
      image: newsDetail3,
    },
    {
      id: 4,
      image: newsDetail4,
    },
    {
      id: 5,
      image: newsDetail5,
    },
    {
      id: 6,
      image: newsDetail6,
    },
    {
      id: 7,
      image: newsDetail7,
    },
  ],
};
export const announceInnerData = {
  id: 1,
  slug: 'dfwrf',
  date: '02.07.2025',
  title: 'Sığorta sahəsində keçiriləcək attestasiya ilə bağlı ELAN',
  desription:
    'Sığorta sahəsində attestasiyanın təşkili və keçirilməsi” Qaydasının 2.4-cü bəndinə əsasən siyahıda adları qeyd edilən şəxslər (siyahı əlavə olunur) 15 iyul 2025-ci il tarixində Azərbaycan Respublikasının Mərkəzi Bankında (Bakı şəhəri, Bülbül prospekti 27) keçiriləcək attestasiyaya dəvət olunurlar.',
};
export const interviewsData = [
  {
    id: 1,
    title: 'Azərbaycan Mərkəzi Bankının sədri Taleh Kazımov Toronto Mərkəzinin müsahibi olub',
    web_url: 'https://uploads.cbar.az/assets/465137ff7641e4c25d6868539.pdf',
    file_url: 'https://uploads.cbar.az/assets/465137ff7641e4c25d6868539.pdf',
    type: 'pdf',
  },
  {
    id: 2,
    title:
      'Mərkəzi Bankın sədri Taleh Kazımov dayanıqlı maliyyə təşəbbüsləri ilə bağlı fikirlərini bölüşüb',
    web_url: 'https://uploads.cbar.az/assets/1c809273c83f6f9affe8ce842.pdf',
    file_url: 'https://uploads.cbar.az/assets/1c809273c83f6f9affe8ce842.pdf',
    type: 'pdf',
  },
  {
    id: 3,
    title:
      'Azərbaycan Mərkəzi Bankının sədri Taleh Kazımovun “Global Finance” jurnalına müsahibəsi',
    web_url: 'https://uploads.cbar.az/assets/fbf289b6b765926804aedf299.pdf',
    file_url: 'https://uploads.cbar.az/assets/fbf289b6b765926804aedf299.pdf',
    type: 'pdf',
  },
  {
    id: 4,
    title: 'Mərkəzi Bankın sədri Elman Rüstəmovun “Zerkalo" qəzetinə müsahibəsi',
    web_url: 'https://uploads.cbar.az/assets/a98f30de5227f8e5291a4c600.pdf',
    file_url: 'https://uploads.cbar.az/assets/a98f30de5227f8e5291a4c600.pdf',
    type: 'pdf',
  },
  {
    id: 5,
    title:
      'Azərbaycan Mərkəzi Bankının sədri Elman Rüstəmovun Rusiyanın “Voprosı ekonomiki” adlı iqtisadi elmi-nəzəri jurnalında “Maliyyə böhranları: mənbələri, təzahürləri, nəticələri” başlıqlı məqaləsi',
    web_url: 'https://uploads.cbar.az/assets/751c64cf08ce6baf5ddc8c505.pdf',
    file_url: 'https://uploads.cbar.az/assets/751c64cf08ce6baf5ddc8c505.pdf',
    type: 'pdf',
  },
  {
    id: 6,
    title:
      'Azərbaycan Mərkəzi Bankının sədri Elman Rüstəmovun Rusiya Federasiyasının Mərkəzi Bankının “Деньги и Кредит” jurnalında “Makroiqtisadi siyasətin 2007-2009-cu illərin qlobal böhranının yaranmasına və nəticələrinin yumşaldılmasına təsiri” adlı məqaləsi',
    web_url: 'https://uploads.cbar.az/assets/19d867529c5f42a48190c3d75.pdf',
    file_url: 'https://uploads.cbar.az/assets/19d867529c5f42a48190c3d75.pdf',
    type: 'pdf',
  },
];
export const mediaEvents = {
  pastEvents: [
    {
      id: 1,
      title: 'COP29',
      content: [
        {
          id: 1,
          description:
            'Noyabr ayının 14-də Azərbaycan Respublikasının Mərkəzi Bankı COP29-da Maliyyə, İnvestisiya və Ticarət Günü çərçivəsində “Qlobal maliyyə sistemi: iqlim fəaliyyəti üçün maliyyələşmənin genişləndirilməsi” mövzusunda mühüm tədbir təşkil edib.',
          images: [
            {
              id: 1,
              image: eventItemInner1,
            },
          ],
        },
        {
          id: 2,
          description:
            'Noyabr ayının 14-də Azərbaycan Respublikasının Mərkəzi Bankı və Beynəlxalq Maliyyə Korporasiyası (BMK) “Dünya üzrə dayanıqlı maliyyənin inkişafı: Dayanıqlı maliyyə taksonomiyalarının qarşılıqlı əlaqəliliyi və müqayisəliliyi üzrə Yol Xəritəsi” adlı tədbir təşkil edib. Maliyyə, İnvestisiya və Ticarət Günündə keçirilən bu tədbir dünya miqyasında dayanıqlı maliyyə çərçivələrinin əlaqəliliyini artırmaqla yaşıl keçidin irəliləyişinə dair müzakirələr üçün effektiv platformaya çevrilib.',
          images: [
            {
              id: 1,
              image: eventItemInner2,
            },
          ],
        },
      ],
    },
    {
      id: 2,
      title: 'Heydər Əliyev - 100 il',
      content: [
        {
          id: 1,
          description:
            'Azәrbaycan Respublikasında 2023-cü ilin “Heydәr Әliyev İli” elan edilmәsi haqqında Azәrbaycan Respublikası Prezidentinin Sәrәncamı Ümummilli lider Heydər Əliyevin anadan olmasının 100-cü ildönümü münasibətilə Azərbaycan Respublikası Mərkəzi Bankı tərəfindən keçirilən silsilə tədbirlər çərçivəsində Mərkəzi Bankın Naxçıvan Muxtar Respublikası İdarəsinə press-tur təşkil edilmişdir https://www.cbar.az/press-release-4367/view',
          images: [
            {
              id: 1,
              image: eventItemInner3,
            },
            {
              id: 2,
              image: eventItemInner4,
            },
            {
              id: 3,
              image: eventItemInner5,
            },
            {
              id: 4,
              image: eventItemInner6,
            },
            {
              id: 5,
              image: eventItemInner7,
            },
          ],
        },
        {
          id: 2,
          description:
            'Mərkəzi Bankda Ümummilli Lider Heydər Əliyevin 100 illik yubileyinə həsr olunmuş tədbir keçirildi. https://www.cbar.az/press-release-4199/central-bank-holds-event-dedicated-to-100th-anniversary-of-national-leader-heydar-aliyev',
          images: [
            {
              id: 1,
              image: eventItemInner8,
            },
            {
              id: 2,
              image: eventItemInner9,
            },
            {
              id: 3,
              image: eventItemInner10,
            },
            {
              id: 4,
              image: eventItemInner11,
            },
            {
              id: 5,
              image: eventItemInner12,
            },
          ],
        },
      ],
    },
  ],
  futureEvents: [
    {
      id: 1,
      date: '05.07.2025',
      location: 'Bakı, Marriott Hotel',
      eventFormat: 'Seminar',
      name: 'Rəqəmsal İqtisadiyyatın İnkişafı',
    },
    {
      id: 2,
      date: '12.08.2025',
      location: 'Naxçıvan',
      eventFormat: 'Təlim',
      name: 'Mərkəzi Bankda Karyera Günləri',
    },
    {
      id: 3,
      date: '25.09.2025',
      location: 'Online (Zoom)',
      eventFormat: 'Vebinar',
      name: 'Rəqəmsal Maliyyə Sistemləri',
    },
    {
      id: 4,
      date: '10.10.2025',
      location: 'Bakı, Hilton',
      eventFormat: 'Forum',
      name: 'Gənclər üçün Maliyyə Savadlılığı',
    },
  ],
};
export const mediaRequest = {
  text: 'Mərkəzi Bankın kommunikasiyası onun missiyası, strateji və əməliyyat hədəfləri, fəaliyyət nəticələri haqqında bütün hədəf qruplarının məlumatlandırılması məqsədi ilə təşkil edilir. Operativ, əhatəli, aydın və dəqiq məlumatların ictimaiyyətə açıqlanması Mərkəzi Bankın həyata keçirdiyi siyasətin daha yaxşı qavranılmasına, bununla da iqtisadi-monetar gözləntilərin formalaşdırılmasına imkan verir. Mərkəzi Bank şəffaf kommunikasiya aparır. Bu çərçivədə medianın iştirakı ilə müntəzəm tədbirlər, konfranslar, brifinqlər və müxtəlif sessiyalar təşkil olunur. Mərkəzi Bank tərəfindən media sorğuları da aktiv surətdə cavablandılır. Media nümayəndələri sorğularını aşağıdakı elektron poçt ünvanı, yaxud telefon nömrəsi vasitəsilə Mərkəzi Banka ünvanlaya bilər:',
  mail: 'Press@cbar.az',
  phone: '(+994 12) 966 (572)',
};
export const photosData = [
  {
    id: 1,
    title: 'Azərbaycan Mərkəzi Bankının sədri İsveçrə Milli Bankının nümayəndə heyətini qəbul edib',
    date: '09.07.2025',
    slug: 'lorem-ipsum',
    images: [
      {
        id: 1,
        image: media1_1,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
      {
        id: 2,
        image: media1_2,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
      {
        id: 3,
        image: media1_3,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
    ],
  },
  {
    id: 2,
    title:
      'Türk Dövlətləri Təşkilatına üzv ölkələrin mərkəzi banklarının Şurasının birinci toplantısı keçirilib',
    date: '27.05.2025',
    slug: 'lorem-ipsum',
    images: [
      {
        id: 1,
        image: media2_1,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
      {
        id: 2,
        image: media2_2,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
      {
        id: 3,
        image: media2_3,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
    ],
  },
  {
    id: 3,
    title:
      'Azərbaycan Mərkəzi Bankı ilə Qazaxıstan Maliyyə Bazarının Tənzimlənməsi və İnkişafı Agentliyi arasında Anlaşma Memorandumu imzalanıb',
    date: '27.05.2025',
    slug: 'lorem-ipsum',
    images: [
      {
        id: 1,
        image: media3_1,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
      {
        id: 2,
        image: media3_2,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
      {
        id: 3,
        image: media3_3,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
    ],
  },
  {
    id: 4,
    title: 'Azərbaycan Mərkəzi Bankının sədri İsveçrə Milli Bankının nümayəndə heyətini qəbul edib',
    date: '09.07.2025',
    slug: 'lorem-ipsum',
    images: [
      {
        id: 1,
        image: media1_1,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
      {
        id: 2,
        image: media1_2,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
      {
        id: 3,
        image: media1_3,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
    ],
  },
  {
    id: 5,
    title:
      'Türk Dövlətləri Təşkilatına üzv ölkələrin mərkəzi banklarının Şurasının birinci toplantısı keçirilib',
    date: '27.05.2025',
    slug: 'lorem-ipsum',
    images: [
      {
        id: 1,
        image: media2_1,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
      {
        id: 2,
        image: media2_2,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
      {
        id: 3,
        image: media2_3,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
    ],
  },
  {
    id: 6,
    title:
      'Azərbaycan Mərkəzi Bankı ilə Qazaxıstan Maliyyə Bazarının Tənzimlənməsi və İnkişafı Agentliyi arasında Anlaşma Memorandumu imzalanıb',
    date: '27.05.2025',
    slug: 'lorem-ipsum',
    images: [
      {
        id: 1,
        image: media3_1,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
      {
        id: 2,
        image: media3_2,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
      {
        id: 3,
        image: media3_3,
        imageAlt: 'loremIpsum',
        imageTitle: 'loremIpsum',
      },
    ],
  },
];
export const videosData = [
  {
    id: 1,
    title: 'Faiz dəhlizinin parametrləri haqqında',
    date: '12.03.2025',
    coverImage: videoCover1,
    slug: 'lorem-ipsum',
    url: 'https://youtu.be/7mKSs0A3YoE',
  },
  {
    id: 2,
    title:
      'Mərkəzi Bankın sədri Taleh Kazımov Gürcüstan Milli Bankının nümayəndə heyətini qəbul edib',
    date: '06.03.2025',
    coverImage: videoCover2,
    slug: 'lorem-ipsum',
    url: 'https://youtu.be/I181T-RIbcI',
  },
  {
    id: 3,
    title: 'Faiz dəhlizinin parametrləri haqqında',
    date: '18.12.2024',
    coverImage: videoCover3,
    slug: 'lorem-ipsum',
    url: 'https://youtu.be/Qu4atbGdWDw',
  },
];
export const cbar105 = {
  text: 'Azərbaycan mərkəzi bankçılığın yaranmasının 105-ci ildönümüdür. 30 sentyabr 2024-cü il, Bakı: Bu gün Azərbaycanda mərkəzi bankçılığın yaranmasının 105 illik yubileyidir. Bu illər ərzində ölkədə mərkəzi bankçılıq uzun inkişaf yolu keçib. Tarixi inkişaf mərhələləri. Ölkənin maliyyə tarixində mühüm bir mərhələnin başlanğıcı Şərqin ilk demokratik respublikası olan Azərbaycan Xalq Cümhuriyyəti (AXC) ilə bağlıdır.',
};
export const cbar105Event = {
  text: 'Azərbaycanda mərkəzi bankçılığın yaranmasının 105 illik yubileyi münasibətilə Mərkəzi Bank tərəfindən tədbir keçirilib.Belə ki, Mərkəzi Bankın sədri Taleh Kazımovun rəhbərliyi ilə Bankın kollektivi Fəxri xiyabanda Ümummilli lider Heydər Əliyevin məzarını ziyarət edib. Ziyarət iştirakçıları tərəfindən Ulu öndərin məzarı üzərinə gül dəstələri qoyulub, xatirəsi hörmətlə yad edilib.',
  images: [
    {
      id: 1,
      image: cbar_105_1,
    },
    {
      id: 2,
      image: cbar_105_2,
    },
    {
      id: 3,
      image: cbar_105_3,
    },
    {
      id: 4,
      image: cbar_105_4,
    },
    {
      id: 5,
      image: cbar_105_5,
    },
  ],
};
export const presidentDecree = {
  text: 'Azərbaycan Respublikası Konstitusiyasının 109-cu maddəsinin 23-cü bəndini rəhbər tutaraq qərara alıram: Azərbaycanda mərkəzi bankçılığın yaranmasının 100 illiyi münasibətilə və bank işinin inkişaf etdirilməsindəki xidmətlərinə görə Azərbaycan Respublikası Mərkəzi Bankının aşağıdakı əməkdaşları təltif edilsinlər:',
};
export const developmentArticle = {
  text: '1918-ci il mayın 28-də Azərbaycan dövlətçilik salnaməsinin şanlı səhifələrindən biri kimi müsəlman Şərqində ilk demokratik respublikanın yaradılmasına Prezident İlham Əliyev tərəfindən yüksək siyasi qiymət verilib və 2018-ci il Cümhuriyyət ili elan edilib. Zəngin dövlət quruculuğu təcrübəsi ilə milli dövlətçilik tarixində silinməz izlər qoymuş, bugünkü müstəqillik üçün etibarlı zəmin hazırlamış Cümhuriyyətin yubileyi ölkə daxilində və xaricində çoxsaylı tədbirlərlə qeyd olunub. Mərkəzi bankçılığın 100 illik yubileyi də məhz həmin silsilə tədbirlərin davamıdır. AZƏRTAC Azərbaycanda mərkəzi bankçılığın bir əsrlik inkişaf yoluna və bu gününə nəzər salır.',
};
export const anniversaryStamp = {
  title:
    'Azərbaycanda mərkəzi bankçılığın 100 illik yubileyi ilə əlaqədar buraxılmış poçt markaları',
  image: stampImage,
};
export const anniversaryCoin = {
  title: 'Azərbaycanda mərkəzi bankçılığın 100 illiyinə həsr olunmuş yubiley pul nişanı',
  description:
    'Azərbaycan Respublikasının Mərkəzi Bankı tərəfindən Azərbaycanda mərkəzi bankçılığın 100 illik yubileyinə həsr olunmuş nominal dəyəri 5 AZN təşkil edən gümüş yubiley pul nişanı tədavülə buraxılmışdır.Qeyd olunan əlamətdar tarixi hadisəyə həsr olunmuş gümüş yubiley pul nişanının çəkisi 1 troy unsiyası – 31.1 qr. (± 0.1 qr.), diametri isə 38.61 mm. təşkil edir. Pul nişanı Böyük Britaniyanın “The Royal Mint” şirkətində beynəlxalq standartlara uyğun “Pruf” texnologiyası əsasında istehsal edilmişdir.Yubiley pul nişanının ön tərəfində iqtisadi inkişafı təcəssüm etdirən parabola xətlərinin fonunda Azərbaycan Mərkəzi Bankının inzibati binasının təsviri, ümummilli lider Heydər Əliyevin kəlamı və imzası, arxa tərəfində isə Azərbaycan Respublikasının dövlət gerbi, Azərbaycan manatının simvolu və eləcə də milli naxış və ornamentlər təsvir olunmuşdur.',
  image: anniversaryCoinImg,
};
export const trainingJournalists = {
  title:
    'Azərbaycanda mərkəzi bankçılığın 100 illik yubiley tədbirləri çərçivəsində media nümayəndələri üçün keçirilmiş təlim proqramı və press-tur',
  text: 'Azərbaycan Respublikasının Mərkəzi Bankının kommunikasiyasının başlıca hədəf qrupu kimi media institutları ilə peşəkar əməkdaşlığın gücləndirilməsi, jurnalistlərin iqtisadi-maliyyə, o cümlədən mərkəzi bankçılıq sahəsində biliklərinin artırılması məsələləri daim diqqət mərkəzində saxlanılır.Bu prosesin davamı olaraq Azərbaycanda mərkəzi bankçılığın 100 illik yubiley tədbirləri çərçivəsində cari ilin 2 - 20 sentyabr tarixlərində KİV nümayəndələri üçün “Mərkəzi bankçılıq” mövzusunda təlim proqramı keçirilmişdir. Təlim proqramında mərkəzi bankçılığının əsas fəaliyyat istiqamətləri, pul siyasəti, ödəniş sistemlərinin inkişafı, tədiyə balansı, nağd pulun dövriyyəsinin təşkili və idarə olunması, maliyyə texnologiyaları üzrə qabaqcıl trendlər, kriptovalyuta və blokçeyn həlləri, maliyyə savadlılığı, mərkəzi bankların kommunikasiya siyasəti və digər mövzular əhatə olunmuşdur. Təlim proqramının sonunda Mərkəzi Bankın Quba Regional Mərkəzinə press-tur təşkil edilmişdir. Əsas məqsədi media nümayəndələrini regional mərkəzin fəaliyyəti barədə əyani məlumatlandırmaqdan ibarət olan press-tur zamanı jurnalistlərə regionda sosial-iqtisadi inkişafın dinamik xarakter alması, burada bank-maliyyə institutlarının inkişafı, iqtisadi və maliyyə savadlılığının artırılması, regional mərkəzin həyata keçirdiyi funksiyalar barədə geniş məlumat verildi. Tədbir müddəti ərzində jurnalistləri maraqlandıran çoxsaylı suallar cavablandırıldı.',
  images: [
    {
      id: 1,
      image: training1,
    },
    {
      id: 2,
      image: training2,
    },
    {
      id: 3,
      image: training3,
    },
    {
      id: 4,
      image: training4,
    },
    {
      id: 5,
      image: training5,
    },
    {
      id: 6,
      image: training6,
    },
    {
      id: 7,
      image: training7,
    },
    {
      id: 8,
      image: training8,
    },
    {
      id: 9,
      image: training9,
    },
  ],
};
export const cbar100PhotoData = [
  {
    id: 1,
    image: cbar_100_1,
  },
  {
    id: 2,
    image: cbar_100_2,
  },
  {
    id: 3,
    image: cbar_100_3,
  },
  {
    id: 4,
    image: cbar_100_4,
  },
  {
    id: 5,
    image: cbar_100_5,
  },
  {
    id: 6,
    image: cbar_100_6,
  },
  {
    id: 7,
    image: cbar_100_7,
  },
  {
    id: 8,
    image: cbar_100_8,
  },
];
export const cbar100Video = [
  {
    id: 1,
    title:
      'Azərbaycanda mərkəzi bankçılığın yaranmasının 100 illiyinə həsr olunmuş yubiley tədbiri haqda video çarx',
    videoUrl:
      '<iframe width="560" height="315" src="https://www.youtube.com/embed/SQVWwDLq4P0?si=q4mXePDXBsHSBsWw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>',
  },
  {
    id: 2,
    title:
      ' Azərbaycanda mərkəzi bankçılığın yaranmasının 100 illiyinə həsr olunmuş yubiley tədbirində Mərkəzi Bankın sədri cənab E.Rüstəmovun çıxışı',
    videoUrl:
      '<iframe width="560" height="315" src="https://www.youtube.com/embed/13FYpeAg4uc?si=x84hn4pEBL9bo--U" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>',
  },
  {
    id: 3,
    title:
      ' Azərbaycanda mərkəzi bankçılığın yaranmasının 100 illiyinə həsr olunmuş yubiley tədbirində iştirak edən qonaqların çıxışları',
    videoUrl:
      '<iframe width="560" height="315" src="https://www.youtube.com/embed/zqzK8DxAUVg?si=ycfF2QbOQEAD_pgT" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>',
  },
];
