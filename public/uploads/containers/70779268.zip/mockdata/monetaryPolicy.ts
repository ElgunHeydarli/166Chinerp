import { poster } from './images';

export const monetaryPolicyText = {
  text: 'Mərkəzi Bankın bu istiqamətdə fəaliyyəti “Azərbaycan Respublikasının Mərkəzi Bankı haqqında” Qanunla tənzimlənir. Pul siyasəti Mərkəzi Bankın əsas məqsədi olan qiymətlərin sabitliyini təmin etmək məqsədilə həyata keçirilən tədbirlər sistemidir.Pul siyasətinin hədəfinə çatmaq məqsədilə Mərkəzi Bank pul siyasəti alətlərindən istifadə edir. Sərəncamında olan pul siyasəti alətləri vasitəsilə pul kütləsi, valyuta məzənnəsi və faiz dərəcələrinə təsir göstərməklə Mərkəzi Bank özünün son məqsədinə nail olmağa çalışır. Pul siyasətinə dair adekvat qərarlar qəbul etmək üçün Mərkəzi Bank daim ölkədəki makroiqtisadi vəziyyəti təhlil edir və proqnozlaşdırır. Makroiqtisadi vəziyyət müntəzəm olaraq Mərkəzi Bankın kollegial idarəetmə orqanları olan Pul Siyasəti və Maliyyə Sabitliyi Komitəsində və İdarə Heyətində müzakirə edilir, bu müzakirələr əsasında pul siyasətinə dair qərarlar qəbul olunur. Qərarlar Mərkəzi Bankın kommunikasiya vasitələri, o cümlədən press-relizlər vasitəsilə ictimaiyyətə açıqlanır.Mərkəzi Bank qarşıdakı il (həmçinin ortamüddətli dövr) üçün pul siyasətinin əsas istiqamətləri barədə bəyanatı hazırlayır və ictimaiyyətə açıqlayır. Sənəddə cari ildə makroiqtisadi siyasət çərçivəsi, həyata keçirilən pul siyasətinin yekunları, qarşıdakı il üçün müəyyən edilən pul siyasətinin məqsəd və vəzifələri, onların həyata keçirilməsi yolları, eləcə də ortamüddətli dövrə siyasət istiqamətləri göstərilir.Mərkəzi Bank il ərzində makroiqtisadi vəziyyəti və həyata keçirilən pul siyasəti barədə məlumatları geniş oxucu kütləsinə çatdırmaq məqsədilə rüblük əsasda Pul Siyasəti İcmalını hazırlayaraq ictimaiyyətə açıqlayır.',
};
export const monetaryPolicyDirections = {
  title: 'Azərbaycan Respublikasının Mərkəzi Bankının pul siyasətinin əsas istiqamətləri barədə',
  directions: [
    {
      id: 1,
      title: '2025',
      files: [
        {
          id: 1,
          title:
            'Azərbaycan Respublikası Mərkəzi Bankının 2025-ci il üçün pul siyasətinin əsas istiqamətləri barədə BƏYANATI',
          web_url: 'https://uploads.cbar.az/assets/6ae7605fde03d511903a80390.pdf',
          file_url: 'https://uploads.cbar.az/assets/6ae7605fde03d511903a80390.pdf',
          type: 'pdf',
        },
      ],
    },
    {
      id: 2,
      title: '2024',
      files: [
        {
          id: 1,
          title:
            'Azərbaycan Respublikası Mərkəzi Bankının 2024-ci il üçün pul siyasətinin əsas istiqamətləri barədə BƏYANATI',
          web_url: 'https://uploads.cbar.az/assets/f99c0a21f2500479d8abf343a.pdf',
          file_url: 'https://uploads.cbar.az/assets/f99c0a21f2500479d8abf343a.pdf',
          type: 'pdf',
        },
      ],
    },
    {
      id: 3,
      title: '2023',
      files: [
        {
          id: 1,
          title:
            'Azərbaycan Respublikası Mərkəzi Bankının 2023-ci il üçün pul siyasətinin əsas istiqamətləri barədə BƏYANATI',
          web_url: 'https://uploads.cbar.az/assets/b8dc13d161f6120a58a2b10c1.pdf',
          file_url: 'https://uploads.cbar.az/assets/b8dc13d161f6120a58a2b10c1.pdf',
          type: 'pdf',
        },
      ],
    },
    {
      id: 4,
      title: '2022',
      files: [
        {
          id: 1,
          title:
            'Azərbaycan Respublikası Mərkəzi Bankının 2022-ci il üçün pul və maliyyə sabitliyi siyasətinin əsas istiqamətləri barədə BƏYANATI',
          web_url: 'https://uploads.cbar.az/assets/ff08dc2a6d47f5636f74ad50b.pdf',
          file_url: 'https://uploads.cbar.az/assets/ff08dc2a6d47f5636f74ad50b.pdf',
          type: 'pdf',
        },
      ],
    },
  ],
};
export const monetaryPolicyReview = {
  reviews: [
    {
      id: 1,
      title: '2025',
      files: [
        {
          id: 1,
          title: 'Avqust',
          year: 2025,
          coverTitle: 'Pul siyasəti icmalı',
          web_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          file_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title: 'May',
          year: 2025,
          coverTitle: 'Pul siyasəti icmalı',
          web_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          file_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          type: 'pdf',
        },
        {
          id: 3,
          title: 'Fevral',
          year: 2025,
          coverTitle: 'Pul siyasəti icmalı',
          web_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          file_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          type: 'pdf',
        },
      ],
    },
    {
      id: 2,
      title: '2024',
      files: [
        {
          id: 1,
          title: 'Pul Siyasəti İcmalı – Noyabr 2024',
          year: 2024,
          coverTitle: 'Pul siyasəti icmalı',
          web_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          file_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title: '2024-cü ilin yanvar-iyun ayları üzrə Pul Siyasəti icmalı',
          year: 2024,
          coverTitle: 'Pul siyasəti icmalı',
          web_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          file_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          type: 'pdf',
        },
        {
          id: 3,
          title: '2024-cü ilin yanvar-mart ayları üzrə Pul Siyasəti icmalı',
          year: 2024,
          coverTitle: 'Pul siyasəti icmalı',
          web_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          file_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          type: 'pdf',
        },
      ],
    },
    {
      id: 3,
      title: '2023',
      files: [
        {
          id: 1,
          title: '2023-cü ilin yanvar-dekabr ayları üzrə Pul Siyasəti icmalı',
          year: 2023,
          coverTitle: 'Pul siyasəti icmalı',
          web_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          file_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          type: 'pdf',
        },
        {
          id: 2,
          title: '2023-cü ilin yanvar-sentyabr ayları üzrə Pul Siyasəti icmalı',
          year: 2023,
          coverTitle: 'Pul siyasəti icmalı',
          web_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          file_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          type: 'pdf',
        },
        {
          id: 3,
          title: '2023-cü ilin yanvar-iyun ayları üzrə Pul Siyasəti icmalı',
          year: 2023,
          coverTitle: 'Pul siyasəti icmalı',
          web_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          file_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          type: 'pdf',
        },
        {
          id: 4,
          title: '2023-cü ilin yanvar-mart ayları üzrə Pul Siyasəti icmalı',
          year: 2023,
          coverTitle: 'Pul siyasəti icmalı',
          web_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          file_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
          type: 'pdf',
        },
      ],
    },
  ],
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/HrIh0su_-rQ?si=uarNpSgY3MxtLo3Z" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
};
export const monetaryPolicyDecisions = {
  desicion: [
    {
      id: 1,
      year: '2025',
      desicions: [
        {
          id: 1,
          slug: 'aaa',
          title: 'Uçot dərəcəsi və faiz dəhlizinin digər parametrləri 0.25% azaldıldı',
          description:
            '2025-ci ildə Pul siyasətinin hesabatlılığı şöbəsi təcrübəçi qəbul edəcək. Sözügedən şöbə pul siyasəti qərarlarının əsaslandırılması və qarşıya qoyulan hədəflərə nail olunması vəziyyəti ilə bağlı ictimaiyyətin məlumatlandırılmasını təmin edir, qanunvericiliyə uyğun olaraq müvafiq dövlət orqanlarına hesabatların ümumiləşdirilməsini təmin edir, müxtəlif dövlət proqramları və dövlət əhəmiyyətli strateji sənədlərdə pul siyasətinin yerinə yetirilməsi ilə bağlı hesabatlar hazırlayır. ',
        },
        {
          id: 2,
          slug: 'aaa',
          title: 'Faiz dəhlizinin parametrləri haqqında',
          description:
            'Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.',
        },
        {
          id: 3,
          slug: 'aaa',
          title: 'Uçot dərəcəsi və faiz dəhlizinin digər parametrləri 0.25% azaldıldı',
          description:
            '2025-ci ildə Pul siyasətinin hesabatlılığı şöbəsi təcrübəçi qəbul edəcək. Sözügedən şöbə pul siyasəti qərarlarının əsaslandırılması və qarşıya qoyulan hədəflərə nail olunması vəziyyəti ilə bağlı ictimaiyyətin məlumatlandırılmasını təmin edir, qanunvericiliyə uyğun olaraq müvafiq dövlət orqanlarına hesabatların ümumiləşdirilməsini təmin edir, müxtəlif dövlət proqramları və dövlət əhəmiyyətli strateji sənədlərdə pul siyasətinin yerinə yetirilməsi ilə bağlı hesabatlar hazırlayır. ',
        },
        {
          id: 4,
          slug: 'aaa',
          title: 'Faiz dəhlizinin parametrləri haqqında',
          description:
            'Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.',
        },
      ],
    },
    {
      id: 2,
      year: '2024',
      desicions: [
        {
          id: 1,
          slug: 'aaa',
          title: 'Uçot dərəcəsi və faiz dəhlizinin digər parametrləri 0.25% azaldıldı',
          description:
            '2025-ci ildə Pul siyasətinin hesabatlılığı şöbəsi təcrübəçi qəbul edəcək. Sözügedən şöbə pul siyasəti qərarlarının əsaslandırılması və qarşıya qoyulan hədəflərə nail olunması vəziyyəti ilə bağlı ictimaiyyətin məlumatlandırılmasını təmin edir, qanunvericiliyə uyğun olaraq müvafiq dövlət orqanlarına hesabatların ümumiləşdirilməsini təmin edir, müxtəlif dövlət proqramları və dövlət əhəmiyyətli strateji sənədlərdə pul siyasətinin yerinə yetirilməsi ilə bağlı hesabatlar hazırlayır. ',
        },
        {
          id: 2,
          slug: 'aaa',
          title: 'Faiz dəhlizinin parametrləri haqqında',
          description:
            'Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.',
        },
        {
          id: 3,
          slug: 'aaa',
          title: 'Uçot dərəcəsi və faiz dəhlizinin digər parametrləri 0.25% azaldıldı',
          description:
            '2025-ci ildə Pul siyasətinin hesabatlılığı şöbəsi təcrübəçi qəbul edəcək. Sözügedən şöbə pul siyasəti qərarlarının əsaslandırılması və qarşıya qoyulan hədəflərə nail olunması vəziyyəti ilə bağlı ictimaiyyətin məlumatlandırılmasını təmin edir, qanunvericiliyə uyğun olaraq müvafiq dövlət orqanlarına hesabatların ümumiləşdirilməsini təmin edir, müxtəlif dövlət proqramları və dövlət əhəmiyyətli strateji sənədlərdə pul siyasətinin yerinə yetirilməsi ilə bağlı hesabatlar hazırlayır. ',
        },
        {
          id: 4,
          slug: 'aaa',
          title: 'Faiz dəhlizinin parametrləri haqqında',
          description:
            'Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.',
        },
      ],
    },
    {
      id: 3,
      year: '2023',
      desicions: [
        {
          id: 1,
          slug: 'aaa',
          title: 'Uçot dərəcəsi və faiz dəhlizinin digər parametrləri 0.25% azaldıldı',
          description:
            '2025-ci ildə Pul siyasətinin hesabatlılığı şöbəsi təcrübəçi qəbul edəcək. Sözügedən şöbə pul siyasəti qərarlarının əsaslandırılması və qarşıya qoyulan hədəflərə nail olunması vəziyyəti ilə bağlı ictimaiyyətin məlumatlandırılmasını təmin edir, qanunvericiliyə uyğun olaraq müvafiq dövlət orqanlarına hesabatların ümumiləşdirilməsini təmin edir, müxtəlif dövlət proqramları və dövlət əhəmiyyətli strateji sənədlərdə pul siyasətinin yerinə yetirilməsi ilə bağlı hesabatlar hazırlayır. ',
        },
        {
          id: 2,
          slug: 'aaa',
          title: 'Faiz dəhlizinin parametrləri haqqında',
          description:
            'Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.',
        },
        {
          id: 3,
          slug: 'aaa',
          title: 'Uçot dərəcəsi və faiz dəhlizinin digər parametrləri 0.25% azaldıldı',
          description:
            '2025-ci ildə Pul siyasətinin hesabatlılığı şöbəsi təcrübəçi qəbul edəcək. Sözügedən şöbə pul siyasəti qərarlarının əsaslandırılması və qarşıya qoyulan hədəflərə nail olunması vəziyyəti ilə bağlı ictimaiyyətin məlumatlandırılmasını təmin edir, qanunvericiliyə uyğun olaraq müvafiq dövlət orqanlarına hesabatların ümumiləşdirilməsini təmin edir, müxtəlif dövlət proqramları və dövlət əhəmiyyətli strateji sənədlərdə pul siyasətinin yerinə yetirilməsi ilə bağlı hesabatlar hazırlayır. ',
        },
        {
          id: 4,
          slug: 'aaa',
          title: 'Faiz dəhlizinin parametrləri haqqında',
          description:
            'Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.',
        },
      ],
    },
    {
      id: 4,
      year: '2022',
      desicions: [
        {
          id: 1,
          slug: 'aaa',
          title: 'Uçot dərəcəsi və faiz dəhlizinin digər parametrləri 0.25% azaldıldı',
          description:
            '2025-ci ildə Pul siyasətinin hesabatlılığı şöbəsi təcrübəçi qəbul edəcək. Sözügedən şöbə pul siyasəti qərarlarının əsaslandırılması və qarşıya qoyulan hədəflərə nail olunması vəziyyəti ilə bağlı ictimaiyyətin məlumatlandırılmasını təmin edir, qanunvericiliyə uyğun olaraq müvafiq dövlət orqanlarına hesabatların ümumiləşdirilməsini təmin edir, müxtəlif dövlət proqramları və dövlət əhəmiyyətli strateji sənədlərdə pul siyasətinin yerinə yetirilməsi ilə bağlı hesabatlar hazırlayır. ',
        },
        {
          id: 2,
          slug: 'aaa',
          title: 'Faiz dəhlizinin parametrləri haqqında',
          description:
            'Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.',
        },
        {
          id: 3,
          slug: 'aaa',
          title: 'Uçot dərəcəsi və faiz dəhlizinin digər parametrləri 0.25% azaldıldı',
          description:
            '2025-ci ildə Pul siyasətinin hesabatlılığı şöbəsi təcrübəçi qəbul edəcək. Sözügedən şöbə pul siyasəti qərarlarının əsaslandırılması və qarşıya qoyulan hədəflərə nail olunması vəziyyəti ilə bağlı ictimaiyyətin məlumatlandırılmasını təmin edir, qanunvericiliyə uyğun olaraq müvafiq dövlət orqanlarına hesabatların ümumiləşdirilməsini təmin edir, müxtəlif dövlət proqramları və dövlət əhəmiyyətli strateji sənədlərdə pul siyasətinin yerinə yetirilməsi ilə bağlı hesabatlar hazırlayır. ',
        },
        {
          id: 4,
          slug: 'aaa',
          title: 'Faiz dəhlizinin parametrləri haqqında',
          description:
            'Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.',
        },
      ],
    },
    {
      id: 5,
      year: '2021',
      desicions: [
        {
          id: 1,
          slug: 'aaa',
          title: 'Uçot dərəcəsi və faiz dəhlizinin digər parametrləri 0.25% azaldıldı',
          description:
            '2025-ci ildə Pul siyasətinin hesabatlılığı şöbəsi təcrübəçi qəbul edəcək. Sözügedən şöbə pul siyasəti qərarlarının əsaslandırılması və qarşıya qoyulan hədəflərə nail olunması vəziyyəti ilə bağlı ictimaiyyətin məlumatlandırılmasını təmin edir, qanunvericiliyə uyğun olaraq müvafiq dövlət orqanlarına hesabatların ümumiləşdirilməsini təmin edir, müxtəlif dövlət proqramları və dövlət əhəmiyyətli strateji sənədlərdə pul siyasətinin yerinə yetirilməsi ilə bağlı hesabatlar hazırlayır. ',
        },
        {
          id: 2,
          slug: 'aaa',
          title: 'Faiz dəhlizinin parametrləri haqqında',
          description:
            'Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.',
        },
        {
          id: 3,
          slug: 'aaa',
          title: 'Uçot dərəcəsi və faiz dəhlizinin digər parametrləri 0.25% azaldıldı',
          description:
            '2025-ci ildə Pul siyasətinin hesabatlılığı şöbəsi təcrübəçi qəbul edəcək. Sözügedən şöbə pul siyasəti qərarlarının əsaslandırılması və qarşıya qoyulan hədəflərə nail olunması vəziyyəti ilə bağlı ictimaiyyətin məlumatlandırılmasını təmin edir, qanunvericiliyə uyğun olaraq müvafiq dövlət orqanlarına hesabatların ümumiləşdirilməsini təmin edir, müxtəlif dövlət proqramları və dövlət əhəmiyyətli strateji sənədlərdə pul siyasətinin yerinə yetirilməsi ilə bağlı hesabatlar hazırlayır. ',
        },
        {
          id: 4,
          slug: 'aaa',
          title: 'Faiz dəhlizinin parametrləri haqqında',
          description:
            'Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.',
        },
      ],
    },
  ],
  desicionTable: {
    title:
      '2025-ci il ərzində Mərkəzi Bankın İdarə Heyətinin pul siyasəti qərarlarının ictimaiyyətə açıqlanması qrafiki',
    table: 'Table olacaq, editordan gelecek',
  },
  posters: [
    {
      id: 1,
      image: poster,
    },
    {
      id: 2,
      image: poster,
    },
    {
      id: 3,
      image: poster,
    },
    {
      id: 4,
      image: poster,
    },
    {
      id: 5,
      image: poster,
    },
    {
      id: 6,
      image: poster,
    },
    {
      id: 7,
      image: poster,
    },
    {
      id: 8,
      image: poster,
    },
  ],
};

export const forecastingPolicyAnalysis = {
  text: '1. Ümumi müddəalar Bu Metodoloji rəhbərlik Azərbaycan Respublikasının Mərkəzi Bankında (bundan sonra - AMB) Pul siyasəti və maliyyə sabitliyi komitəsinin iclasları üçün analitik materialların hazırlanması məqsədilə istifadə olunan Proqnozlaşdırma və siyasət təhlili sisteminin mahiyyətini, mərhələlərini və idarəetmə çərçivəsini müəyyən edir. 2. Anlayışlar və akronimlər 2.1. Bu Metodoloji rəhbərlikdə istifadə olunan anlayışlar və akronimlər aşağıdakı mənaları ifadə edir: 2.1.1. PSTS – Proqnozlaşdırma və siyasət təhlili sistemi;  2.1.2. PSTS qrupu – Proqnozlaşdırma və siyasət təhlili sistemi çərçivəsində Analitik blokun əməkdaşlarından təşkil olunan qrup; 2.1.3. PSMSK – Pul siyasəti və maliyyə sabitliyi komitəsi; 2.1.4. PSMSK-nin üzvləri – AMB-nin İdarə Heyəti və müvafiq rəhbər şəxslərindən təşkil olunmuş kollegial orqan; 2.1.5. Analitik blok – Pul siyasəti, Statistika və Tədqiqatlar departamentləri; 2.1.6. Qeyri-struktur modellər – dəyişənlər arasında qarşılıqlı əlaqəyə dair heç bir məhdudiyyətin tətbiq olunmadığı ekonometrik modellər; 2.1.7. DSÜT – dinamik stoxastik ümumi tarazlıq modeli; 2.1.8. RPM – rüblük proqnozlaşdırma modeli; 2.1.9. Pul siyasəti qərarı – faiz dəhlizinin parametrlərinə və pul siyasətinin aralıq və əməliyyat hədəflərinə dair qərarların məcmusu. 3. Proqnozlaşdırma və siyasət təhlili sisteminin məqsədi və mahiyyəti. 3.1.Qabaqcıl mərkəzi bankların təcrübəsində olduğu kimi AMB-də də PSTSnin qurulmasında əsas məqsəd PSMSK tərəfindən pul və məzənnə siyasətinə dair qərarların qəbul olunması üçün analitik dəstək göstərməkdir.3.2.PSTS-nin tətbiqi qlobal mühitdə, tərəfdaş ölkələrdə gedən iqtisadi proseslərin və Azərbaycanda cari makroiqtisadi vəziyyətin təhlilinə, onu xarakterizə edən əsas göstəriciləri (inflyasiya, məcmu buraxılış kəsiri, iqtisadi artım, məcmu tələbin komponentləri, cari əməliyyatlar balansı və s.) mümkün inkişaf ssenariləri üzrə proqnozlaşdırmağa imkan verir. 3.3.PSTS çərçivəsində biznes proseslər 5 mərhələdən ibarət olmaqla PSMSK-nin iclasından 5 həftə əvvəl başlayır. İlk 3 mərhələ 4 həftəlik müddəti əhatə edir. Bu zaman təhlil nəticələri və ssenarilər üzrə proqnozlar hazırlanaraq təqdimat formatında PSMSK-nin üzvlərinə təqdim edilir. PSTS-nin son 2 mərhələsi 5-ci həftəyə təsadüf edir. Bu mərhələlərdə PSMSK iclasının keçirilməsi, qərarların qəbul edilməsi və ictimaiyyətə açıqlanması təmin edilir. 3.4. PSTS çərçivəsində mərhələlər və həftəlik iş bölgüsü üzrə biznes proseslərin fasiləsiz və vaxtında həyata keçirilməsi ciddi əhəmiyyət daşıyır və müəyyən olunmuş qrafikdən kənarlaşma PSTS-nin mahiyyət və məqsədilə ziddiyyət təşkil edir.',
  files: [
    {
      id: 1,
      title: 'Proqnozlaşdırma və siyasət təhlili sisteminə dair Metodoloji rəhbərlik',
      web_url: 'https://uploads.cbar.az/assets/0ef42f8219cb163486e4ced48.pdf',
      file_url: 'https://uploads.cbar.az/assets/0ef42f8219cb163486e4ced48.pdf',
      type: 'pdf',
    },
  ],
};

export const monetaryPolicyInstruments = [
  {
    id: 1,
    title: 'Pul siyasətinin əməliyyat çərçivəsinə dair izahedici sənəd',
    web_url: 'https://uploads.cbar.az/assets/35e695d5920d51a7d587865de.pdf',
    file_url: 'https://uploads.cbar.az/assets/35e695d5920d51a7d587865de.pdf',
    type: 'pdf',
  },
  {
    id: 2,
    title: 'Azərbaycan Respublikası Mərkəzi Bankının notlarının buraxılış şərtləri',
    web_url: 'https://uploads.cbar.az/assets/72d249aff9f10cce554a8611e.pdf',
    file_url: 'https://uploads.cbar.az/assets/72d249aff9f10cce554a8611e.pdf',
    type: 'pdf',
  },
  {
    id: 3,
    title: 'AZIR - Banklararası Təmi̇natsız Pul Bazarında İsti̇nad Fai̇z Dərəcəsi',
    web_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
    file_url: 'https://uploads.cbar.az/assets/8a21e25f763fee542d9714e3c.pdf',
    type: 'pdf',
  },
];
