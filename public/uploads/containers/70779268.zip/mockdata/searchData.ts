export const searchData = [
  {
    id: 1,
    title: 'Mərkəzi Bankın nümayəndə heyəti ABŞ-də işgüzar səfərdədir',
    description:
      '24 aprel 2025-cü il, Bakı: Səfər zamanı nümayəndə heyəti Vaşinqton şəhərində keçiriləcək Dünya Bankı və Beynəlxalq Valyuta Fondunun Yaz Toplantıları çərçivəsində müxtəlif tədbirlərdə və Mərkəzi Bank ilə əməkdaşlıq edən bir sıra maliyyə-investisiya institutlarının rəhbərliyi ilə',
    url: '',
  },
  {
    id: 2,
    title: 'Faiz dəhlizinin parametrləri haqqında',
    description:
      '23 aprel 2025-ci il: Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.   Faiz dəhlizi ilə bağlı qərar faktiki və proqnozlaşdırılan inflyasiyanın hədəflə (4±2%) müqayisəsi, qlobal iqtisadiyyatda və maliyyə bazarlarındakı vəziyyət, ölkədaxili makroiqtisadi',
    url: '',
  },
  {
    id: 3,
    title: 'Faiz dəhlizinin parametrləri haqqında',
    description:
      '12 mart 2025-ci il: Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.   Uçot dərəcəsinin dəyişməz saxlanılması ilə bağlı qərar faktiki və proqnozlaşdırılan inflyasiyanın hədəf daxilində (4±2%) olması, qlobal iqtisadi şərait, makroiqtisadi meyillərin',
    url: '',
  },
  {
    id: 4,
    title: 'Valyuta hərracı barədə',
    description:
      '25 fevral 2025-ci il tarixində Mərkəzi Bankda növbəti valyuta hərracı keçirilib. Hərracda tələb 52,4 mln. ABŞ dolları təşkil edib və tam təmin olunub. Hərracın ortaçəkili məzənnəsi 1,7000 manat təşkil edib.',
    url: '',
  },
  {
    id: 5,
    title: 'Mərkəzi Bankın nümayəndə heyəti ABŞ-də işgüzar səfərdədir',
    description:
      '24 aprel 2025-cü il, Bakı: Səfər zamanı nümayəndə heyəti Vaşinqton şəhərində keçiriləcək Dünya Bankı və Beynəlxalq Valyuta Fondunun Yaz Toplantıları çərçivəsində müxtəlif tədbirlərdə və Mərkəzi Bank ilə əməkdaşlıq edən bir sıra maliyyə-investisiya institutlarının rəhbərliyi ilə',
    url: '',
  },
  {
    id: 6,
    title: 'Faiz dəhlizinin parametrləri haqqında',
    description:
      '23 aprel 2025-ci il: Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.   Faiz dəhlizi ilə bağlı qərar faktiki və proqnozlaşdırılan inflyasiyanın hədəflə (4±2%) müqayisəsi, qlobal iqtisadiyyatda və maliyyə bazarlarındakı vəziyyət, ölkədaxili makroiqtisadi',
    url: '',
  },
  {
    id: 7,
    title: 'Faiz dəhlizinin parametrləri haqqında',
    description:
      '12 mart 2025-ci il: Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.   Uçot dərəcəsinin dəyişməz saxlanılması ilə bağlı qərar faktiki və proqnozlaşdırılan inflyasiyanın hədəf daxilində (4±2%) olması, qlobal iqtisadi şərait, makroiqtisadi meyillərin',
    url: '',
  },
  {
    id: 8,
    title: 'Valyuta hərracı barədə',
    description:
      '25 fevral 2025-ci il tarixində Mərkəzi Bankda növbəti valyuta hərracı keçirilib. Hərracda tələb 52,4 mln. ABŞ dolları təşkil edib və tam təmin olunub. Hərracın ortaçəkili məzənnəsi 1,7000 manat təşkil edib.',
    url: '',
  },
  {
    id: 9,
    title: 'Mərkəzi Bankın nümayəndə heyəti ABŞ-də işgüzar səfərdədir',
    description:
      '24 aprel 2025-cü il, Bakı: Səfər zamanı nümayəndə heyəti Vaşinqton şəhərində keçiriləcək Dünya Bankı və Beynəlxalq Valyuta Fondunun Yaz Toplantıları çərçivəsində müxtəlif tədbirlərdə və Mərkəzi Bank ilə əməkdaşlıq edən bir sıra maliyyə-investisiya institutlarının rəhbərliyi ilə',
    url: '',
  },
  {
    id: 10,
    title: 'Faiz dəhlizinin parametrləri haqqında',
    description:
      '23 aprel 2025-ci il: Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.   Faiz dəhlizi ilə bağlı qərar faktiki və proqnozlaşdırılan inflyasiyanın hədəflə (4±2%) müqayisəsi, qlobal iqtisadiyyatda və maliyyə bazarlarındakı vəziyyət, ölkədaxili makroiqtisadi',
    url: '',
  },
  {
    id: 11,
    title: 'Faiz dəhlizinin parametrləri haqqında',
    description:
      '12 mart 2025-ci il: Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyətinin qərarı ilə uçot dərəcəsi 7.25%, faiz dəhlizinin aşağı həddi 6.25%, faiz dəhlizinin yuxarı həddi isə 8.25% səviyyəsində dəyişməz saxlanılıb.   Uçot dərəcəsinin dəyişməz saxlanılması ilə bağlı qərar faktiki və proqnozlaşdırılan inflyasiyanın hədəf daxilində (4±2%) olması, qlobal iqtisadi şərait, makroiqtisadi meyillərin',
    url: '',
  },
  {
    id: 12,
    title: 'Valyuta hərracı barədə',
    description:
      '25 fevral 2025-ci il tarixində Mərkəzi Bankda növbəti valyuta hərracı keçirilib. Hərracda tələb 52,4 mln. ABŞ dolları təşkil edib və tam təmin olunub. Hərracın ortaçəkili məzənnəsi 1,7000 manat təşkil edib.',
    url: '',
  },
];
