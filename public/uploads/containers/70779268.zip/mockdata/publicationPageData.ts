export const publicationContentData = {
  text: 'Azərbaycan Respublikasının Mərkəzi Bankında aparılan tədqiqat işlərinin əsas məqsədi ölkədə effektiv makroiqtisadi, o cümlədən pul və məzənnə siyasətinin analitik-empirik tədqiqat bazasını formalaşdırmaq, sosial-iqtisadi inkişafı dəstəkləyən makroiqtisadi sabitliyin fundamentallarının aşkarlanmasına töhfə verməkdir. Tədqiqat işləri dövri xarakter daşıyır və mütəmadi olaraq elektron formatda ictimaiyyətə təqdim olunur.Tədqiqatların nəticələri ilə “İşçi məqalələr silsiləsi”, qurulmuş modellər və indekslərlə “Ekonometrik modellər” bölməsində, tədqiqat yönümlü əlavə materiallarla “Digər nəşrlər” bölməsində tanış olmaq mümkündür.',
};
export const econometicModels = {
  text: 'Ekonometrik və riyazi modellər əsas makroiqtisadi göstəricilərin qısa və orta müddətli dövr üçün proqnozlaşdırılmasında istifadə olunur. Mərkəzi Bankda istifadə olunan modellər daim təkmilləşdirilir və yeni modellər qurulur.',
  files: [
    {
      id: 1,
      title: 'Mərkəzi Bankda istifadə olunan modellər',
      web_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
      file_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
      type: 'pdf',
    },
  ],
};
export const articleDetail = {
  text: 'Tədqiqatın adı: Azərbaycanın Rüblük Proqnozlaşdırma Modeli (AzİM 1.0) Nömrə: 01/2024 Müəllif(lər): Tural Yusifzadə, Nəzrin Ramazanova, Ramiz Rəhmanov, Vüqar Əhmədov Dil: İngilis dili Tarix: 2024 Xülasə: Bu məqalədə ədəbiyyatlarda açıq iqtisadiyyat kəsir modeli adlanan və Azərbaycan iqtisadiyyatı timsalında qurulan rüblük proqnozlaşdırma modelinin (AzİM 1.0) ilkin versiyası təqdim olunur. Model proqnozlaşdırma, simulyasiya və pul siyasətinin təhlili məqsədləri üçün nəzərdə tutulmuşdur. Bu model beş əsas blokdan ibarətdir: (i) qeyri-neft buraxılış kəsirini əhatə edən ümumi tələb bloku; (ii) inflyasiya və inflyasiya gözləntilərini modelləşdirən Fillips əyrisi (inflyasiyanın proqnozlaşdırılması) bloku; (iii) nominal lövbər rolunu oynayan riskə uyğunlaşdırılmış açıq faiz dərəcəsi pariteti bloku; (iv) pul siyasətinə reaksiya funksiyasını müəyyən edən Teylor qaydası (qısamüddətli faiz dərəcəsi) bloku; (v) xarici sektor bloku. AzİM 1.0 qismən-struktur yeni keynes nəzəri çərçivəsinə əsaslanan modeldir və Azərbaycan iqtisadiyyatının xüsusiyyətlərini, xüsusilə də transmissiya mexanizmi və pul siyasətinin formalaşma prosesini nəzərə almaqla qurulmuşdur. Modelin kalibrasiyası Azərbaycan üzrə aparılmış empirik qiymətləndirmələrə, beynəlxalq ədəbiyyata, oxşar ölkə təcrübələrinə və tarixi məlumatlara əsaslanır. Modelin dayanıqlığını və tətbiqə yararlılığını qiymətləndirmək məqsədilə impuls-cavab analizləri, tənliklərin dekompozisiyası və nümunədaxili simulyasiyalar həyata keçirilmişdir. Açar sözlər: rüblük proqnoz modeli, Azərbaycan iqtisadiyyatı, proqnozlaşdırma və siyasət təhlili, pul siyasəti. JEL təsnifatı: E32, E37, E47, E52 ',
  files: [
    {
      id: 1,
      title: 'Azərbaycanın Rüblük Proqnozlaşdırma Modeli (AzİM 1.0)',
      web_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
      file_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
      type: 'pdf',
    },
  ],
};
export const workingPaperData = {
  text: 'İşçi məqalələr Mərkəzi Bankın əməkdaşları tərəfindən aparılan tədqiqat işlərini əhatə edir. İşçi məqalələr silsiləsinin dərc olunmasında əsas məqsəd mövzular ətrafında müzakirələri stimullaşdırmaqdır. Məqalələrə dair rəy və təkliflər müəlliflərə ünvanlanmalıdır. Müəlliflik nüansları nəzərə alınaraq burada məqalələrin yalnız orijinal mətni (tərcüməsiz) yerləşdirilmişdir.',
  papers: [
    {
      id: 1,
      year: '2024',
      articles: [
        {
          id: 1,
          slug: 'aaa',
          title: 'Azərbaycanın Rüblük Proqnozlaşdırma Modeli (AzİM 1.0)',
          subTitle: 'Nömrə: 01/2024',
        },
      ],
    },
    {
      id: 2,
      year: '2023',
      articles: [
        {
          id: 1,
          slug: 'dewfrw',
          title: 'Azərbaycanın Rüblük Proqnozlaşdırma Modeli (AzİM 1.0)',
          subTitle: 'Nömrə: 01/2024',
        },
        {
          id: 2,
          slug: 'rgewrg',
          title: 'Azərbaycanın Rüblük Proqnozlaşdırma Modeli (AzİM 1.0)',
          subTitle: 'Nömrə: 01/2024',
        },
      ],
    },
    {
      id: 3,
      year: '2022',
      articles: [
        {
          id: 1,
          slug: 'ferfr',
          title: 'Azərbaycanın Rüblük Proqnozlaşdırma Modeli (AzİM 1.0)',
          subTitle: 'Nömrə: 01/2024',
        },
        {
          id: 2,
          slug: 'rewfrf',
          title: 'Azərbaycanın Rüblük Proqnozlaşdırma Modeli (AzİM 1.0)',
          subTitle: 'Nömrə: 01/2024',
        },
        {
          id: 3,
          slug: 'egtg',
          title: 'Azərbaycanın Rüblük Proqnozlaşdırma Modeli (AzİM 1.0)',
          subTitle: 'Nömrə: 01/2024',
        },
      ],
    },
  ],
};
export const annualReportData = [
  {
    id: 1,
    title: '2024',
    files: [
      {
        id: 1,
        title:
          'Azərbaycan Respublikası Mərkəzi Bankının 31 dekabr 2024-cü il tarixinə Konsolidasiya edilmiş Maliyyə Hesabatları',
        web_url: 'https://uploads.cbar.az/assets/71d4da94ec6df159561b1a2b7.pdf',
        file_url: 'https://uploads.cbar.az/assets/71d4da94ec6df159561b1a2b7.pdf',
        type: 'pdf',
      },
      {
        id: 2,
        title: '2024-cü il üçün Mərkəzi Bankın illik hesabatı',
        web_url: 'https://uploads.cbar.az/assets/71d4da94ec6df159561b1a2b7.pdf',
        file_url: 'https://uploads.cbar.az/assets/71d4da94ec6df159561b1a2b7.pdf',
        type: 'pdf',
      },
    ],
  },
  {
    id: 2,
    title: '2023',
    files: [
      {
        id: 1,
        title:
          'Azərbaycan Respublikası Mərkəzi Bankının 31 dekabr 2024-cü il tarixinə Konsolidasiya edilmiş Maliyyə Hesabatları',
        web_url: 'https://uploads.cbar.az/assets/71d4da94ec6df159561b1a2b7.pdf',
        file_url: 'https://uploads.cbar.az/assets/71d4da94ec6df159561b1a2b7.pdf',
        type: 'pdf',
      },
      {
        id: 2,
        title: '2024-cü il üçün Mərkəzi Bankın illik hesabatı',
        web_url: 'https://uploads.cbar.az/assets/71d4da94ec6df159561b1a2b7.pdf',
        file_url: 'https://uploads.cbar.az/assets/71d4da94ec6df159561b1a2b7.pdf',
        type: 'pdf',
      },
    ],
  },
  {
    id: 3,
    title: '202',
    files: [
      {
        id: 1,
        title:
          'Azərbaycan Respublikası Mərkəzi Bankının 31 dekabr 2024-cü il tarixinə Konsolidasiya edilmiş Maliyyə Hesabatları',
        web_url: 'https://uploads.cbar.az/assets/71d4da94ec6df159561b1a2b7.pdf',
        file_url: 'https://uploads.cbar.az/assets/71d4da94ec6df159561b1a2b7.pdf',
        type: 'pdf',
      },
      {
        id: 2,
        title: '2024-cü il üçün Mərkəzi Bankın illik hesabatı',
        web_url: 'https://uploads.cbar.az/assets/71d4da94ec6df159561b1a2b7.pdf',
        file_url: 'https://uploads.cbar.az/assets/71d4da94ec6df159561b1a2b7.pdf',
        type: 'pdf',
      },
    ],
  },
];
export const interSectoralData = [
  {
    id: 1,
    title: '2025',
    files: [
      {
        id: 1,
        title: 'Sahələrarası maliyyə axınlarının təhlili - II rüb 2025',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
      {
        id: 2,
        title: 'Sahələrarası maliyyə axınlarının təhlili - I rüb',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
    ],
  },
  {
    id: 2,
    title: '2024',
    files: [
      {
        id: 1,
        title: 'Sahələrarası maliyyə axınlarının təhlili - IV rüb 2024',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
      {
        id: 2,
        title: 'Sahələrarası maliyyə axınlarının təhlili - III rüb 2024 ',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
      {
        id: 3,
        title: 'Sahələrarası maliyyə axınlarının təhlili - II rüb 2024',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
      {
        id: 4,
        title: 'Sahələrarası maliyyə axınlarının təhlili - I rüb 2024',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
    ],
  },
  {
    id: 3,
    title: '2023',
    files: [
      {
        id: 1,
        title: 'Sahələrarası maliyyə axınlarının təhlili - IV rüb 2023',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
      {
        id: 2,
        title: 'Sahələrarası maliyyə axınlarının təhlili - III rüb 2023 ',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
      {
        id: 3,
        title: 'Sahələrarası maliyyə axınlarının təhlili - II rüb 2023',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
      {
        id: 4,
        title: 'Sahələrarası maliyyə axınlarının təhlili - I rüb 2023',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
    ],
  },
  {
    id: 4,
    title: '2022',
    files: [
      {
        id: 1,
        title: 'Sahələrarası maliyyə axınlarının təhlili - IV rüb 2022',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
      {
        id: 2,
        title: 'Sahələrarası maliyyə axınlarının təhlili - III rüb 2022 ',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
      {
        id: 3,
        title: 'Sahələrarası maliyyə axınlarının təhlili - II rüb 2022',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
      {
        id: 4,
        title: 'Sahələrarası maliyyə axınlarının təhlili - I rüb 2022',
        web_url: 'https://uploads.cbar.az/assets/5a0b8752eeebfca66817ca844.pdf',
        file_url: 'https://uploads.cbar.az/assets/bbf122daac31d3b05144e0374.xlsx',
        type: 'pdf',
      },
    ],
  },
];
export const monetaryStatisticsData = {
  id: 1,
  title: 'Pul-kredit statistikası',
  files: [
    {
      id: 1,
      title: 'Pul icmalı (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
    {
      id: 2,
      title: 'AMB-nin analitik balansı (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
    {
      id: 3,
      title: 'Kommersiya banklarının analitik balansı (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
    {
      id: 4,
      title: 'Pul aqreqatları (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
    {
      id: 5,
      title: 'Pul bazası (dövrün sonuna) (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
    {
      id: 6,
      title:
        'İqtisadiyyata kredit qoyuluşlarının kredıt təşkilatları üzrə strukturu (dövrün sonuna) (25.06.2025)',
      file_url: 'https://uploads.cbar.az/assets/09b4f707806fa2f47d4af81b8.xlsx',
      type: 'xls',
    },
  ],
};
export const financialCyberSecurity = [
  {
    id: 1,
    title: 'Maliyyə bazarlarında kibertəhlükəsizlik Strategiyası',
    web_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
    file_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
    type: 'pdf',
  },
];
export const riskSupervisionCbar = [
  {
    id: 1,
    title: 'Azərbaycan Respublikası Mərkəzi Bankının risk əsaslı nəzarət üzrə Siyasət Konsepsiyası',
    web_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
    file_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
    type: 'pdf',
  },
];
export const roadMapSupervisionCbar = [
  {
    id: 1,
    title:
      'Azərbaycan Respublikası Mərkəzi Bankının 2024-2029-cu illəri əhatə edəcək Nəzarət Texnologiyaları üzrə Yol Xəritəsinin qısa icmalı',
    web_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
    file_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
    type: 'pdf',
  },
];
export const microFinanceData = [
  {
    id: 1,
    title: 'Mikromaliyyə Modeli üzrə Strateji Çərçivə',
    web_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
    file_url: 'https://uploads.cbar.az/assets/4f9ced2ebffd8b2fb6149f920.pdf',
    type: 'pdf',
  },
];
