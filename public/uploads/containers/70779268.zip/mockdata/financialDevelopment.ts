import { chairman } from './images';

export const financialDevelopmentData = {
  image: chairman,
  title: '2024-2026-cı illərdə maliyyə sektorunun inkişaf Strategiyası',
  content:
    'Hörmətli maliyyə sektoru iştirakçıları,Azərbaycan Respublikası Mərkəzi Bankının İdarə Heyəti tərəfindən “2024-2026-cı illərdə maliyyə sektorunun inkişaf Strategiyası” təsdiq olunmuşdur.Strategiya ölkəmizdə maliyyə sisteminin mühüm sektorları olan sığorta, kapital bazarları və ödəniş sistemlərinin inkişaf etdirilməsi, habelə bank sektorunun dayanıqlığının daha da gücləndirilməsi kimi prioritetləri ehtiva edir. Strategiya maliyyə inklüzivliyinin genişləndirilməsi, maliyyə xidmətlərinin əhatəliliyinin artırılması və maliyyə alətlərinin şaxәlәndirilməsi, sektorda sәmәrәliliyin yüksəldilməsi, korporativ idarәetmәnin tətbiqi, habelə şәffaflıq və dayanıqlılığının gücləndirilməsi kimi strateji məqsədləri özündə əks etdirir.Strategiya sənədi həmçinin hər sektorun ehtimal olunan bazar potensialını, Mərkəzi Bankın müvafiq keyfiyyət tələblərini və risk əsaslı nəzarət mexanizmlərini, rəqəmsal maliyyə, dayanıqlı maliyyə, peşəkar inkişaf və əhalinin maliyyə biliklərinin artırılması kimi istiqamətləri müəyyən edir.Strategiyada sürətli inkişaf mərhələsində olan sığorta sektoru üzrə vasitəçi və satış kanallarının (sığorta agentləri və brokerləri daxil olmaqla) genişləndirilməsi, könüllü və icbari sığortanın təşviqi, sığorta məlumat və monitorinq mərkəzinin yaradılması, eləcə də korporativ idarəetmənin gücləndirilməsi və risk əsaslı prudensial tənzimləmənin həyata keçirilməsi məsələləri nəzərdə tutulub.  Sığorta sektoru üzrə əsas strateji hədəflər, sığorta təminatını genişləndirmək və istehlakçı hüquqlarını effektiv müdafiə etməklə, sığortaya olan inam indeksinin 66%-dən 80%-ə yüksəldilməsini və sığortaçıların ödәmә qabiliyyәtinin artırılması ilə yanaşı, adambaşına düşən ümumi sığorta haqqının cari 121 manatdan potensial olaraq 195 manata çatdırılmasını əhatə edir. Bu kompleks yanaşma riskləri effektiv idarə etməklə iqtisadi artımı dəstəkləmək məqsədi daşıyır.',
  file: {
    headTitle:
      'Strategiya sənədinin əhatəli icmalı ilə bu keçiddən istifadə etməklə tanış ola bilərsiniz:',
    fileTitle: '2024-2026-cı illərdə maliyyə sektorunun inkişaf Strategiyası',
    url: 'https://cbar.az/2024_2026_Azerbaijani.pdf',
  },
};
