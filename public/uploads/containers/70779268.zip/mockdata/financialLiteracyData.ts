import {
  eventsImage,
  financialLiteracyPortal,
  infoSearch1,
  infoSearch2,
  infoSearch3,
  InfoSearchSystem,
  portalImg1,
  portalImg2,
  portalImg3,
  virtualEdu1,
  virtualEdu2,
  virtualEdu3,
  virtualEducationPlatform,
} from './images';

export const financialLiteracy = {
  title: 'Maliyyə savadlılığı',
  content:
    'Maliyyə sağlamlığı həyatımızda fiziki və intellektual sağlamlıq kimi vacibdir. Uşaqlıqdan başlayan maliyyə bilikləri və davamlı təhsil fərdlərin maliyyə qərarlarını düzgün verməsinə yardım edir. Azərbaycan Mərkəzi Bankının təşəbbüsləri ilə maliyyə savadlılığınızı artırın və gələcəyiniz üçün dayanıqlı maliyyə sağlamlığı yaradın!',
  video: 'https://www.youtube.com/embed/jW2zf8zFE7c?si=D38A47Ngu6Tth92N',
  eventInnerLink: {
    title: 'Tədbirlər',
    image: eventsImage,
  },
  portalInnerLink: {
    title: 'Maliyyə Savadlılığı Portalı',
    image: financialLiteracyPortal,
  },
  platformInnerLink: {
    title: 'Virtual Təhsil Platforması',
    image: virtualEducationPlatform,
  },
  infoSearchSystemInnerLink: {
    title: 'Maliyyə məhsul və xidmətlərinin məlumat-axtarış sistemi',
    image: InfoSearchSystem,
  },
};
export const financialEventsData = {
  title: 'Tədbirlər',
  events: [
    {
      id: 1,
      title: '2025',
      eventList: [
        {
          id: 1,
          date: '19.05.2025',
          title:
            '28 nömrəli tam orta məktəbdə Milli pul nişanları və Mərkəzi Bankın elektron resurslarına həsr edilmiş maliyyə məlumatlılığı seminarı keçirilib',
          url: 'https://bizimpullar.az/home',
        },
        {
          id: 2,
          date: '02.05.2025',
          title:
            'Akademik Xoşbəxt Yusifzadə adına 112 nömrəli tam orta məktəbdə Milli pul nişanları və Mərkəzi Bankın elektron resurslarına həsr edilmiş maliyyə məlumatlılığı seminarı keçirilib',
          url: 'https://bizimpullar.az/news/detail/1165',
        },
        {
          id: 3,
          date: '24.04.2025',
          title:
            "Faiq Rəfiyev adına 166 nömrəli məktəb-liseydə 'Milli pul nişanları və Mərkəzi Bankın elektron resurslarına həsr edilmiş maliyyə məlumatlılığı seminarı keçirilib",
          url: 'https://bizimpullar.az/news/detail/1162',
        },
      ],
    },
    {
      id: 2,
      title: '2024',
      eventList: [
        {
          id: 1,
          date: '28.12.2024',
          title:
            'H.Mahmudbəyov adına 2 nömrəli Texniki-Humanitar liseyində Milli pul nişanlarına həsr edilmiş maliyyə məlumatlılığı seminarı keçirilmişdir',
          url: 'https://bizimpullar.az/news/detail/1140',
        },
        {
          id: 2,
          date: '17.12.2024',
          title:
            'Milli pul nişanları ilə bağlı məlumatlılığın artırılması məqsədilə tədbir keçirilib',
          url: 'https://bizimpullar.az/news/detail/1132',
        },
        {
          id: 3,
          date: '30.10.2024',
          title:
            'Mərkəzi Bank tərəfindən Qaçqın və Məcburi Köçkünlərin İşləri üzrə Dövlət Komitəsinin əməkdaşları üçün maliyyə savadlılığı təlimi keçirilmişdir',
          url: 'https://bizimpullar.az/news/detail/1116',
        },
      ],
    },
    {
      id: 3,
      title: '2023',
      eventList: [
        {
          id: 1,
          date: '28.12.2023',
          title:
            'Azərbaycan Respublikasının Vəkillər Kollegiyası və Azərbaycan Qida Təhlükəsizliyi İnstitutunun əməkdaşları üçün Maliyyə savadlılığı seminarları keçirilmişdir',
          url: 'https://bizimpullar.az/news/detail/946',
        },
        {
          id: 2,
          date: '27.12.2023',
          title:
            'Azərbaycan Dövlət Mədəniyyət və İncəsənət Universitetində əcnəbi tələbələr üçün məlumatlandırma sessiyası keçirilmişdir',
          url: 'https://bizimpullar.az/news/detail/947',
        },
        {
          id: 3,
          date: '21.12.2023',
          title:
            'Bakı Slavyan Universitetində əcnəbi tələbələr üçün məlumatlandırma sessiyası keçirilmişdir',
          url: 'https://bizimpullar.az/news/detail/942',
        },
      ],
    },
  ],
};
export const financialPortal = {
  title: 'Maliyyə Savadlılığı portalı',
  content:
    'Portalın əsas məqsədi maliyyə savadlılığının artırılması istiqamətində bütün təşəbbüsləri (resurslar, tədbirlər haqqında məlumatlar və s.) vahid bir virtual məkanda toplamaq, eyni zamanda ölkədə maliyyə savadlılığı üzrə əsas təşviqedici platforma olmaqdır.Pullar bölməsində dövriyyədə olan yenilənmiş kağız pullar haqqında animasiyalar yerləşdirilmişdir. Burada hər bir nominalın üzərində yerləşən təsvirlər, mühafizə elementləri haqqında maraqlı və maarifləndirici məlumatlar videorolik formatında təqdim olunmuşdur.',
  images: [
    {
      id: 1,
      image: portalImg1,
    },
    {
      id: 2,
      image: portalImg2,
    },
    {
      id: 3,
      image: portalImg3,
    },
  ],
};
export const virtualEduData = {
  title: 'Virtual Təhsil Platforması',
  content:
    'Azərbaycan Respublikasının Mərkəzi Bankının Virtual Təhsil Platforması – https://edu.e-cbar.az/ 2017-ci ildə fəaliyyətə başlamışdır.Ənənəvi təlim üsullarını müasir formatda təklif edən bu platformanın əsas məqsədi iqtisadiyyat və maliyyə-bank sektorunda çalışan, bu istiqamətdə təhsil alan, həmçinin öz bilik və bacarığını inkişaf etdirmək istəyən şəxslərə, o cümlədən şagirdlərə dəstək olmaqdır.Platformada mövcud olan distant tədris modulları istifadəçilərə zaman və məkan fərqi olmadan peşəkarlıq səviyyəsini təkmilləşdirmək imkanı yaradır.Kursların hazır və virtual mühitdə yerləşdirilməsi iştirakçılara daha rahat və sərbəst təhsil almaq imkanı yaradır. Bu, həmçinin istifadəçilərin üçüncü şəxslərdən (müəllim, qrup yoldaşı, inzibatçı) asılılığını azaldaraq keyfiyyətli tədris şəraiti ilə təmin edir. İştirakçılar ehtiyac və istəyindən asılı olaraq istənilən vaxt portala daxil ola bilər. Tədris prosesinin effektivliyini izləmək məqsədilə platformada iştirakçıların qeydiyyatı zəruridir. Qeydiyyat haqqında ətraflı məlumatı bu link vasitəsilə əldə etmək olar: https://youtu.be/0iNZkyQ0Q7M ',
  images: [
    {
      id: 1,
      image: virtualEdu1,
    },
    {
      id: 2,
      image: virtualEdu2,
    },
    {
      id: 3,
      image: virtualEdu3,
    },
  ],
};
export const infoSearchData = {
  title: 'Maliyyə məhsul və xidmətlərinin məlumat-axtarış sistemi',
  content:
    'Əhalinin maliyyə xidmətlərinə çıxış imkanlarının asanlaşdırılması və bu xidmətlərdən istifadənin stimullaşdırılması məqsədilə 2019-cu ildən etibarən Maliyyə məhsul və xidmətlərinin məlumat-axtarış sistemi -https://infobank.az/ - istifadəyə verilmişdir. Sistem eyni zamanda, maliyyə xidmətləri bazarında rəqabəti gücləndirmək, təqdim olunan məhsul və xidmətlərin keyfiyyətini artırmaq məqsədi də daşıyır. https://infobank.az/ tələb olunan məlumatı maksimum bir dəqiqə ərzində əldə etməyə imkan yaradır. Burada istehlakçıların maliyyə davranışlarına xidmət edəcək faydalı və lazımi məlumatlar vahid bir məkanda toplanmışdır. Xüsusi qeyd etmək lazımdır ki, axtarış bazarda mövcud və aktual olan bütün maliyyə xidmətlərinə dair təkliflər əsasında aparılır.Sistemdəki məlumatlar mütəmadi olaraq monitorinq olunur, yenilənir və zənginləşdirilir. Rəy, təklif və dəstək üçün ünvan: infobank@cbar.az',
  images: [
    {
      id: 1,
      image: infoSearch1,
    },
    {
      id: 2,
      image: infoSearch2,
    },
    {
      id: 3,
      image: infoSearch3,
    },
  ],
};
